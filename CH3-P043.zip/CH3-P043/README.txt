SBL 1.0 resolved page rendering package
Render target: CH3-P043
Entry file: CH3-P043.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Zora-mana-effects-sheet.png
  Assets/Alpha-expression-sheet.png
  Assets/Terra-expression-sheet.png
  Assets/Zoran_Language_and_script.docx
  Assets/Zora-Nyas-technology-timeline.txt
  Assets/Terra-canonical-character-specification.txt
  Assets/Zorna-character-sheet.png
  Assets/Zorna-canonical-character-specification.txt
  Assets/Zora-cultural-development-specification.txt
  Assets/Nyssara-expression-sheet.png
  Assets/Nyssara-character-sheet.png
  Assets/Alpha-character-sheet.png
  Assets/Zora-Nyas-writing-systems-sheet.png
  Assets/Terra-character-sheet.png
  Assets/Alpha-canonical-character-specification.txt
  Assets/Nyssara-canonical-character-specification.txt
  Assets/Zorna-expression-sheet.png
  Assets/Zora-Nyas-writing-systems-renderer-spec.txt
  Assets/Zora-Nyas-world-map.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
