# Scene Blocking Language (SBL) 1.0
## AI-Readable Specification — Revision 134

> Derived from the Human-Readable SBL 1.0 Specification, Revision 133.
> The Human-Readable Specification is authoritative if a discrepancy is found.
> Figures are omitted from this AI-oriented text.

Human-Readable Specification — 1.0 rev 132

Written by ChatGPT under the direction of Randy Hyde, edited by Randy Hyde

Normative Human-Readable Specification for SBL 1.0

## Why “Blocking”?

The term blocking comes from theater and is also standard production terminology in film and television. Blocking is the process of deciding where performers are positioned and how they move through a scene: where someone stands, when an actor crosses the stage, who approaches whom, where a performer sits, which direction someone faces, and how the performers relate spatially to one another.

A commonly repeated explanation for the term is that theater directors used small blocks or other markers representing actors on a miniature stage or stage plan while working out positions and movement. Whatever the precise etymology, the production meaning is well established: to block a scene is to establish the physical arrangement and movement of its participants.

The idea transfers directly to filmmaking and sequential art. A director might first decide that one actor enters through a door, crosses behind another actor, stops beside a desk, and turns toward a third person. Camera placement, lighting, framing, and other production decisions can then be built around that blocking.

Scene Blocking Language takes its name from this production concept. SBL describes much more than literal actor placement, but its central purpose is closely related: to state who and what is present, where they are, what they are doing, how they are oriented, and how the audience should see the scene. This is also why SBL uses theatrical terms such as stage left, stage right, upstage, downstage, center stage, and midstage where those terms provide useful spatial descriptions.

## Normative Language

This specification uses the capitalized terms MUST, MUST NOT, REQUIRED, SHALL, SHALL NOT, SHOULD, SHOULD NOT, RECOMMENDED, NOT RECOMMENDED, MAY, and OPTIONAL in their conventional standards-document sense. MUST/REQUIRED identify requirements for conformance. MUST NOT/SHALL NOT identify prohibited behavior. SHOULD/RECOMMENDED identify behavior that is strongly preferred but may be departed from when a documented reason exists. SHOULD NOT/NOT RECOMMENDED identify behavior that is normally avoided. MAY/OPTIONAL identify behavior that is permitted but not required. Lowercase uses of words such as "must" or "should" in ordinary explanatory prose are not normative unless the surrounding text explicitly says otherwise.

## Purpose

The script object is the root of an SBL document. It identifies the work, records document-level metadata, selects the applicable media profile, defines optional defaults, and contains the lower-level renderable page/panel structure. SBL 1.0 normatively supports manga, comic, and static storyboard documents using this page/panel model.

The script level should remain relatively thin. Information required to render an individual panel should not exist only at this level, because a large production may be processed one page or panel at a time. A resolver should be able to expand inherited and global information into a self-contained renderable unit before that unit is sent to an image generator or other renderer.

## Authoring Workflow

1. Write the scene in ordinary prose or script form.
2. Ask a generative AI system to convert the scene into valid SBL/JSON.
3. Validate or review the generated SBL and provide any required reference resources.
4. Submit the SBL and its resources to the image-generation or rendering system.
5. Review the generated image.
6. Modify the SBL/JSON, or ask the generative AI system to modify it, to correct blocking, camera placement, character state, dialogue, lighting, or other renderable details.
7. Render again and repeat until the result is satisfactory.

This makes the JSON representation an editable intermediate form rather than the primary authoring interface. Authors may edit the JSON directly when convenient, but the language is designed so that a generative AI system can perform most of the translation between a normal human-readable script and the structured SBL representation.

The same workflow also makes revisions explicit. Instead of describing an image correction only in conversational terms, the corresponding SBL properties can be changed and the revised scene rendered again. The SBL document therefore becomes a persistent, inspectable description of the intended scene.

### Schema Validation in the Authoring Workflow

The SBL JSON Schema is an automated structural grammar checker for SBL source. SBL 1.0 defines two schema-validation profiles: (1) the Source SBL profile, used while a document is being authored or edited, and (2) the Renderable Source SBL profile, used immediately before semantic resolution and rendering. Both profiles validate the same language structures; the renderable profile adds readiness requirements that are intentionally relaxed during editing. The schema is not itself an image-generation prompt and normally is not sent directly to the renderer.

The recommended workflow is: normal script → generative AI → Source SBL/JSON → JSON parsing → JSON Schema validation → SBL semantic resolution/validation → Resolved SBL → optional Render SBL → image generator or other renderer.

When a generative AI system such as ChatGPT is used to author SBL, the user should provide the AI-oriented SBL specification and the applicable JSON Schema together with the natural-language script and any required reference resources. The AI should be instructed to produce SBL that conforms to the schema and to report missing required information or resources rather than inventing them.

The JSON Schema checks structural properties such as required fields, data types, enumerated vocabulary, and basic numeric ranges. For example, it can reject an invalid stage-position keyword or an elevation value outside its permitted range.

Schema validation does not replace SBL semantic resolution. A document may satisfy the JSON Schema while still containing unresolved character or object references, contradictory required constraints, inheritance or import cycles, missing required resources, or other cross-object semantic errors. Those conditions are detected by the SBL resolver/semantic validator.

Accordingly, validation occurs at three distinct levels: (1) JSON parsing asks whether the source is legal JSON; (2) JSON Schema validation asks whether the JSON has legal SBL structure; and (3) SBL semantic validation/resolution asks whether the SBL references and requirements form a coherent, renderable scene. Rendering should normally begin only after all applicable pre-render validation stages succeed.

Schema Validation Profiles — A document conforming to the Source SBL profile MUST contain the normal required script identity fields and a "pages" array, but "format" MAY be omitted and "pages" MAY be empty while the document is under construction. A document conforming to the Renderable Source SBL profile MUST additionally contain "format" with a supported "medium" and MUST contain at least one page. Every page present in either profile MUST satisfy the page structure defined by this specification; SBL 1.0 does not define partially formed page objects as schema-valid pages. The renderable profile is therefore a stricter validation entry point over the same Source SBL grammar, not a separate language.

The schema may be used directly by a standard JSON Schema Draft 2020-12 validator, or indirectly by a generative AI system that has been supplied with the schema. A future SBL resolver or command-line tool may automate both schema validation and semantic resolution.

## Root Structure

SBL is represented using JSON (JavaScript Object Notation), a widely used text format for representing structured data. You do not need to be a programmer to read this specification, and you are not expected to write large SBL documents by hand. However, a small amount of JSON vocabulary will make the examples much easier to understand.

JSON organizes information primarily as objects and arrays. An object is a collection of named entries, and an array is an ordered list of values. Names are written in double quotation marks and are followed by a colon and their associated value. Objects are enclosed in curly braces { }, while arrays are enclosed in square brackets [ ]. SBL uses these ordinary JSON structures to describe scripts, pages, panels, characters, and other scene information.

Readers who want additional background on JSON may consult:

a. MDN: Working with JSON — an accessible introduction with examples.

b. MDN: JSON glossary — a short overview of JSON values, objects, and arrays.

c. RFC 8259 — the IETF Internet Standard defining the JSON data interchange format.

d. ECMA-404 — the ECMA JSON data interchange syntax specification.

The following is the basic form of an SBL script. The example uses the documentation's Allman-style formatting: when the value associated with an entry is an object, its opening brace is placed on the following line at the same indentation level as the entry name.

```json
{
  "script":
  {
    "id": "IAKESI-CH12",
    "title": "Chapter 12",
    "subtitle": "Midori at the Academy",
    "specification":
    {
      "name": "SBL",
      "version": "1.0",
      "exact": false
    },
    "metadata":
    {
      "author":
      [
        "Randall Hyde"
      ],
      "created": "2026-08-19",
      "modified": "2026-08-19",
      "version": "1.0",
      "language": "en-US",
      "description": ""
    },
    "format":
    {
      "medium": "manga",
      "reading_direction":
      [
        "left_to_right",
        "top_to_bottom"
      ]
    },
    "defaults":
    {
    },
    "pages":
    [
    ]
  }
}
```

Every JSON object begins with an opening curly brace ({) and ends with a matching closing curly brace (}). Everything belonging to that object appears between those braces. In the example above, the first and last braces enclose the complete JSON document.

An SBL document begins with a top-level entry named "script". The value associated with "script" is itself a JSON object, so it has its own opening and closing braces. Everything that belongs to the SBL script appears between those braces.

The script body contains a list of named entries that describe the production. In this example those entries include an identifier (id), a human-readable title, the SBL specification and version being used, descriptive metadata, the media format, default data, and the pages that make up the script. Some of these entries contain simple values such as text; others contain additional JSON objects or arrays.

For the Source SBL validation profile, the required script-body entries are "id", "title", "specification", and "pages". The "subtitle", "metadata", "format", "defaults", "imports", "resources", "characters", and "text_styles" entries are optional while a source document is being constructed. For the Renderable Source SBL profile, "format" is additionally REQUIRED and "format.medium" MUST select a supported SBL 1.0 media profile. Optional entries may otherwise be omitted entirely; they do not need empty objects or arrays. The empty "defaults" object shown above is legal but is not required.

The "pages" entry is required in both schema-validation profiles. Under the Source SBL profile it MAY be empty while the document is being constructed or edited. Under the Renderable Source SBL profile it MUST contain at least one page, and each page MUST contain at least one logical panel. This distinction allows an incomplete production to remain valid Source SBL without treating it as ready for rendering.

The following major sections define each of the script-body entries in more detail, beginning with the script identifier and title.

## Script Identification

### id

A stable machine-readable identifier for the script. The identifier should remain unchanged when the human-readable title changes. Other documents and resources may use this value when referencing the script.

```json
"id": "IAKESI-CH12"
```

### title

The human-readable name of the script, chapter, episode, or other production unit. Unlike id, the title may be revised without breaking references.

```json
"title": "Chapter 12"
```

### subtitle

An optional human-readable subtitle may supplement "title". Use "title" for the primary name of the work or production unit and "subtitle" for a secondary descriptive line. Keeping them separate allows publishing tools and renderers to format them independently.

```json
"subtitle": "Midori at the Academy"
```

## Specification Identification

The "specification" object identifies the SBL language and language version required by the document. Its primary purpose is compatibility control: it prevents a script from being processed using SBL semantics older than those required by the script. This is independent of the version of the script document itself.

Requirements — "specification.name" and "specification.version" are REQUIRED. For SBL 1.0, name MUST be "SBL". "exact" is optional Boolean and defaults to false.

```json
"specification":
{
  "name": "SBL",
  "version": "1.0",
  "exact": false
}
```

If "exact" is false or omitted, a processor may use a later SBL version that is backward-compatible with the requested version, but a processor whose supported SBL version is older than the requested version MUST reject the script. If "exact" is true, the processor MUST reject the script unless it supports that SBL version exactly or explicitly provides an exact compatibility mode. "exact" defaults to false.

The "specification" object therefore prevents an SBL document from being processed under language semantics that are older than those required by the document, and may optionally require an exact SBL version match.

The specification version allows processors to detect incompatible syntax or semantics as SBL evolves.

## SBL Text

SBL contains many properties whose values are human-readable text: descriptions, renderer directions, dialogue, narration, sound effects, captions, and text appearing on objects. Most text needs no special formatting and can remain an ordinary JSON string. When formatting changes are required within the text, SBL provides a structured rich-text representation using runs.

### Definition

An SBL Text value is human-readable textual content intended for interpretation or display. Unless a field explicitly states otherwise, every field defined by this specification as SBL Text accepts either (a) an ordinary JSON string or (b) an SBL Text object containing a "runs" array. These two representations are semantically interchangeable except that runs can carry formatting.

This rule applies only to fields explicitly defined as SBL Text. Machine strings such as ids, type names, enum values, resource paths, modes, actions, and references remain ordinary JSON strings and cannot be replaced by runs.

### Simple SBL Text

```json
"description": "Midori approaches the door."
```

Line breaks and other control characters use normal JSON string escape syntax. SBL does not introduce a separate multiline-string syntax.

```json
"description": "Midori stands near the classroom door.\nShe holds her notebook against her chest.\nBeli watches her from across the room."
```

### Rich SBL Text and Runs

When formatting changes within a textual value, use an object containing a "runs" array. Each array element is a text run: a consecutive span of characters sharing the same formatting properties. Runs are concatenated in array order. A run does not imply a new line; use "\n" inside the run’s "text" string when an explicit line break is required.

```json
{
  "content":
  {
    "runs":
    [
      {
        "text": "This is "
      },
      {
        "text": "very",
        "italic": true
      },
      {
        "text": " important."
      }
    ]
  }
}
```

### Text Run Fields

Each element of "runs" is an object. "text" is required; all other properties are optional. An omitted formatting property inherits the applicable surrounding/default text style.

The "runs" array MAY be empty; an empty array is equivalent to an empty string. A run MAY contain an empty "text" string, although authors SHOULD omit empty runs unless they are useful to an editing tool. Runs do not nest: the required "text" member of a run is always an ordinary JSON string, never another SBL Text object or another "runs" array.

text (string) — Required. Literal text for the run. It may contain any JSON string escape, including \n, \r, \t, and Unicode characters.

bold (boolean) — Requests boldface.

italic (boolean) — Requests italic styling.

underline (boolean) — Requests underlining.

strike (boolean) — Requests strikethrough.

font (object) — Selects a font role and optionally a preferred font family and fallbacks.

size (number) — Relative size multiplier. 1.0 is normal; values below 1.0 are smaller and values above 1.0 are larger.

color (string) — Requested text color. Accepts a standard color name or hexadecimal RGB color such as "#1E90FF".

align (string) — Vertical alignment of this run relative to surrounding text.

style (string) — Machine id of a reusable text style.

#### Run Alignment

The "align" field controls vertical placement relative to the surrounding baseline. Valid core values are "baseline" (default), "sub" (subscript), "super" (superscript), "top", "middle", and "bottom". The latter three are primarily useful when runs of significantly different sizes or inline symbols are mixed.

```json
{
  "runs":
  [
    { "text": "x = 2 + 3" },
    { "text": "2", "align": "super", "size": 0.7 }
  ]
}
```

### Font Selection

The "font" object describes the requested typeface. It MUST contain at least one of "role" or "family". For portable SBL, "role" is preferred because an image renderer or another computer may not possess a particular installed font. "family" expresses a preferred named font when available; "fallback" is an ordered array of acceptable roles or families if the preferred family is unavailable.

```json
{
  "font":
  {
    "role": "handwritten"
  }
}
{
  "font":
  {
    "family": "Bradley Hand",
    "fallback":
    [
      "handwritten",
      "cursive"
    ]
  }
}
```

Recommended core font roles are "normal", "serif", "sans_serif", "monospace", "handwritten", "cursive", "display", "decorative", and "printed". Font roles are extensible: an author may use another concise role understood by the renderer. A renderer SHOULD preserve the requested visual intent even when it substitutes a different physical font.

### Size, Color, and Emphasis

"size" is deliberately relative rather than a point size because SBL targets both conventional typesetting and image generation. A value of 1.0 means the applicable normal text size. When a run inherits a size from a reusable style and also specifies its own "size", the run value REPLACES the inherited size; relative size values are not multiplied unless a future construct explicitly requests scaling. "color" accepts a CSS named-color identifier composed of ASCII letters (for example "red", "black", or "rebeccapurple") or hexadecimal RGB in "#RRGGBB" form. SBL 1.0 does not define alpha-channel text colors. bold, italic, underline, and strike are independent booleans and may be combined.

```json
{
  "text": "WARNING!",
  "bold": true,
  "size": 1.25,
  "color": "red"
}
```

### Reusable Text Styles

Formatting combinations used repeatedly may be named in "text_styles". A run can then reference the style by machine id. Explicit properties on a run override the corresponding property inherited from its named style.

```json
{
  "text_styles":
  {
    "handwritten_note":
    {
      "font":
      {
        "role": "handwritten"
      },
      "italic": true
    },
    "warning":
    {
      "bold": true,
      "size": 1.25,
      "color": "red"
    }
  }
}
{
  "runs":
  [
    {
      "text": "Do not enter.",
      "style": "handwritten_note"
    }
  ]
}
```

#### Declaration and Scope

"text_styles" is an object containing reusable text-formatting definitions keyed by machine-readable style id. It MAY appear at script, page, panel, or library scope. A text style is visible in the scope where it is declared and in descendant scopes unless a narrower declaration with the same id overrides it.

Text-style ids use normal SBL lexical and qualification rules. Imported libraries MAY declare text styles. When qualification is required, a run may use a reference such as "Typography-Library::handwritten_note". The run property "style" is therefore a machine-readable reference, not SBL Text.

A text-style definition MUST contain formatting properties only and MUST NOT contain "text" or other textual content. SBL 1.0 text styles are flat: one text style MUST NOT inherit from, extend, or otherwise derive from another text style.

To resolve a run, the resolver first resolves the named style, copies its formatting properties into the effective run, and then applies formatting properties written directly on the run. Explicit run properties override the corresponding properties supplied by the named style. When the narrower scope ends, any overridden broader style becomes visible again.

### Unicode and JSON Escape Sequences

SBL Text is Unicode text. Unicode characters may appear directly in JSON strings, and portable SBL files SHOULD be encoded as UTF-8. SBL defines no additional character-escape language: its strings use JSON escapes.

JSON string escapes available to SBL include \" for a quotation mark, \\ for a backslash, \/ for a slash, \b for backspace, \f for form feed, \n for line feed, \r for carriage return, \t for horizontal tab, and \uXXXX for a Unicode UTF-16 code unit.

Authors SHOULD normally enter Unicode characters directly when practical rather than replacing readable characters with \uXXXX escapes. Characters outside the Unicode Basic Multilingual Plane may be written directly or represented by the appropriate JSON surrogate-pair escapes.

```json
{
  "runs":
  [
    {
      "text": "Midori reads the sign: "
    },
    {
      "text": "立入禁止",
      "font":
      {
        "role": "printed"
      },
      "color": "red"
    }
  ]
}
```

### Rendered Examples

The following examples demonstrate the intended visual effect of runs. They are illustrations of SBL Text formatting, not complete SBL scene definitions. Exact physical fonts may vary by renderer; semantic formatting such as emphasis, handwriting, relative size, color, superscript, and Unicode text should remain recognizable.

#### Handwritten font role

A run with font.role set to "handwritten" requests handwriting-like lettering. The renderer may substitute an available handwritten font while preserving the visual role.

#### Reusable warning style

A named warning style can combine boldface, increased relative size, and red text. The run itself need only reference that style.

#### Mixed color and emphasis

Runs allow formatting to change within one textual value. Here the first run is red and italic while the second returns to ordinary black text.

#### Unicode text

Unicode characters may appear directly in a run. The renderer should choose a font capable of representing the requested characters while respecting other run properties.

#### Superscript

The align value "super" raises a run above the normal baseline. A smaller relative size is normally appropriate for mathematical exponents.

#### Mixed italic emphasis

Separate runs can emphasize individual words without changing the rest of the sentence.

## Machine-Readable Identifiers and Human-Readable Names

SBL deliberately distinguishes machine-readable identifiers from human-readable names and titles. A machine-readable identifier is used by SBL processors to refer unambiguously to one script, page, panel, character, object, resource, event, or other addressable entity. A human-readable name is intended for people and may contain spaces, punctuation, capitalization, and wording chosen for readability.

For example, "IAKESI-CH12" is a suitable machine identifier for a script whose human-readable title is "Chapter 12". Likewise, two different characters may both legitimately have the human-readable name "John Smith", but two simultaneously visible declarations within the same scope MUST NOT use the same machine id. SBL references use machine ids rather than human-readable names so that duplicate names, renamed characters, translations, and spelling variations do not create ambiguity.

SBL 1.0 machine-readable id components MUST use only ASCII letters (A-Z, a-z), decimal digits (0-9), hyphen (-), underscore (_), and period (.). An id component MUST begin with an ASCII letter or digit, MUST contain at least one character, and MUST NOT contain whitespace, colons, quotation marks, slashes, backslashes, semicolons, commas, braces, brackets, parentheses, or other punctuation. Identifiers are case-sensitive: "Midori", "midori", and "MIDORI" are different ids. Authors SHOULD choose one capitalization convention and use it consistently.

Recommended local ids include "student_1", "book_1", "P40", "S3", and "academy.corridor". Human-readable fields such as "title", "subtitle", and "name" are not subject to machine-id syntax and may contain ordinary Unicode text appropriate to the document language.

An unqualified id reference is resolved lexically. A declaration is visible within the object that defines it and within descendant scopes unless a narrower declaration overrides or suppresses it. For example, a character declared at page scope may be referenced by its local id from panels on that page. A panel-local object is local to that panel and its descendants.

Different scopes may reuse the same local id. For example, page "P40" and page "P41" may each declare a different anonymous character with id "student_1". Within either page, the unqualified reference "student_1" resolves to the declaration visible in that page scope. This allows short, convenient local identifiers without requiring every transient entity in a long production to have a globally unique id.

When a reference must identify an entity declared in a different scope, SBL uses the double-colon operator (::) to form a qualified reference. The colon characters are reference syntax and are NOT part of the underlying machine ids. Thus "P40::student_1" means the entity whose local id is "student_1" in the scope identified by "P40".

Qualification may contain multiple components. For example, "IAKESI-CH12::P40::S3::book_1" identifies "book_1" by traversing the scopes "IAKESI-CH12", "P40", and "S3" from left to right. Each component MUST identify a containing SBL object visible to the resolver, and the final component identifies the referenced entity within that scope.

A qualified reference MUST resolve to exactly one entity. An unknown qualifier, a missing final id, or an ambiguous scope path is a resolution error. A resolver MUST NOT guess which similarly named entity was intended.

Machine ids SHOULD remain stable even when the associated human-readable name or title changes. Qualified references are composed from those stable ids, so renaming a human-readable title or character name does not invalidate references.

## Metadata

Metadata describes the document but normally does not directly control rendering. Most metadata fields are optional.

The "author" field is an array of strings rather than a single string because an SBL document may have multiple authors. Even when there is only one author, the value remains an array. The order of elements in the array is significant for display: authors should be listed in the order in which they should appear in credits. This is the first example in this specification of an array containing multiple elements.

A single-author script uses a one-element array:

```json
"author":
[
  "Randall Hyde"
]
```

A script with several authors places each author in the same array, separated by commas:

```json
"author":
[
  "Randall Hyde",
  "Jane Smith",
  "Akira Tanaka"
]
```

In JSON, the square brackets delimit the array. Each quoted name is one array element, and commas separate adjacent elements. The final element is not followed by a comma. The same array syntax is used elsewhere in SBL for lists of pages, panels, characters, dialogue items, resources, and other repeated values.

The "description" field is SBL Text. For ordinary descriptions, a JSON string is usually simplest; displayed line or paragraph breaks use the JSON escape sequence "\n". When word-level formatting is required, "description" may instead use the SBL Text "runs" representation. JSON does not permit an unescaped literal line break inside a quoted string.

The "language" field is informative and identifies the primary natural language/locale of the script. SBL recommends familiar language-region tags such as "en-US", "en-GB", "ja-JP", "fr-FR", and "ar-SA". Modern systems commonly use BCP-47-style identifiers, but operating-system locale representations are not perfectly uniform. SBL does not require an exact OS locale match; this field is mainly informative.

ISO 8601 is the international standard for representing dates and times unambiguously. For SBL metadata, "created" and "modified" MUST use calendar-date form YYYY-MM-DD, for example "2026-08-21".

Locale references: Windows/Microsoft; macOS/Apple; Linux locale(7).

Possible future metadata extensions include copyright, license, revision notes, production status, and other publishing information. These should not be required by the core blocking language.

## Format / Media Profile

The "format" object selects media-specific semantics. SBL 1.0 normatively defines three static page/panel profiles: "manga", "comic", and "storyboard". Many core constructs are intentionally media-independent and are expected to be reused by future profiles, but their presence in SBL 1.0 does not imply that SBL 1.0 defines a complete production grammar for every visual medium.

Requirements — Under the Source SBL validation profile, "format" is OPTIONAL. Under the Renderable Source SBL profile, "format" is REQUIRED. Whenever "format" is present, "medium" is REQUIRED and MUST be a supported SBL 1.0 media value. "reading_direction" is optional.

```json
"format":
{
  "medium": "manga",
  "reading_direction":
  [
    "left_to_right",
    "top_to_bottom"
  ]
}
```

### medium

The "medium" field selects the applicable SBL media profile. SBL 1.0 standard values are "manga", "comic", and "storyboard". The manga and comic profiles use pages, layout regions, logical panels, panel content, dialogue balloons, narration, SFX, and the other sequential-art constructs defined by this specification. The storyboard profile uses the same page/panel grammar for static storyboard work; each logical panel represents one storyboard frame or shot depiction. SBL 1.0 does not yet define structured temporal shot duration, camera movement over time, transitions, animation timing, keyframes, or audio synchronization. Until a future SBL version or storyboard-specific extension defines those constructs, storyboard authors MAY record necessary temporal guidance in "direction" records, especially records whose "type" is "temporal". Such direction text is preserved as production guidance but does not create formal timing or camera-motion semantics. The values "animation", "film", "television", and "stage" are reserved for anticipated future SBL profiles and are not conforming SBL 1.0 media values. A core SBL 1.0 processor encountering one of those reserved values MUST report an unsupported-media-profile error rather than silently interpreting it as manga, comic, or storyboard.

### reading_direction

For the manga, comic, and storyboard profiles, "reading_direction" is an optional ordered array containing one or two values. Allowed values are "left_to_right", "right_to_left", "top_to_bottom", and "bottom_to_top". The first array value is the primary progression and the second, when present, is the secondary progression. The same value MUST NOT appear twice. When two values are supplied, they MUST describe different axes: one horizontal direction ("left_to_right" or "right_to_left") and one vertical direction ("top_to_bottom" or "bottom_to_top"). Examples include ["left_to_right", "top_to_bottom"] for typical Western flow, ["right_to_left", "top_to_bottom"] for many Japanese manga layouts, and ["top_to_bottom", "right_to_left"] for traditional vertical East Asian layouts. Storyboards normally use the reading direction appropriate to the storyboard sheet or production convention. If "reading_direction" is omitted, SBL imposes no reading-direction default; the renderer or consuming workflow may use its own convention only where that choice does not contradict explicit panel links or other required structure.

## Defaults

Defaults provide project-wide production and rendering policy that is inherited by lower-level structures. SBL 1.0 deliberately limits defaults to a small set of production-oriented properties. Defaults MUST NOT be used to create story state such as characters, objects, poses, actions, dialogue, events, or blocking.

The "defaults" object has two optional members: "page" and "panel". Each member contains only properties that are explicitly defaultable at that scope.

```json
"defaults":
{
  "page":
  {
    "canvas":
    {
      "width": 1024,
      "height": 1536,
      "units": "pixels"
    },
    "panel_numbers":
    {
      "display": false
    }
  },
  "panel":
  {
    "camera":
    {
      "angle": "eye_level"
    },
    "lighting":
    {
      "mode": "clear"
    },
    "background":
    {
      "mode": "environment",
      "style": "normal"
    }
  }
}
```

defaults.page

The allowed SBL 1.0 properties in "defaults.page" are "canvas", "production_areas", "page_side", and "panel_numbers". These establish production-wide page policy. A page-local value overrides the corresponding page default.

defaults.panel

The allowed SBL 1.0 properties in "defaults.panel" are "camera", "composition", "lighting", "perspective", and "background". These establish production-wide visual/rendering policy for panels. A panel-local value overrides the corresponding panel default.

Defaults MUST NOT contain "id", "description", "imports", "inherit", "characters", "objects", "blocking", "orientation", "pose", "expression", "actions", "events", "dialogue", "narration", "sfx", "effects", "visibility", "interactions", "relationships", "eyelines", "continuity", "motion", "text_objects", "render_layers", or "render_passes". Those constructs represent identity, scene state, story content, continuity, or production structure and must use their normal declaration, cascade, and inheritance mechanisms.

Defaults and text_styles

"text_styles" is not part of "defaults". Reusable typography already has its own lexical-scope mechanism. A script, page, panel, or imported library may declare text_styles, and narrower declarations with the same style id override broader ones according to the text-style rules.

Resolution order

For page properties, the resolver applies SBL normative defaults first, then "script.defaults.page", then page-local properties. For panel properties, it applies SBL normative defaults first, then "script.defaults.panel", then applicable page-level declarations, then explicit panel inheritance, then panel-local properties. A directly authored narrower value therefore overrides a script default.

Defaults are resolver input, not renderer memory. Before an independently rendered page or panel is submitted to a renderer, a conforming resolver SHOULD expand applicable defaults into the resolved unit so correctness does not depend on an image generator remembering a root-level instruction from earlier work.

Normative SBL defaults versus authored defaults

The language-defined defaults listed later in §21.14, Core Defaults, are normative semantics that apply when a field is omitted. They are not members of the source document's "defaults" object. For example, camera.angle="eye_level" is a language default even when no "defaults" object exists; an authored "defaults.panel.camera.angle" merely lets a project choose a different broad camera policy.

## Renderable Content

For the manga, comic, and storyboard profiles, the root script contains the required "pages" array, whose grammar is defined in this specification. Each page entry defines the page-level visual structure or "look and feel": canvas size and production areas, the number of panels, their relative sizes and shapes, their arrangement and placement, and other page-level presentation information. Within each page, the panel definitions contain the information normally associated with a script: setting, characters, objects, blocking, action, camera, dialogue, effects, lighting, continuity, and related rendering constraints. Detailed page and panel definitions appear later in this document.

```json
"pages":
[]
```

## Source Script vs. Resolved Representation

SBL should distinguish between the compact source document authored by a human and the resolved representation supplied to a renderer.

Conceptual processing pipeline:

Source Script JSON  →  SBL Resolver  →  Self-Contained Page/Panel JSON  →  Renderer or Image Generator

The resolver is responsible for applying script defaults, inherited state, referenced resources, and other contextual information. The resulting page or panel should contain everything required for that rendering operation. This architecture avoids depending on an AI model or renderer to retain the global state of a long script.

## Core Design Principles

a. Keep the script/root level relatively thin.

The root should establish production-wide identity, metadata, reusable resources, and broad defaults without becoming a dumping ground for panel-specific detail. Keeping it thin makes large scripts easier to resolve in smaller units and reduces the amount of global state that must be carried into every render.

b. Use stable machine identifiers separately from human-readable titles.

Machine identifiers exist for unambiguous references and should remain stable even when a chapter, character, location, or other entity is renamed for readers. Human-readable titles and names can change, be translated, or even be duplicated; machine ids should not.

c. Distinguish the SBL specification version from the script document version.

These versions answer different questions. The SBL specification version determines which language syntax and semantics a processor must understand, while the script document version identifies a revision of the particular production file. Keeping them separate prevents a script revision from being confused with a language revision.

d. Treat metadata as descriptive unless a field explicitly affects rendering.

Metadata primarily identifies and documents the production rather than describing what should appear in an image. This separation prevents fields such as author, creation date, or document revision from accidentally acquiring rendering semantics.

e. Use the medium field to select a media-specific language profile.

Different visual media need different concepts. Manga and comics emphasize pages, panels, balloons, and reading direction; film and animation may require shots, duration, lenses, and camera movement; stage work uses theatrical position terminology. The medium field tells a processor which profile and conventions apply.

f. Allow script-level defaults, but do not require a renderer to remember them.

Defaults reduce repetition in Source SBL, but current generative systems cannot be trusted to remember a global instruction across a long production. A resolver should expand important defaults into the page or panel being rendered so correctness does not depend on long-term model memory.

g. Resolve global and inherited state before submitting an individual renderable unit.

A renderer should receive the effective scene rather than being expected to reconstruct imports, defaults, inheritance, overrides, and suppression itself. Resolution makes the render request explicit and deterministic before image generation begins.

h. Ensure that a resolved page or panel can be processed independently.

Independent processing is essential for long projects and repeated regeneration. A panel rendered hundreds of pages into a production should contain or reference everything it needs without depending on the renderer remembering earlier conversations or images.

i. Prefer external references for large reusable resources such as character sheets and location definitions rather than embedding them repeatedly.

Character sheets, location definitions, style references, and similar assets may be large and reused many times. Stable external resources avoid duplication, reduce SBL document size, and allow the resolver to provide only the assets relevant to the current render target.

## Units and Numeric Quantities

SBL uses several kinds of numeric quantities. A number MUST have an unambiguous interpretation from either its field definition or an accompanying unit field. Authors and processors MUST NOT assume that an otherwise undefined number means pixels, meters, degrees, or any other physical unit.

Normalized coordinates and normalized scalar values are unitless. Unless a field states another range, normalized screen/page coordinates use 0.0 through 1.0. Pixel dimensions are identified by a surrounding or companion "units": "pixels" declaration. Physical dimensions such as character height SHOULD use an explicit unit such as "cm", "m", "in", or "ft". Angles are expressed in degrees when a field is defined as an angle. Color temperature is expressed in kelvins. Exact clock times use the textual HH:MM form rather than a numeric quantity.

A field whose definition supplies its own semantic scale does not need a separate units member. Examples include lighting intensity from 0.0 through 1.0, normalized screen coordinates, normalized stage elevation, and relative text size where 1.0 means normal size. A numeric quantity representing an exact physical story-world distance MUST either use a field whose unit is intrinsically defined by SBL or use a physical-quantity object containing "value" and "units". SBL 1.0 physical-distance units are "mm", "cm", "m", "in", and "ft". A conforming resolver MAY convert among compatible units.

Example physical quantity:

```json
{
  "value": 1.5,
  "units": "m"
}
```

### Normalized Screen Placement

Several graphical constructs may use a reusable "placement" object to identify an anchor point in normalized panel/screen coordinates. "x" and "y" are unitless values from 0.0 through 1.0: x=0.0 is the left edge, x=1.0 the right edge, y=0.0 the top edge, and y=1.0 the bottom edge. The coordinates identify the selected anchor point of the graphical object rather than its upper-left corner.

```json
{
  "placement":
  {
    "x": 0.78,
    "y": 0.42,
    "anchor": "center"
  }
}
```

"anchor" is optional and defaults to "center". Standard anchors are "top_left", "top_center", "top_right", "middle_left", "center", "middle_right", "bottom_left", "bottom_center", and "bottom_right". A graphical construct that omits placement leaves its screen position to the renderer unless another rule supplies it.

Normalized screen y and stage elevation deliberately use the same 0.0-through-1.0 numeric range but describe different coordinate systems. screen y describes vertical placement in the rendered image; stage elevation describes physical story-world height above the stage floor. A resolver MUST NOT treat them as interchangeable.

## Page Objects

Page requirements — A renderable SBL 1.0 page MUST contain a stable "id", a renderable "canvas", a "layout", and a non-empty "panels" array. Production areas, page side, printed page numbering, panel numbering, insets, panel links, text styles, and visual_continuity are optional unless another selected feature requires them.

For the manga, comic, and storyboard profiles, a page object defines the complete generated canvas, print-production regions, page numbering, panel numbering, panel topology, optional links between panels, and the array of panel-content objects. Page-level production information is deliberately allowed to be redundant with script defaults so that a resolved page can be rendered independently.

### Minimal Page Example

This example is the smallest complete renderable page currently permitted by the SBL manga, comic, and storyboard profiles. It defines one page containing one row and one panel. The panel itself contains no scene content.

```json
{
    "script": {
        "id": "SBL-EXAMPLE-001",
        "title": "Minimal Page",
        "specification": {
            "name": "SBL",
            "version": "1.0"
        },
        "format": {
            "medium": "manga"
        },
        "pages": [
            {
                "id": "P1",
                "canvas": {
                    "width": 1024,
                    "height": 1536,
                    "units": "pixels"
                },
                "layout": {
                    "type": "rows",
                    "rows": [
                        {
                            "height_weight": 1,
                            "panels": [
                                {
                                    "id": "P1A",
                                    "width_weight": 1
                                }
                            ]
                        }
                    ]
                },
                "panels": [
                    {
                        "id": "P1A"
                    }
                ]
            }
        ]
    }
}
```

Example rendering:

The resulting image therefore contains only a single empty panel. Details not specified by the SBL source are left to the renderer unless SBL defines a default for them.

Related sections

a. Script structure and identification — see §5, Root Structure, §6, Script Identification, §7, Specification Identification.

b. Page identifiers — see §17.2, Page Identifier.

c. Canvas dimensions and coordinate system — see §17.3, Canvas.

d. Row and panel layout — see §17.8, Panel Layout.

e. Layout margins and gutters — see §17.9, Margins and Gutters.

f. Relationship between layout positions and panel content — see §17.12, Panel Contents.

g. Panel objects and their contents — see §18, Panel Content.

h. SBL defaults and unspecified properties — see §21.14, Core Defaults.

i. Structural requirements imposed by the JSON Schema — see §24, Structural Validation and JSON Schema.

### Page Identifier

Requirements — "id" is REQUIRED for every page and MUST satisfy the SBL machine-id rules.

Every page MUST have a stable machine-readable id. This identifier is independent of the page number printed for the reader.

```json
{
  "page":
  {
    "id": "CH12-P40"
  }
}
```

### Canvas

Requirements — A renderable page "canvas" MUST contain numeric "width" and "height" greater than zero and "units". For the SBL 1.0 bitmap page model, "units" MUST be "pixels".

canvas.width and canvas.height specify the dimensions of the entire generated image, including any bleed area. They do not specify the trim size. This is the authoritative output bitmap size requested from the renderer or image generator.

```json
{
  "canvas":
  {
    "width": 1024,
    "height": 1536,
    "units": "pixels"
  }
}
```

All absolute pixel coordinates on a page are measured relative to this full canvas. The coordinate origin (0,0) is the upper-left corner of the generated image. Normalized screen/page coordinates use the same orientation: x=0.0 is the left edge, x=1.0 is the right edge, y=0.0 is the top edge, and y=1.0 is the bottom edge. Normalized screen coordinates describe graphical placement in the rendered panel/page and are distinct from physical stage elevation.

Practical generator limits — SBL canvas dimensions describe the desired output bitmap; they do not guarantee that the selected image-generation backend can produce those dimensions natively. Image generators may restrict native pixel dimensions, aspect ratios, and maximum resolution. A renderer MUST NOT assume that an arbitrary SBL canvas size can be requested directly from every backend.

When the selected backend cannot natively produce the requested canvas, the renderer MAY generate at a supported size or aspect ratio and then resize, crop, pad, or upscale the result to satisfy the SBL production dimensions. For example, a 6 × 9 inch print page at 600 DPI requires a 3600 × 5400 pixel trim image, while an image generator may natively provide only a much smaller portrait image such as 1024 × 1536. The post-processing stage is responsible for producing the requested final dimensions without changing the intended composition or production constraints.

Backend capabilities are implementation-dependent and may change over time. At the time of this draft, OpenAI image generation commonly exposes native outputs such as 1024 × 1024, 1024 × 1536, and 1536 × 1024 rather than arbitrary dimensions. Image generators may also have practical limitations with dense text, multilingual text, multiple faces, and strict reference-image fidelity. Reference image inputs may have upload-size limits and may be internally resized before model processing. Renderers SHOULD account for these limitations rather than treating them as SBL language restrictions.

### Production Areas

Requirements — "production_areas" is optional. Each supplied region ("bleed", "trim", or "safe") MUST contain numeric "x", "y", "width", and "height" in the canvas units, with positive width/height. Regions MUST be geometrically meaningful within the production workflow; the resolver SHOULD report impossible or contradictory regions.

The page may explicitly define bleed, trim, and safe areas within the full canvas. These values belong in the resolved page even when equivalent defaults exist at script level, because a page should contain all production constraints needed to render it independently.

For a more detailed discussion of print-production requirements and the practical reasons for these areas, see The IAKESI Project.

```json
{
  "production_areas":
  {
    "bleed":
    {
      "x": 0,
      "y": 0,
      "width": 1024,
      "height": 1536
    },

    "trim":
    {
      "x": 24,
      "y": 24,
      "width": 976,
      "height": 1488
    },

    "safe":
    {
      "x": 72,
      "y": 72,
      "width": 880,
      "height": 1392
    }
  }
}
```

The bleed area normally extends to the canvas boundaries. The trim area represents the intended finished page after trimming. The safe area identifies the region in which critical content such as dialogue, page numbers, faces, and important visual elements MUST remain.

**Binding composition rule.** Production-area geometry is invisible in finished artwork but is NOT postprocessing-only metadata. When `production_areas` is supplied, it is binding composition geometry. A renderer MUST use it while composing the page even though trim/safe/bleed guides themselves MUST NOT be drawn unless an explicit diagnostic render requests them. Backgrounds and other noncritical artwork MAY extend through the safe boundary toward trim or bleed.

**Whole-object safe-area rule.** Critical graphical containers MUST fit wholly inside the safe rectangle, not merely their text glyphs or semantic anchor points. This includes the visible bodies/borders of speech balloons, thought balloons, narration boxes, captions, and printed folios. Balloon/thought tails MAY extend outside the safe rectangle when necessary to identify the speaker, but the balloon body and its lettering MUST remain inside. Faces and continuity-critical props SHOULD also remain wholly inside the safe rectangle unless the script explicitly authorizes intentional cropping.

**Page-specific prompt rule.** A renderer-facing prompt compiler MUST emit the resolved numeric safe rectangle and resolved page side whenever `production_areas.safe` is present. For bitmap pages it SHOULD state the inclusive boundaries in canvas coordinates (for example, `SAFE CONTENT RECTANGLE: x=75..886, y=81..1454; verso; binding right`) and explicitly state that the geometry constrains composition but must not be visibly drawn.

**Print-safety preflight.** Before final rendering/compositing, a conforming renderer SHOULD preflight every critical element for which it has estimated or explicit graphical bounds. If a speech/thought balloon body, narration box, caption, folio, face, or continuity-critical prop would cross the safe boundary, the renderer SHOULD reflow, reposition, resize, or otherwise revise the layout before rendering. If the violation cannot be resolved without contradicting stronger authored requirements, it MUST report the conflict rather than silently treating the safe area as advisory. Automatic placement does not waive this requirement.


**Revision 133 AI print-safety extension.** The true `production_areas.safe` rectangle remains the final pass/fail boundary. A resolver SHOULD also derive `production_areas.render_safe`, wholly inside `safe`, using a conservative guard band (48 px by default for 1024×1536 IAKESI pages). `render_safe` is the image generator's target and exists to absorb nondeterministic placement drift.

**Visual composition guide.** The page packager SHOULD generate a temporary page-sized guide showing the smaller render-safe region in green and visibly blocking the surrounding placement-exclusion region. It MUST identify page/binding side. The image generator SHOULD use this guide as its PRIMARY spatial reference for speech balloons, narration, captions, folios, faces, and other critical content. The guide MUST NOT appear in final artwork.

**Automatic retry preflight.** After rendering, the workflow SHOULD create a diagnostic overlay of trim, true safe, and render-safe boundaries and inspect the actual rendered result. A failed page SHOULD receive a targeted placement correction and be rerendered without changing already-correct character, environment, camera, lighting, continuity, or panel-layout instructions. Recommended automatic retry limit: three.

**Composition zones.** Pages and panels MAY provide semantic `composition_zones` for dialogue, faces, or other critical content. Such zones guide AI composition and SHOULD remain inside `render_safe`; they do not replace the true production safe rectangle.

### Page Side

Requirements — "page_side" is optional. Legal values are "recto", "verso", "single", and "automatic". "automatic" requires sufficient sequence context whenever recto/verso affects required semantics.

The "page_side" property describes how a page participates in a bound or displayed page sequence. "recto" means a right-hand page in a conventionally bound book or spread; "verso" means a left-hand page. "single" means the page is treated as a standalone page with no left/right binding relationship, such as a cover, poster, isolated digital page, or individually rendered sheet. "automatic" asks the SBL resolver to determine recto or verso from the page sequence; it is the default when page-side behavior is needed but not explicitly supplied.

```json
"page_side": "automatic"
```

Examples: a conventional book page explicitly known to be on the right uses "recto"; its facing left-hand page uses "verso". A title image intended to be rendered by itself may use "single". A normally sequenced interior page may use "automatic" when the resolver has enough sequence context to determine the side. If a page is rendered without sufficient sequence context, "automatic" MUST NOT be guessed when recto/verso affects required semantics; the resolver should report the unresolved side or treat the page as "single" only when the caller explicitly requests that fallback.

### Page Numbering

Requirements — "page_number" is optional. When the object is present, "display" is optional and defaults to true. "value" is REQUIRED. value.mode is "explicit" or "sequential"; explicit mode requires "number". "style" and "position" are optional presentation controls.

Page numbering is independent of the page machine id. A page may suppress its printed number while retaining a stable id. For production work, SBL strongly recommends explicit page numbers because they are deterministic: regenerating the same page produces the same printed page number, and rendering a page in isolation does not depend on knowing which pages were processed previously. If "page_number" is omitted, no printed page number is requested. If "page_number" is present and "display" is omitted, display defaults to true.

```json
{
  "page_number":
  {
    "display": true,

    "value":
    {
      "mode": "sequential"
    },

    "style":
    {
      "type": "plain"
    },

    "position":
    {
      "horizontal": "outer_edge",
      "vertical": "bottom"
    }
  }
}
```

The "value.mode" field supports "explicit" and "sequential". "explicit" supplies the page number directly and is the RECOMMENDED mode. "sequential" means that the effective printed page number is derived from sequence context rather than stored directly in the page. Although legal, "sequential" is error-prone and of limited practical value: repeatedly regenerating a page, rendering only part of a script, beginning work in the middle of a script, or resolving a page without its preceding sequence can make the intended number unclear. A conforming resolver MUST derive a sequential number from document order/declared sequence state, never from the count of rendering attempts. If sufficient sequence context is unavailable, it MUST report the number as unresolved rather than inventing page 1 or incrementing a previous render.

```json
{
  "value":
  {
    "mode": "explicit",
    "number": 40
  }
}
```

Page-number style.type supports plain, chapter_page, roman_upper, roman_lower, and custom. A chapter_page style may include a configurable separator. A custom style may define implementation-specific formatting without changing the underlying page number.

```json
{
  "style":
  {
    "type": "chapter_page",
    "separator": "-"
  }
}
```

Position is expressed semantically where possible. Horizontal values should include left, center, right, outer_edge, and inner_edge. Vertical values should include top and bottom. outer_edge resolves to the left edge on a verso page and the right edge on a recto page; inner_edge resolves oppositely. When `production_areas.safe` is present, these semantic positions are anchored within the safe rectangle rather than against the canvas or trim boundary. A printed folio MUST be wholly inside the safe rectangle, including any backing/halo, and SHOULD include a small inward inset so it does not visually touch the safe boundary.

When pages are inserted, deleted, or reordered, an author may renumber explicit printed page numbers manually or ask a generative-AI/editor tool to renumber them as a batch operation. This is generally straightforward because printed page numbers are presentation data, not machine identity. Machine ids SHOULD remain stable during such renumbering unless the author deliberately chooses to rename them.

Cross-references are therefore a separate issue from printed page numbering. A qualified reference such as "P40::student_1" refers to the machine id "P40", not to whichever page currently displays the number 40. Changing a printed page number does not break that reference. Deleting the page whose machine id is "P40", however, leaves the reference unresolved and MUST be reported as a reference error. Likewise, renaming the machine id itself requires updating references to that id.

### Panel Numbering

Requirements — "panel_numbers" is optional. When present, "display" is REQUIRED and Boolean. In SBL 1.0 it applies page-wide to all logical panels on that page.

Panel identifiers are always machine-visible, but printed panel numbers are optional. A page-level setting provides the default behavior for panels on that page.

```json
{
  "panel_numbers":
  {
    "display": false
  }
}
```

The page-level "panel_numbers.display" value applies to every panel on that page in SBL 1.0. If "panel_numbers" is omitted, SBL requests no printed panel numbers.

### Panel Layout

Requirements — A renderable SBL 1.0 page MUST contain "layout". layout.type MUST be "rows" and "rows" MUST be a non-empty array. Each row MUST contain positive "height_weight" and a non-empty "panels" array. Each layout-region entry MUST contain a unique "id" and positive "width_weight".

The SBL 1.0 manga/comic/storyboard layout model is row based. The number of entries in rows determines the number of rows; a separate row_count is unnecessary. Likewise, the number of panel entries in a row determines the number of panel positions in that row.

Relative dimensions are expressed as weights rather than absolute panel pixel sizes. height_weight controls the relative height of a row, while width_weight controls the relative width allocated to a panel position.

```json
{
  "layout":
  {
    "type": "rows",

    "rows":
    [
      {
        "height_weight": 1,

        "panels":
        [
          {
            "id": "P1",
            "width_weight": 1
          },
          {
            "id": "P2",
            "width_weight": 2
          }
        ]
      },

      {
        "height_weight": 1,

        "panels":
        [
          {
            "id": "P3",
            "width_weight": 1
          },
          {
            "id": "P4",
            "width_weight": 1
          }
        ]
      }
    ]
  }
}
```

The following example shows a simple three-row page layout. The first row has relative height 1 and contains two equal-width panels. The second row has relative height 1 and contains one full-width panel. The third row has relative height 2 and contains one full-width panel. Because row heights are relative, the third row receives twice as much vertical space as either of the first two rows.

```json
"layout":
{
  "type": "rows",
  "rows":
  [
    {
      "height_weight": 1,
      "panels":
      [
        {
          "id": "P1A",
          "width_weight": 1
        },
        {
          "id": "P1B",
          "width_weight": 1
        }
      ]
    },
    {
      "height_weight": 1,
      "panels":
      [
        {
          "id": "P1C",
          "width_weight": 1
        }
      ]
    },
    {
      "height_weight": 2,
      "panels":
      [
        {
          "id": "P1D",
          "width_weight": 1
        }
      ]
    }
  ]
}
```

The two entries in the first row divide that row equally because both have width_weight 1. The second and third rows each contain a single panel, so each panel occupies the full available row width. The row height weights 1, 1, and 2 divide the available vertical space into four relative units.

### Margins and Gutters

Requirements — layout "margin" and "gutter" are optional. Supplied margin components (top, bottom, left, right) and gutter components (horizontal, vertical) MUST be non-negative numeric values in canvas units. Omitted components impose no additional spacing requirement.

A row layout should be able to specify the usable page margin and the space separating panels. These are layout properties and are distinct from safe, trim, and bleed production areas. The example includes one minimal row so that it remains structurally valid SBL while illustrating margin and gutter syntax.

```json
{
  "layout":
  {
    "type": "rows",

    "margin":
    {
      "top": 24,
      "bottom": 24,
      "left": 24,
      "right": 24
    },

    "gutter":
    {
      "horizontal": 12,
      "vertical": 12
    },

    "rows":
    [
      {
        "height_weight": 1,
        "panels":
        [
          { "id": "P1", "width_weight": 1 }
        ]
      }
    ]
  }
}
```

The figure below shows the distinction between page margins and gutters. Margins reserve space between the page edge and the usable panel layout. Gutters are the spaces between neighboring panels. Horizontal and vertical gutters may be specified independently.

### Merging Layout Regions

Requirements — Panel "merge" is optional. When present it MUST be a non-empty array of unique layout-region ids on the same page. Every referenced region MUST exist and a layout region MUST NOT belong to more than one merged logical panel.

A panel normally occupies one rectangular layout region. The panel-level "merge" property allows one logical panel to occupy two or more layout regions. This supports ordinary rectangular spans as well as L-shaped, T-shaped, and even disconnected panel shapes.

Consider a 2×2 layout with four regions: P1 and P2 on the first row, and P3 and P4 on the second. The following logical panel occupies regions P2, P3, and P4:

```json
{
  "id": "P_MERGED",
  "merge":
  [
    "P2",
    "P3",
    "P4"
  ]
}
```

The image supplied for P_MERGED is NOT sized independently for P2, P3, and P4. The renderer first finds the smallest rectangle that contains every region in the "merge" array. For P2+P3+P4 in a 2×2 layout, that bounding rectangle is the entire 2×2 panel area. The panel image must therefore be large enough and composed appropriately for that full bounding rectangle.

The following synthetic source image represents the image supplied for P_MERGED. It is intentionally a large composition because portions of it will be visible in three different layout regions.

The visible area of P_MERGED is the union of P2, P3, and P4. P1 is not in the merge, so P1 remains an independent panel above the merged image and clips the upper-left portion of that image. This produces an inset-like result: the merged image exists behind the full 2×2 area, but only the merged regions reveal it.

Gutters and internal panel borders that would normally separate adjacent regions disappear when those regions belong to the same merged panel. Only the outer boundary of the merged visible area and boundaries against independent panels remain. In this example, there is no P2/P4 gutter and no P3/P4 gutter. The borders around P1 remain because P1 is an independent panel.

Image size matters. Supplying an image intended only for a single small region and then stretching it across the full merge bounding rectangle may cause excessive scaling, poor composition, or loss of useful detail. The source artwork should therefore be generated or selected with the complete merge bounding rectangle in mind.

A "merge" may also contain disconnected regions. For example, merging P2 and P3 in the same 2×2 layout is legal. The image is still composed once for the full 2×2 bounding rectangle. P1 and P4 then clip the image, leaving P2 and P3 as two disconnected visible windows onto the same underlying image. SBL does not invent a connection between the two visible regions.

```json
{
  "id": "P_MERGED",
  "merge":
  [
    "P2",
    "P3"
  ]
}
```

Each entry in "merge" MUST identify an existing layout region on the same page. Duplicate region ids in one merge are invalid. A layout region MUST NOT belong to more than one merged logical panel. A missing or ambiguous region reference is a resolution error. The order of ids in the array has no effect on geometry or stacking.

Independent panels whose regions fall inside a merged panel's bounding rectangle appear above the merged panel by default and therefore clip it. This default is what allows ordinary panels to function naturally as insets into irregular merged panels.

### Inset Panels

Requirements — The page-level "insets" array is optional. Each inset MUST contain a stable "id" and a "placement" object. An inset is a page-level panel-like object whose geometry is explicitly positioned over the normal page layout. It does not occupy a layout region and does not participate in row sizing or gutters. An inset uses the normal panel-content vocabulary where applicable, but its geometry is established by "placement" rather than by the page layout.

The "placement" object reuses the normalized coordinate and anchor vocabulary defined in Normalized Screen Placement. For an inset, "relative_to" MUST be a non-empty array of logical panel ids on the current page. The listed panels establish the reference rectangle used by the inset's normalized placement.

```json
{
  "insets":
  [
    {
      "id": "I1",
      "placement":
      {
        "relative_to":
        [
          "P1"
        ],
        "x": 0.78,
        "y": 0.22,
        "anchor": "center",
        "width": 0.30,
        "height": 0.25
      },
      "camera":
      {
        "shot": "close_up"
      },
      "characters":
      [
        {
          "id": "midori"
        }
      ]
    }
  ]
}
```

When "relative_to" contains one panel id, the reference rectangle is that panel's visible rectangle. When it contains multiple panel ids, the reference rectangle is the smallest page-aligned rectangle containing all listed panels, including intervening gutters or other layout space. "x" and "y" are normalized coordinates in the reference rectangle and identify the point selected by "anchor". "width" and "height" are normalized fractions of the reference rectangle's width and height. They MUST be greater than 0 and MAY be greater than 1.0.

An inset is rendered above the normal page layout and MAY overlap panel artwork, panel borders, and gutters. Inset artwork MUST be clipped to the inset's own visible boundary unless another applicable panel-style rule explicitly permits content to escape that boundary. Insets are rendered in array order; when two insets overlap, a later inset is rendered above an earlier inset. The underlying panels remain independent logical panels and are not merged or otherwise modified by the inset.

"relative_to" establishes geometry only. It does not establish scene inheritance, character inheritance, continuity, or semantic containment. An inset obtains content and inherited state through the same mechanisms available to ordinary panel content.

Inset reading order — An inset does not have an independently fixed position in page reading order. After layout, the inset is associated with every logical panel whose visible rectangle it geometrically intersects. The inset MAY be read immediately before or immediately after any such intersected panel according to the natural visual flow of the rendered page.

Authoring guidance — An author MUST NOT rely on an inset for a more precise reading-order relationship. If content must occur at a specific point in the semantic panel sequence, that content SHOULD be represented as a normal panel rather than an inset.

```json
{
  "id": "I2",
  "placement":
  {
    "relative_to":
    [
      "P1",
      "P2"
    ],
    "x": 0.50,
    "y": 0.50,
    "anchor": "center",
    "width": 0.35,
    "height": 0.30
  },
  "camera":
  {
    "shot": "extreme_close_up"
  },
  "characters":
  [
    {
      "id": "midori"
    }
  ]
}
```

Because I2 is positioned relative to both P1 and P2, its normalized coordinate system is the bounding rectangle containing both panels and the gutter between them. The inset may therefore span the gutter without merging P1 and P2.

### Panel Links and Arrows

Requirements — "panel_links" is optional and SHOULD be used only when reading order is otherwise genuinely unclear. Each link MUST contain stable "id", "from", "to", and "type". SBL 1.0 defines "arrow" as the standard visible link type; from/to MUST resolve to logical panels on the page.

Panel links describe an explicit relationship between logical panels and are separate from panel geometry. The most common use is to draw arrows that guide the reader through a non-obvious reading order. Because links refer to logical panels, they remain meaningful even when a panel is formed by merging several layout regions.

Consider a page whose underlying layout is a 3×3 grid of nine equal regions. To make the distinction between layout geometry and logical panels explicit, the grid regions are named R1 through R9. Five logical panels are then formed: P12 merges R1+R2, P36 merges R3+R6, P45 merges R4+R5, P78 merges R7+R8, and P9 occupies R9.

```json
{
  "layout":
  {
    "type": "rows",
    "rows":
    [
      {
        "height_weight": 1,
        "panels":
        [
          { "id": "R1", "width_weight": 1 },
          { "id": "R2", "width_weight": 1 },
          { "id": "R3", "width_weight": 1 }
        ]
      },
      {
        "height_weight": 1,
        "panels":
        [
          { "id": "R4", "width_weight": 1 },
          { "id": "R5", "width_weight": 1 },
          { "id": "R6", "width_weight": 1 }
        ]
      },
      {
        "height_weight": 1,
        "panels":
        [
          { "id": "R7", "width_weight": 1 },
          { "id": "R8", "width_weight": 1 },
          { "id": "R9", "width_weight": 1 }
        ]
      }
    ]
  },

  "panels":
  [
    {
      "id": "P12",
      "merge":
      [
        "R1",
        "R2"
      ]
    },
    {
      "id": "P36",
      "merge":
      [
        "R3",
        "R6"
      ]
    },
    {
      "id": "P45",
      "merge":
      [
        "R4",
        "R5"
      ]
    },
    {
      "id": "P78",
      "merge":
      [
        "R7",
        "R8"
      ]
    },
    {
      "id": "P9",
      "merge":
      [
        "R9"
      ]
    }
  ],

  "panel_links":
  [
    {
      "id": "L1",
      "from": "P12",
      "to": "P45",
      "type": "arrow"
    },
    {
      "id": "L2",
      "from": "P45",
      "to": "P36",
      "type": "arrow"
    },
    {
      "id": "L3",
      "from": "P36",
      "to": "P78",
      "type": "arrow"
    },
    {
      "id": "L4",
      "from": "P78",
      "to": "P9",
      "type": "arrow"
    }
  ]
}
```

The merge definitions establish the five visible panels. The "panel_links" array then defines the desired traversal independently of their physical placement. In this example the reading order is P12 → P45 → P36 → P78 → P9. Each link has its own machine id, identifies a source panel with "from", a destination panel with "to", and uses "type": "arrow" to request a visible directional arrow.

The arrows are rendered above the panel artwork as reading-order guides. Their exact path and curvature may be chosen by the renderer unless additional placement constraints are supplied, but each arrow MUST clearly originate from its "from" panel and point toward its "to" panel without reversing the intended order.

Panel links are useful when the visual layout alone does not make reading order obvious. They should not be required for ordinary pages whose reading order is already unambiguous. A link does not change panel geometry, merge membership, or scene content; it only expresses a relationship between the completed logical panels.

NOTE — PANEL LINKS ARE FOR EMERGENCY USE ONLY!

If the reader cannot easily determine which panel should be read next using the normal reading conventions of the script's language and medium, that is usually evidence of a page-design problem. The preferred solution is to redesign the page so that panel placement, shape, spacing, and visual flow make the intended reading order obvious. A panel link should be treated as a last-resort corrective device, not as a substitute for clear page composition.

In other words, use panel links only when an unusual layout genuinely requires them or when redesigning the page is impractical. If arrows are routinely required to explain how to read a page, fix the layout rather than relying on the arrows.

### Panel Contents

Requirements — A renderable page MUST contain a non-empty "panels" array. Each panel element MUST contain a stable "id". A logical panel must occupy at least one layout region, either by corresponding directly to a layout-region id or through its "merge" array. Layout/content references MUST resolve consistently.

Panel topology and panel content are separate concerns. The layout allocates page regions by panel id; the panels array contains the actual scene, blocking, camera, dialogue, effects, and other content for each panel. The id joins a content object to its layout position.

```json
{
  "panels":
  [
    {
      "id": "P1"
    },
    {
      "id": "P2"
    },
    {
      "id": "P3"
    }
  ]
}
```

The detailed panel-content grammar will be defined in the next level of the specification.

### Complete Page Skeleton

The following example brings the page-level pieces together in one place. It is a skeleton rather than a complete story page: it defines the physical page, print-production areas, numbering behavior, layout regions, one merged panel, optional panel links, and the logical panels themselves. The scene content inside those panels is intentionally minimal because the next major section explains panel content in detail.

The page-level entries used below are defined in Page Identifier, Canvas, Production Areas, Page Side, Page Numbering, Panel Numbering, Panel Layout, Margins and Gutters, Merging Layout Regions, Inset Panels, Panel Links and Arrows; and Panel Contents.

```json
{
  "page":
  {
    "id": "CH12-P40",

    "canvas":
    {
      "width": 1024,
      "height": 1536,
      "units": "pixels"
    },

    "production_areas":
    {
      "bleed":
      {
        "x": 0,
        "y": 0,
        "width": 1024,
        "height": 1536
      },

      "trim":
      {
        "x": 24,
        "y": 24,
        "width": 976,
        "height": 1488
      },

      "safe":
      {
        "x": 72,
        "y": 72,
        "width": 880,
        "height": 1392
      }
    },

    "page_side": "automatic",

    "page_number":
    {
      "display": true,
      "value":
      {
        "mode": "explicit",
        "number": 40
      },
      "style":
      {
        "type": "plain"
      },
      "position":
      {
        "horizontal": "outer_edge",
        "vertical": "bottom"
      }
    },

    "panel_numbers":
    {
      "display": false
    },

    "layout":
    {
      "type": "rows",
      "margin":
      {
        "top": 24,
        "bottom": 24,
        "left": 24,
        "right": 24
      },
      "gutter":
      {
        "horizontal": 12,
        "vertical": 12
      },
      "rows":
      [
        {
          "height_weight": 1,
          "panels":
          [
            { "id": "R1", "width_weight": 1 },
            { "id": "R2", "width_weight": 1 }
          ]
        },
        {
          "height_weight": 1,
          "panels":
          [
            { "id": "R3", "width_weight": 1 },
            { "id": "R4", "width_weight": 1 }
          ]
        }
      ]
    },

    "insets":
    [
    ],

    "panel_links":
    [
    ],

    "panels":
    [
      {
        "id": "P1",
        "merge":
        [
          "R1"
        ]
      },
      {
        "id": "P2",
        "merge":
        [
          "R2",
          "R4"
        ]
      },
      {
        "id": "P3",
        "merge":
        [
          "R3"
        ]
      }
    ]
  }
}
```

The "panels" array is especially important. It is the list of logical panels that exist on this page. Each element between the array brackets is one complete panel object. In the skeleton above, the array contains three elements: P1, P2, and P3. There is no extra "panel" keyword in front of each element; each pair of curly braces is itself one array element.

The "layout" section defines rectangular regions R1 through R4. Those region ids describe geometry only. The elements of the "panels" array turn that geometry into logical panels. P1 uses R1, P3 uses R3, and P2 uses the merged regions R2+R4. Once the logical panel is established, that same panel object can also contain setting, characters, objects, blocking, action, camera, dialogue, lighting, effects, and other script information.

This distinction is central to SBL: layout regions say where image areas exist on the page; panel objects say what those image areas mean and what should be rendered in them. The following major section, Panel Content, defines the entries that may appear inside each panel object.

## Panel Content

A panel describes one visual state. A resolved panel should contain enough information to render independently, even when its source uses imports, defaults, inheritance, or external reference libraries.

Panel properties defined by this specification include id, description, imports, inherit, entry_state, checkpoint, anchor, text_styles, direction, setting, characters, objects, blocking, orientation, pose, expression, actions, events, camera, composition, lighting, dialogue, footnotes, narration, sfx, effects, constraints, validation, canonical_dimensions, appearance_state, visibility, interactions, relationships, eyelines, camera_continuity, continuity, visual_continuity, perspective, background, motion, text_objects, references, render_layers, render_passes, render_sets, render_profiles, and render. Features introduced in later sections remain ordinary panel properties even when they are described outside this section.

Panel Property Requirement Rule. Except for "id", panel properties are optional unless their individual definitions explicitly state otherwise. Omitting a property means that the current panel introduces no new requirement for that property. An effective value may still come from an imported definition, a broader cascading declaration, a normative default, or explicit inheritance. When a construct is present, its own definition specifies the fields required within that construct.

Panel-level "text_styles" is optional. When present, it declares reusable text formatting for that panel scope according to the SBL Text declaration and lexical-scope rules.

Every panel described in this chapter is one element of its page's "panels" array. The array name appears once, before the list. Individual panel entries do not begin with another "panels" or "panel" label; an individual panel is simply a JSON object enclosed in curly braces inside the array.

### Panel Identity and Description

Requirements — Panel "id" is REQUIRED. "description" is optional SBL Text. No default description is implied.

```json
{
  "id": "CH12-P40-S3",
  "description": "The students stop and look back after hearing an explosion."
}
```

The curly-braced object above is one element of the page's "panels" array. Its "id" is the machine-readable identity of this logical panel. Other properties placed inside the same braces describe that panel.

The optional "description" is SBL Text containing a human-readable summary of the panel. It can help an author, editor, resolver, or renderer understand the intended moment, but structured SBL properties take precedence when they specify the same subject more precisely.

```json
{
  "id": "CH12-P40-S3",
  "description": "The students stop after the explosion.\nMidori turns toward the lavatory door.\nBeli looks alarmed."
}
```

A JSON string cannot contain a literal unescaped line break. For a multi-line description, place the escape sequence "\n" at each desired line or paragraph break. A tool displaying the description may render each "\n" as a new line. For very long descriptions, it is usually better to move specific facts into structured SBL fields rather than put an entire scene script into "description".

Page and panel descriptions can also support production workflow. A separate utility may scan an SBL document and extract page numbers, page ids, panel ids, and descriptions to produce a rendering work list. Including descriptions in that list gives an artist, renderer, or automation layer a concise human-readable summary of the work associated with each page or panel. The exact work-list format and extraction utility are outside the scope of this specification.

### Imports and Reusable Definitions

Requirements — "imports" is optional. Each import record MUST identify the external SBL/JSON file to load with "file". A required import that cannot be loaded is a resolution error.

Imports solve a repetition problem. A chapter may return to the same classroom, dorm room, laboratory, or hallway dozens of times. Rewriting the complete environment in every panel is tedious and makes continuity errors likely. Instead, SBL lets the author define the reusable material once and load that definition where it is needed.

In SBL 1.0, an "import" refers to a separate external SBL/JSON file. It is not textual copy-and-paste and it does not insert raw characters at the location of the import statement. The imported file is parsed as structured JSON, its reusable definitions are loaded into the effective SBL namespace, and the resolver then uses those definitions where referenced.

Imports are declaration-scope additions rather than ordinary replace-on-override arrays. Imports visible from broader lexical scopes remain visible when a narrower scope declares additional imports. A narrower "imports" array therefore adds its imported definitions to the visible import set; it does not hide broader imports. Resolvers MAY de-duplicate repeated imports of the same normalized file path.

Reusable material elsewhere in the current document is not imported. Within one document, use ordinary machine-id references, cascading declarations, or panel inheritance. Use "imports" when the reusable definitions live in another file.

An import file uses strict JSON and has an SBL "library" object at its root. A library is not a renderable page. Each library MUST contain a stable "id" and a "specification" object identifying the SBL version used by that library. It is a named collection of reusable definitions such as locations, sub-locations, objects, characters, costumes, resources, and text styles. Authors do not normally hand-build these files: they may ask ChatGPT or another SBL-aware tool to extract a reusable location or costume from an existing script and save it as a library file.

Example import file: resources/locations/Academy-Classroom.sbl.json

```json
{
  "library":
  {
    "id": "Academy-Classroom-Library",
    "specification":
    {
      "name": "SBL",
      "version": "1.0"
    },

    "locations":
    {
      "academy_classroom":
      {
        "name": "Academy Classroom",
        "sub_locations":
        {
          "main_room":
          {
            "name": "Main Classroom"
          }
        },
        "objects":
        [
          {
            "id": "blackboard",
            "type": "board"
          },
          {
            "id": "teacher_desk",
            "type": "desk"
          },
          {
            "id": "window_left",
            "type": "window"
          },
          {
            "id": "window_right",
            "type": "window"
          }
        ]
      }
    }
  }
}
```

A panel that wants to use this reusable classroom imports the file, then names the imported location by its machine id:

```json
{
  "id": "CH12-P10-S1",

  "imports":
  [
    {
      "file": "resources/locations/Academy-Classroom.sbl.json"
    }
  ],

  "setting":
  {
    "location": "academy_classroom",
    "sub_location": "main_room",
    "time": "afternoon"
  },

  "characters":
  [
    {
      "id": "midori",
      "reference": "Midori_character_sheet"
    },
    {
      "id": "beli",
      "reference": "Beli_character_sheet"
    }
  ]
}
```

The import statement makes the library definitions available; the "setting" statement selects "academy_classroom". The panel does not repeat the blackboard, desks, or windows. Those facts come from the imported library.

A resolver is the processing step that turns compact Source SBL into the full effective description required for rendering. The resolver follows import files, finds the selected definitions, resolves referenced resources, applies defaults and inheritance, applies local overrides, and emits a complete Resolved SBL panel.

ChatGPT can perform this resolver role. If the panel above is sent to ChatGPT together with the SBL project files, ChatGPT reads the panel, opens Academy-Classroom.sbl.json, finds "academy_classroom", gathers its environmental objects and any referenced images, combines those facts with Midori, Beli, the afternoon setting, and the panel-specific action/camera/dialogue, and then gives the image generator the complete scene description. The image generator should not be expected to remember the classroom from an earlier page.

### Inheritance

Requirements — "inherit" is optional. When present, "inherit.from" is REQUIRED. "inherit.preserve" is optional; when omitted, all inheritable semantic scene state is copied before local overrides are applied.

Inheritance means “start this panel with scene state already established by another panel.” It is useful when two panels show consecutive moments in the same scene. The new panel need only state what changed.

By default, an "inherit" object containing only "from" copies all inheritable semantic scene state from the named source panel. The new panel's own properties are then applied on top of that copied state. The new values are the changes; inherited values that are not overridden remain in effect.

```json
{
  "id": "P1",
  "setting":
  {
    "location": "academy_classroom",
    "time": "afternoon"
  },
  "characters":
  [
    { "id": "midori" },
    { "id": "beli" }
  ],
  "pose":
  [
    { "target": "midori", "type": "standing" },
    { "target": "beli", "type": "standing" }
  ]
}
{
  "id": "P2",
  "inherit":
  {
    "from": "P1"
  },

  "pose":
  [
    {
      "target": "beli",
      "type": "sitting"
    }
  ],

  "orientation":
  [
    {
      "target": "midori",
      "head":
      {
        "toward": "classroom_door"
      },
      "gaze":
      {
        "target": "classroom_door"
      }
    }
  ]
}
```

P2 does not repeat the classroom, the afternoon time, or the fact that Midori and Beli are present. Those facts are inherited from P1. The only explicit changes are that Beli is now sitting and Midori turns her head and gaze toward the door.

Inheritance copies semantic facts, not pixels. The renderer may redraw the panel from a new camera angle or with different composition while preserving inherited facts.

The optional "preserve" array is a selective-inheritance filter. It lists broad semantic categories that should be copied from the source panel; it does NOT list the changes. SBL 1.0 uses a closed preserve vocabulary so misspellings and unknown categories are validation errors rather than silently ignored instructions. When "preserve" is omitted, all inheritable semantic scene state is copied. When "preserve" is present, only the named categories are copied before local overrides are applied.

```json
{
  "inherit":
  {
    "from": "P1",
    "preserve":
    [
      "character_appearance",
      "wardrobe",
      "equipment"
    ]
  },

  "setting":
  {
    "location": "academy_corridor",
    "time": "afternoon"
  }
}
```

This selective example keeps the characters’ effective appearance, wardrobe, and equipment from P1 but deliberately establishes a new location. The "setting" is a change because it appears outside the "inherit" object as an ordinary property of the new panel.

Standard preserve categories

SBL 1.0 defines the following preserve categories: "setting", "characters", "character_appearance", "wardrobe", "equipment", "objects", "object_state", "blocking", "orientation", "pose", "expression", "actions", "camera", "composition", "lighting", "visibility", "relationships", "perspective", and "background". No other preserve-category strings are conforming SBL 1.0 values.

"setting" preserves the effective setting, including location, sub-location, and story time. "characters" preserves which characters are present and their identity-level declarations. "character_appearance" preserves character identity/reference information, canonical scale/dimensions, and temporary appearance_state, but does not implicitly preserve wardrobe or equipment. "wardrobe" preserves costume and footwear. "equipment" preserves worn_items and carried_items.

"objects" preserves which scene objects are present. "object_state" preserves their effective state values. "blocking" preserves blocking relationships, stage_position, screen_position, and arrangement. "orientation", "pose", "expression", "actions", "camera", "composition", "lighting", "visibility", "relationships", "perspective", and "background" preserve their corresponding effective panel properties.

The categories "dialogue", "footnotes", "narration", "sfx", "direction", "events", "effects", "text_objects", "constraints", "validation", "continuity", "render_layers", and "render_passes" are intentionally not inheritable through "inherit.preserve". Those constructs describe the particular depicted moment, textual overlays, production instructions, validation machinery, or render/compositing instructions rather than persistent semantic scene state.

Preserve selects starting state; it does not freeze it

A preserve category selects which effective state is copied from the source panel. It does not make that state immutable. The inheriting panel may immediately override a preserved value using its normal local property. For example, preserving "pose" copies the source poses, but a local pose record for Beli may then change Beli from standing to sitting while other preserved poses remain in effect.

```json
{
  "inherit":
  {
    "from": "P1",
    "preserve":
    [
      "pose"
    ]
  },

  "pose":
  [
    {
      "target": "beli",
      "type": "sitting"
    }
  ]
}
```

### Sequential State, Entry State, and Checkpoints

Requirements — "entry_state" and "checkpoint" are optional panel properties. entry_state.mode, when present, MUST be "continue", "reset", or "restore". restore requires "from", which MUST resolve to an earlier checkpoint in the same script. checkpoint.id is REQUIRED when checkpoint is present and MUST be unique within the script. A panel MUST NOT combine explicit "inherit" with "entry_state"; competing entry-state mechanisms are a semantic resolution error.

#### Sequential State

Panels form a semantic sequence according to effective reading order. SBL carries automatically persistent state from the resolved end-state of one logical panel into the entry state of the next. Sequential persistence crosses page boundaries: the persistent end-state of the last logical panel of one page supplies the baseline for the first logical panel of the next page unless that panel resets or restores state.

The preceding logical panel MUST be determined by effective reading order, not physical coordinates, render order, or accidental JSON processing order. The first logical panel has no preceding sequential state. Its state is established by applicable script/page declarations, imports, defaults, setting, and its own panel declarations.

#### entry_state

"entry_state" controls the temporal starting state of the current panel. When omitted on a panel that has a preceding logical panel, its effective mode is "continue". Authors SHOULD normally omit an explicit continue.

```json
"entry_state":
{
  "mode": "continue"
}
```

continue — Start from the automatically persistent resolved end-state of the preceding logical panel.

```json
"entry_state":
{
  "mode": "reset"
}
```

reset — Start a new temporal scene state and discard sequential state received from the preceding panel. Reset does not discard script/page declarations, imports, reusable definitions, resources, or defaults. A resolver MUST NOT guess a reset merely because a location changes.

```json
"entry_state":
{
  "mode": "restore",
  "from": "cog_before_babel"
}
```

restore — Replace ordinary sequential entry state with the persistent scene state stored by the named checkpoint. Local panel declarations are applied afterward. Restoration does not consume or modify the checkpoint. After the panel resolves, its persistent end-state becomes the baseline for subsequent continue panels.

#### Sequential Persistence Categories

Automatically persistent under continue: setting; characters/presence; character_appearance; wardrobe; equipment; objects; object_state; blocking; orientation; pose; relationships; lighting.environment; lighting.shot; camera; perspective; and background only when background.mode is "environment".

Not automatically persistent: composition; expression; actions; visibility/cropping/occlusion; background modes "abstract", "none", and "transparent"; dialogue; footnotes; narration; sfx; events; effects; direction; constraints; validation; text_objects; render_layers; and render_passes. Presence and visibility remain distinct.

Actions, events, and effects are moment-specific even when they cause persistent consequences. An "open" action does not persist, but an explicitly established door.state.open=true does persist as object_state. A resolver MUST NOT invent a persistent consequence that SBL does not establish.

Explicit inheritance and automatic persistence are different mechanisms. inherit may explicitly copy categories that are not automatically persistent.

#### checkpoint

A checkpoint captures resumable persistent scene state at a named point in the SBL timeline. A checkpoint attached to a panel captures state from the resolved END of that panel, after local changes have been applied.

```json
"checkpoint":
{
  "id": "cog_before_babel"
}
```

Checkpoints are immutable and reusable. A checkpoint captures setting; characters/presence; character_appearance; wardrobe; equipment; objects; object_state; blocking; pose; relationships; and lighting.environment. It does NOT capture orientation, lighting.shot, camera, perspective, composition, expression, actions, visibility/cropping/occlusion, background treatment, textual content, events/effects, or production/render instructions.

#### Entry-State Conflict Rule

A panel has one temporal entry-state source. A panel containing explicit "inherit" MUST NOT also contain "entry_state", regardless of mode. Existing "continuity" remains a separate validation/consistency mechanism and does not establish entry state.

### Anchors and Internal Reader-Facing References

Requirements — "anchor" is optional on page and panel objects. Its value MUST be either one Anchor object or a non-empty array of Anchor objects. Every Anchor object MUST contain "id"; "label" is optional SBL Text. Anchor ids MUST be unique across the root script document. SBL 1.0 anchors and anchor references are internal to the current root script document.

#### Anchor Declaration

An anchor is a stable semantic address for a page or panel. It identifies the object on which it is declared but, unlike a checkpoint, does not itself capture resumable scene state. The single-object form is RECOMMENDED when only one anchor is needed because it is the common, more readable form.

```json
"anchor":
{
  "id": "flood_story",
  "label": "The Flood"
}
```

When several semantic addresses are useful at the same page or panel, the same "anchor" property may contain an array. The object and array forms have identical semantics; a resolver SHOULD normalize the single-object form to a one-element internal collection.

```json
"anchor":
[
  {
    "id": "flood_story",
    "label": "The Flood"
  },
  {
    "id": "water_world_reveal"
  }
]
```

Anchor ids use the normal SBL machine-id lexical rules but have document-wide uniqueness. Moving or repaginating the anchored page or panel does not change anchor identity. A resolver MUST report duplicate or ambiguous anchor ids and MUST NOT guess which target was intended.

#### Checkpoints and Anchors

Every checkpoint implicitly establishes an anchor with the same id on the checkpointed panel. Thus every checkpoint is addressable as an anchor, but an ordinary anchor does not create or capture checkpoint state. An author MUST NOT explicitly declare an anchor whose id duplicates an anchor implicitly created by a checkpoint.

#### Structured Internal References

Structured SBL properties continue to use ordinary machine-reference strings. A reference may identify an ordinary SBL entity through the existing lexical/qualified-id mechanism or may identify a document-wide anchor where the property permits an anchor target. Existing qualified references such as "P23::P23S4" remain valid. A semantic anchor reference may use the anchor id directly, such as "flood_story". Anchor lookup is document-wide rather than lexical.

An anchor id MUST NOT collide with another addressable machine id in a way that makes a permitted reference ambiguous. Such a collision is a semantic resolution error. SBL 1.0 does not define cross-document anchor syntax; external anchors and cross-document reader-facing references are reserved for a future version.

#### Reader-Facing Reference Substitution

SBL Text may contain reader-facing anchor substitutions using the form {ref:anchor_id.property}. These substitutions are textual presentation features; they do not replace ordinary structured SBL reference fields.

```json
See {ref:flood_story.label} on page {ref:flood_story.page}.
```

SBL 1.0 defines the following anchor substitution properties: "label" is the anchor's optional reader-facing label; "page" is the effective reader-facing/display page number of the containing page; "page_id" is the stable machine id of the containing page; and "panel" is the stable machine id of the anchored panel. "panel" is panel identity, not a printed panel number.

A page anchor has no panel value. Requesting {ref:...panel} for a page anchor is a resolution error. Requesting "label" when no label exists is a resolution error. Requesting "page" requires a resolvable effective display page number; a processor MUST NOT invent one when the target page has no effective display number. "page_id" remains available because every renderable page has a stable machine id.

Anchor substitutions MUST be resolved before layout of the containing SBL Text. Balloon sizing, caption sizing, footnote sizing, line wrapping, and later visibility/postproduction processing therefore operate on the final substituted text.

### Direction

Requirements — "direction" is optional. Each direction record MUST contain "type" and SBL Text "text". "display" is optional and defaults to false. When display is true, "display_placement" is optional and defaults to "bottom".

```json
{
  "direction":
  [
    {
      "type": "dramatic_intent",
      "text": "Make the interruption feel sudden and alarming."
    },
    {
      "type": "renderer_note",
      "text": "Do not show the source of the explosion."
    }
  ]
}
```

The "direction" property contains directorial or production instructions that supplement the structured scene description. Direction records may describe dramatic intent, composition, continuity concerns, production guidance, or information that SBL 1.0 does not yet model structurally. Direction does NOT specify Cartesian coordinates merely because a note discusses where something should appear; structured properties such as blocking, stage_position, screen_position, camera, and composition remain the authoritative mechanisms for structured placement.

Each direction array element is a direction record. "type" is REQUIRED and is a machine-readable classification string. "text" is REQUIRED SBL Text. "display" is an optional Boolean whose default is false. "display_placement" is optional and is meaningful only when display is true; its SBL 1.0 values are "top" and "bottom", with "bottom" as the default. The generic property name "placement" remains reserved for the normalized screen-placement object used by graphical elements.

#### Direction Types

SBL 1.0 defines the standard direction types "renderer_note", "dramatic_intent", "composition_note", "continuity_note", "production_note", and "temporal". "renderer_note" is general renderer guidance not adequately represented elsewhere. "dramatic_intent" describes mood, emphasis, pacing impression, or storytelling effect. "composition_note" supplements structured composition or blocking. "continuity_note" records human/directorial continuity guidance that supplements formal inheritance and continuity. "production_note" records guidance primarily useful to an artist, editor, compositor, or production workflow. "temporal" records unstructured timing, camera-motion, transition, or other time-dependent guidance, particularly for SBL 1.0 storyboards.

The direction-type vocabulary is open-ended. A project MAY use another concise machine-readable type such as "colorist_note". A resolver MUST preserve an unrecognized direction type and its text; an implementation MAY warn that it cannot interpret the type. Unknown direction types are not semantic errors merely because they are unknown.

#### Precedence

Direction records supplement structured SBL and MUST NOT override contradictory required structured semantics. If a direction note says to place Midori on the left while a required blocking constraint places her on the right, the required structured constraint wins and the processor SHOULD report the conflict rather than silently changing the scene.

#### Multi-line and Rich Direction Text

A direction record's "text" value is SBL Text. For ordinary multi-line direction prose, use "\n" inside a JSON string. When word-level formatting is required, the same field may use SBL Text "runs". For several logically separate instructions, an array containing several direction records is usually easier to edit than one very long multi-line string.

```json
{
  "direction":
  [
    {
      "type": "renderer_note",
      "text": "Keep the classroom calm and orderly.\nMake the explosion reaction sudden.\nDo not show the source of the explosion."
    }
  ]
}
```

#### Storyboard Temporal Guidance

SBL 1.0 storyboards MAY use direction records to express temporal information that the structured language does not yet model. This is an intentional interim mechanism, not formal timing syntax. A conforming resolver MUST preserve the text but is not required to convert it into duration, camera-animation, transition, or synchronization data.

```json
{
  "direction":
  [
    {
      "type": "temporal",
      "text": "Hold this shot for approximately three seconds."
    },
    {
      "type": "temporal",
      "text": "During the shot, slowly pan from Midori to Beli."
    },
    {
      "type": "temporal",
      "text": "Cut immediately to the next storyboard panel when the door explodes."
    }
  ]
}
```

#### Displaying Direction Notes in the Panel

By default, direction records are production guidance only and are not drawn in the rendered panel. Setting "display": true requests that the direction text itself be rendered as a production-note box. This is particularly useful on storyboard sheets where artists, directors, editors, or reviewers need to see timing and production instructions beside the visual frame.

```json
{
  "direction":
  [
    {
      "type": "temporal",
      "text": "Hold for approximately three seconds.",
      "display": true,
      "display_placement": "bottom"
    }
  ]
}
```

A displayed direction MUST use a production-note treatment that is visually distinguishable from dialogue and narration. SBL 1.0 restricts display_placement to the top or bottom edge of the panel so that production notes obscure as little scene artwork as practical. If display is true and display_placement is omitted, display_placement defaults to "bottom". Multiple displayed direction records using the same display_placement are stacked in direction-array order. Records assigned to different display placements are grouped at their respective top or bottom edges.

The "display" property affects presentation only. It does not change the semantic meaning, priority, or resolution behavior of the direction record. A displayed temporal note remains informal temporal guidance rather than formal SBL timing semantics.

```json
{
  "direction":
  [
    {
      "type": "temporal",
      "text": "Slow push in.",
      "display": true,
      "display_placement": "top"
    },
    {
      "type": "production_note",
      "text": "Cut on the explosion.",
      "display": true,
      "display_placement": "bottom"
    }
  ]
}
```

### Setting and Environment Objects

Requirements — "setting" and "objects" are optional. A "setting" object has no universally required child field because location, sub-location, or time may be inherited independently; any supplied location/sub_location id MUST resolve. Each locally declared object MUST contain an "id"; object-specific properties such as "type" and "state" are otherwise defined by the applicable object definition.

```json
{
  "setting":
  {
    "location": "academy_corridor",
    "sub_location": "north_wing",
    "time": "afternoon"
  },

  "objects":
  [
    {
      "id": "lavatory",
      "type": "room"
    },
    {
      "id": "window_3",
      "type": "window"
    }
  ]
}
```

"location" and "sub_location" contain machine ids, not arbitrary display names. "academy_corridor" must resolve to a visible location definition, typically declared in an imported SBL library. "north_wing" similarly identifies a sub-location declared within that location or another visible project definition. Human-readable names such as “Academy Corridor” belong in the definitions themselves.

The "time" field describes story time rather than an SBL object id. Standard daypart values are "dawn", "morning", "midday", "afternoon", "evening", and "night". An exact clock time may be written in 24-hour HH:MM form, such as "14:30". Projects may use additional descriptive values when necessary, but standard values are preferred when they express the intended time adequately.

Inside "objects", "lavatory" and "window_3" are machine ids for the individual environment objects. By contrast, "room" and "window" are object type/category strings. "room" is not an id that must refer to some other object named room. It simply classifies lavatory as a room. A project may define additional object types as needed.

Detailed reusable object geometry normally comes from the selected location definition or another imported library. A local "objects" entry may introduce a new object, name an object needed by blocking/action, or override state on an imported object.

### Characters, Costume, Footwear, and Personal Equipment

Requirements — "characters" is optional at panel scope because characters may cascade or be inherited. Each newly declared character MUST contain "id". Overrides of an already visible character need the same "id" and only the properties being changed. Costume and footwear selectors require their referenced "id" when present.

A character entry describes one character participating in the panel. The character's "id" identifies the character; "name" is human-readable. Character identity, costume identity, footwear, worn equipment, and carried equipment are separate so that changing an outfit does not change who the character is.

The "reference" field is SBL shorthand for a required character-identity resource. Its source is the effective "resources" collection in the current script or an imported SBL library. It is not a magic filename and it does not refer to information hidden inside ChatGPT. For example:

```json
{
  "resources":
  {
    "Midori_character_sheet":
    {
      "type": "image",
      "file": "resources/characters/Midori.png",
      "purposes":
      [
        "character_identity",
        "color_reference"
      ]
    }
  }
}
```

With that resource declaration visible, "reference": "Midori_character_sheet" means “use this required image resource as Midori's character identity.” The general "references" array may be used when several assets or explicit purpose/requirement fields are needed.

A "costume.id" names a reusable costume definition; it is not merely an arbitrary label. Costume definitions normally live in an imported SBL library. The definition may describe the clothing directly and/or reference one or more costume images. A costume definition may also supply defaults such as footwear.

```json
{
  "library":
  {
    "id": "Midori-Costumes",
    "specification":
    {
      "name": "SBL",
      "version": "1.0"
    },

    "costumes":
    {
      "academy_uniform":
      {
        "name": "Academy Uniform",
        "description": "Standard Academy student uniform.",
        "defaults":
        {
          "footwear": "academy_shoes"
        }
      },

      "formal_gown":
      {
        "name": "Formal Gown",
        "description": "Long formal gown used for ceremonial events."
      },

      "training_clothes":
      {
        "name": "Training Clothes",
        "description": "Practical training tunic and trousers.",
        "defaults":
        {
          "footwear": "training_boots"
        }
      },

      "casual_clothes":
      {
        "name": "Casual Clothes",
        "description": "Simple off-duty shirt and trousers."
      }
    }
  }
}
```

A panel may import this library once and then dress Midori by selecting one of these costume ids. The character identity reference remains the same; only the costume changes.

#### Academy uniform

```json
{
  "id": "midori",
  "name": "Midori",
  "reference": "Midori_character_sheet",
  "costume":
  {
    "id": "academy_uniform"
  }
}
```

#### Formal gown

```json
{
  "id": "midori",
  "name": "Midori",
  "reference": "Midori_character_sheet",
  "costume":
  {
    "id": "formal_gown"
  }
}
```

#### Training clothes

```json
{
  "id": "midori",
  "name": "Midori",
  "reference": "Midori_character_sheet",
  "costume":
  {
    "id": "training_clothes"
  }
}
```

#### Casual clothes

```json
{
  "id": "midori",
  "name": "Midori",
  "reference": "Midori_character_sheet",
  "costume":
  {
    "id": "casual_clothes"
  }
}
```

A character may override part of a costume after selecting it. In the following example, the Academy uniform normally supplies academy_shoes, but Midori explicitly wears training_boots instead:

```json
{
  "id": "midori",
  "reference": "Midori_character_sheet",

  "costume":
  {
    "id": "academy_uniform"
  },

  "footwear":
  {
    "id": "training_boots"
  },

  "worn_items":
  [
    {
      "id": "midori_mana_meter",
      "type": "mana_meter",
      "location": "chest",
      "visible": true
    }
  ],

  "carried_items":
  [
  ]
}
```

Character-level wardrobe properties override costume defaults. "footwear" is independently addressable. "worn_items" are personal equipment worn on the body and independent of costume; "carried_items" are objects currently carried and may later be put down or transferred.

#### Reusable footwear definitions

SBL 1.0 libraries may declare a "footwear" object keyed by footwear id. Each footwear definition may contain optional human-readable "name" and SBL Text "description", plus optional resource "references". A character "footwear.id" and a costume default footwear value MUST resolve to one of these visible footwear definitions.

```json
{
  "library":
  {
    "id": "Academy-Footwear",
    "specification":
    {
      "name": "SBL",
      "version": "1.0"
    },
    "footwear":
    {
      "academy_shoes":
      {
        "name": "Academy Shoes",
        "description": "Standard black Academy school shoes."
      },
      "training_boots":
      {
        "name": "Training Boots",
        "description": "Durable ankle boots used for practical training."
      }
    }
  }
}
```

At panel scope, "characters" is the canonical SBL property for character declarations and panel participation.

### Blocking and Coordinate Systems

Requirements — "blocking" is optional. A relationship record always requires "subject" and "relation". For every standard relation except "between", the record requires singular "object" and MUST NOT contain "objects". For "between", the record requires "objects", an array containing exactly two distinct references, and MUST NOT contain singular "object". "space" is required when the relation may be interpreted in more than one coordinate space. "stage_position", "screen_position", and "arrangement" are optional arrays inside "blocking". Each stage-position record requires "target" and at least one position component. Each screen-position record requires "target", numeric "x", and numeric "y"; "anchor" is optional and defaults to "bottom_center". Each arrangement record requires "type" and a non-empty "targets" array.

```json
{
  "blocking":
  {
    "relationships":
    [
      {
        "subject": "beli",
        "relation": "left_of",
        "object": "midori",
        "space": "screen"
      },
      {
        "subject": "buren",
        "relation": "behind",
        "object": "kenee",
        "space": "world"
      }
    ],
    "stage_position":
    [
      {
        "target": "midori",
        "horizontal": "center_stage",
        "depth": "downstage",
        "elevation": 0.0
      }
    ],
    "screen_position":
    [
      {
        "target": "midori",
        "x": 0.35,
        "y": 0.70,
        "anchor": "bottom_center"
      }
    ]
  }
}
```

Blocking supports relative relationships, normalized screen coordinates, world space, screen/camera space, and theatrical stage coordinates. "stage_position" is an array because a panel may explicitly position several entities in three-dimensional stage space. The horizontal axis uses the performer's perspective and should include extreme_stage_left, stage_left, center_stage, stage_right, and extreme_stage_right. The depth axis should include extreme_downstage, downstage, midstage, upstage, and extreme_upstage. center_stage and midstage are not synonyms: center_stage identifies the horizontal center between stage left and stage right, while midstage identifies the depth between downstage and upstage. Thus an entity may simultaneously be center_stage and downstage, or stage_left and midstage. The optional elevation property specifies physical height above the stage floor as a normalized value, with 0.0 at floor level and 1.0 at the top of the defined stage volume. "screen_position" is also an array and places entities in normalized panel coordinates. Its x and y values use 0.0 through 1.0, with x=0.0 at the left edge, x=1.0 at the right edge, y=0.0 at the top edge, and y=1.0 at the bottom edge. "anchor" uses the standard nine-anchor vocabulary and defaults to "bottom_center". For characters, bottom_center normally corresponds to the ground-contact point; for other entities it identifies the bottom-center of the rendered bounds. Explicit anchor values may be used whenever another reference point better expresses the intended placement. Screen-space y is distinct from stage elevation.

#### Between

The standard "between" relationship is the one blocking relationship that refers to two reference entities rather than one. It uses "objects", not "object". The "objects" array MUST contain exactly two distinct machine-id references. Using fewer or more than two references is invalid, and a between record MUST NOT contain both "object" and "objects".

```json
{
  "blocking":
  {
    "relationships":
    [
      {
        "subject": "midori",
        "relation": "between",
        "objects":
        [
          "beli",
          "kenee"
        ],
        "space": "screen"
      }
    ]
  }
}
```

"between" means the subject is spatially between the two referenced entities in the specified coordinate space. It does not require the subject to lie at their exact geometric midpoint unless another constraint explicitly requires that stronger condition. For example, the record above requires Midori to read visually between Beli and Kenee on screen, while leaving the exact spacing to other blocking information or the renderer.

#### Arrangement

The "blocking.arrangement" construct positions one or more groups of characters or objects according to geometric patterns. It is an array inside "blocking" so a panel may contain several independently arranged groups. Within one effective blocking.arrangement array, each target MUST appear in at most one arrangement record. A target that appears in more than one effective arrangement is a semantic validation error because two independent group geometries would otherwise compete to establish its initial placement. This restriction does not prevent more specific blocking, stage_position, screen_position, relationships, or constraints from refining a target after its single arrangement has established starting geometry.

Each arrangement record determines initial group geometry. It does not replace other blocking information. Individual targets may still have explicit relationships, screen/stage positions, orientation, pose, actions, or constraints that refine the result. When broader and narrower scopes contribute arrangement records, the resolver MUST form the effective arrangement set and then verify that no target occurs in more than one arrangement record.

Every arrangement record has a "type" and a non-empty "targets" array. "type" selects the geometric pattern and determines which additional fields are legal or required. "targets" contains unique machine-id references to the characters or objects placed by that pattern. SBL 1.0 uses type-specific arrangement records rather than one loose record containing arbitrary fields.

```json
"blocking":
{
  "arrangement": [
    {
      "type": "around",
      "targets": [
        "midori",
        "beli",
        "kenee",
        "buren"
      ],
      "spacing": "even",
      "center": "group_center"
    }
  ]
}
```

SBL 1.0 defines five arrangement types: "around", "line", "arc", "grid", and "cluster". The following subsections define each type. Targets not named in an arrangement are unaffected.

##### Arrangement center and spacing forms

Where an arrangement accepts "center", the value may be either an SBL entity reference or an explicit point. A screen point uses {"space":"screen","x":...,"y":...} with normalized coordinates. A stage point uses {"space":"stage","horizontal":...,"depth":...} and may include normalized "elevation". A physical arrangement distance uses the standard {"value": number, "units": ...} quantity and MUST be greater than zero. The keyword "even" requests even distribution without prescribing an exact physical distance.

```json
{
  "space": "screen",
  "x": 0.5,
  "y": 0.5
}
{
  "space": "stage",
  "horizontal": "center_stage",
  "depth": "midstage",
  "elevation": 0.0
}
```

##### Around

"around" places the targets around a central character, object, or explicit point. Required fields are "type", "targets", and "center". "center" may be an entity reference or an explicit screen/stage point. Optional "radius" is a positive physical quantity. "order" may be "clockwise" or "counterclockwise"; "start_angle" is degrees; "spacing" is either "even" or a positive physical quantity; "facing" may be "center", "outward", "forward", or "camera".

```json
"blocking":
{
  "arrangement":
  [
      {
        "type": "around",
        "center": "council_table",
        "targets":
        [
          "midori",
          "beli",
          "kenee",
          "buren"
        ],
        "radius":
        {
          "value": 1.5,
          "units": "m"
        },
        "order": "clockwise",
        "start_angle": 0,
        "spacing": "even",
        "facing": "center"
      }
  ]
}
```

##### Line

"line" places the targets along a straight line. Required fields are "type" and "targets". "orientation" is optional and may be "horizontal", "vertical", or a numeric angle in degrees. "order" may be "left_to_right", "right_to_left", "top_to_bottom", or "bottom_to_top". "spacing" is optional and is either "even" or a positive physical quantity.

```json
"blocking":
{
  "arrangement":
  [
      {
        "type": "line",
        "targets":
        [
          "midori",
          "beli",
          "kenee",
          "buren"
        ],
        "orientation": "horizontal",
        "order": "left_to_right",
        "spacing": "even"
      }
  ]
}
```

##### Arc

"arc" places targets along part of a circle. Required fields are "type", "targets", "center", and numeric "angle" in degrees. "center" uses the same entity-reference or explicit-point form as around. Optional "radius" is a positive physical quantity; "start_angle" is degrees; "order" may be "clockwise" or "counterclockwise"; "spacing" is "even" or a positive physical quantity; "facing" may be "center", "outward", "forward", or "camera".

```json
"blocking":
{
  "arrangement":
  [
      {
        "type": "arc",
        "center": "teacher",
        "targets":
        [
          "student_01",
          "student_02",
          "student_03",
          "student_04",
          "student_05"
        ],
        "angle": 120,
        "start_angle": -60,
        "spacing": "even",
        "facing": "center"
      }
  ]
}
```

##### Grid

"grid" places targets in rows and columns. Required fields are "type", "targets", positive integer "rows", and positive integer "columns". "order" may be "row_major" or "column_major". "spacing", "spacing_x", and "spacing_y" are optional; each is either "even" or a positive physical quantity, with axis-specific values overriding general spacing on that axis. The grid may contain more cells than targets, leaving unused cells, but rows×columns MUST NOT be smaller than the number of targets.

```json
"blocking":
{
  "arrangement":
  [
      {
        "type": "grid",
        "targets":
        [
          "student_01",
          "student_02",
          "student_03",
          "student_04",
          "student_05",
          "student_06",
          "student_07",
          "student_08",
          "student_09"
        ],
        "rows": 3,
        "columns": 3,
        "order": "row_major",
        "spacing": "even"
      }
  ]
}
```

##### Cluster

"cluster" places targets in a loose group. Required fields are "type" and "targets". Optional "center" uses the standard arrangement-center form. "density" may be "tight", "normal", or "loose"; "shape" may be "round", "oval", or "irregular"; "facing" may be "center", "outward", "forward", or "camera". A cluster deliberately leaves more local placement freedom to the renderer than the other arrangement types.

```json
"blocking":
{
  "arrangement":
  [
      {
        "type": "cluster",
        "center": "campfire",
        "targets":
        [
          "midori",
          "beli",
          "kenee",
          "buren",
          "shiori"
        ],
        "density": "normal",
        "shape": "irregular",
        "facing": "center"
      }
  ]
}
```

Arrangement values are starting geometry, not immutable coordinates. If an individual target has a required relationship or explicit position that conflicts with an arrangement, the resolver should satisfy the more specific required instruction or report a contradiction when both requirements cannot be satisfied.

### Orientation and Pose

Requirements — "orientation" and "pose" are optional arrays of target records. Every orientation record requires "target" plus at least one orientation component. Every pose record requires "target" and "type". Even a single-character orientation or pose uses a one-element array.

Orientation and pose describe different aspects of one or more characters. Each property is an array so several targets may be specified in the same panel. "orientation" describes which way each target's body, torso, head, and eyes are directed. "pose" describes broad physical posture or locomotion state, such as standing, sitting, kneeling, or running. These properties are independent so SBL can describe, for example, a person whose body faces left while the head turns toward another character and the eyes look directly at the camera.

#### Body Orientation

The "body" property gives the overall camera-relative orientation of the character. It describes the principal direction of the whole body, not a temporary twist of the torso or head.

Valid body values are "front", "front_three_quarter_left", "left", "back_three_quarter_left", "back", "back_three_quarter_right", "right", and "front_three_quarter_right". These correspond approximately to 45-degree steps around the character and are artistic orientation categories rather than requirements for mathematically exact angles.

```json
"orientation":
[
  {
    "target": "midori",
    "body": "front_three_quarter_right"
  }
]
```

#### Torso Orientation

The "torso" property describes rotation of the chest and shoulders relative to the body orientation. It is useful when the feet and lower body remain aimed one way while the upper body twists toward something else.

Valid torso values are "aligned", "slight_left", "left", "strong_left", "slight_right", "right", and "strong_right". "aligned" means the torso follows the body orientation. The left/right terms describe relative rotation from that body orientation; they do not replace stage-left/stage-right or screen-position vocabulary.

```json
"orientation":
[
  {
    "target": "midori",
    "body": "front",
    "torso": "slight_left"
  }
]
```

#### Head Orientation

The head may be described either by a relative turn or by a named target. Use "turn" when the important fact is how far the head rotates relative to the torso. Use "toward" when the important fact is that the face is directed toward a particular character, object, or location.

Valid "turn" values are "aligned", "slight_left", "left", "strong_left", "slight_right", "right", and "strong_right". A head object MUST NOT specify both "turn" and "toward" unless a future SBL version explicitly defines how to combine them.

```json
"orientation":
[
  {
    "target": "midori",
    "body": "front",
    "head":
    {
      "toward": "beli"
    }
  }
]
```

#### Gaze

The "gaze" property specifies where the eyes are looking. Gaze is independent of head orientation: a character can turn the head toward one subject while glancing elsewhere with the eyes.

Gaze normally uses either "target" or "direction". "target" names a character, object, or location id. Valid generic "direction" values are "camera_left", "camera_right", "up", "down", "forward", "camera", and "away". "camera" means looking directly toward the viewer/lens; "forward" means looking generally in the direction the head faces; "away" means deliberately avoiding the principal subject or camera without requiring an exact vector. A gaze object SHOULD use either "target" or "direction", not both.

```json
"orientation":
[
  {
    "target": "midori",
    "head":
    {
      "toward": "beli"
    },
    "gaze":
    {
      "target": "beli"
    }
  }
]
```

The optional Boolean "show_gaze_arrow" requests a visible dashed arrow from the character's eyes toward the gaze target or direction. Its default is false. This is primarily an explanatory, diagnostic, storyboard, or instructional device; when true, the arrow becomes part of the requested rendered image. It is especially useful for upstage or distant characters whose eye direction may otherwise be too small to read clearly.

```json
"orientation":
[
  {
    "target": "midori",
    "body": "back_three_quarter_left",
    "head":
    {
      "turn": "slight_right"
    },
    "gaze":
    {
      "target": "door",
      "show_gaze_arrow": true
    }
  }
]
```

#### Combined Orientation Example

A complete orientation can combine all four components. In the following example, Midori's body is angled three-quarter right, her shoulders twist slightly left, her head turns toward Beli, and her eyes also look at Beli.

```json
"orientation":
[
  {
    "target": "midori",
    "body": "front_three_quarter_right",
    "torso": "slight_left",
    "head":
    {
      "toward": "beli"
    },
    "gaze":
    {
      "target": "beli",
      "show_gaze_arrow": false
    }
  }
]
```

#### Pose

The "pose" property describes the broad physical posture or locomotion state of a character. It is intentionally separate from orientation. The initial standard pose types are "standing", "sitting", "kneeling", "crouching", "lying", "leaning", "walking", and "running".

These are broad categories rather than an attempt to enumerate every possible human pose. A pose record may include additional details such as what the character sits on, leans against, or how the posture should be interpreted. Free-form "direction" may provide further artistic detail, while structured interaction and blocking properties define required physical relationships.

```json
"pose":
[
  {
    "target": "midori",
    "type": "sitting",
    "on": "chair_3",
    "posture": "upright"
  }
]
```

The older ad hoc property names "facing", "twist_toward", and "turned_toward" are not part of this orientation model. Use "body", "torso", "head.turn" or "head.toward", and "gaze.target" or "gaze.direction" instead.

### Expression

Requirements — "expression" is an optional array of target records. Each expression record requires "target" and "type". "intensity" is optional. When omitted, SBL imposes no intensity constraint and the renderer chooses a natural interpretation of the specified expression type. Even one expression uses a one-element array.

Expression is character-visible state: it specifies the facial expression the audience should see. It does not necessarily describe the character's true internal emotion. A frightened character may deliberately display a neutral expression, so SBL describes the visible result rather than attempting to infer psychology.

Each element of the "expression" array identifies a character with "target", describes the visible facial expression with "type", and may use "intensity" to indicate how strongly the expression should be shown. Unlike many SBL properties, "type" is intentionally an open descriptive string rather than a closed enumeration. The author may use any concise human-recognizable expression or emotion term that the renderer can reasonably interpret. Suggested examples include "neutral", "happy", "sad", "angry", "afraid", "surprised", "confused", "embarrassed", "disgusted", "determined", "concerned", "curious", "excited", "proud", "shocked", "irritated", "relieved", and "bored". The standard intensity values remain "mild", "moderate", "strong", and "extreme". "details" may add visible facial information that the broad type does not capture. Omitting "intensity" does not imply "moderate" or any other standard intensity value; it leaves intensity unspecified.

```json
{
  "expression": [
    {
      "target": "midori",
      "type": "confused",
      "intensity": "mild"
    }
  ]
}
{
  "expression": [
    {
      "target": "midori",
      "type": "surprised",
      "intensity": "strong",
      "details": "eyes wide, mouth slightly open"
    }
  ]
}
{
  "expression": [
    {
      "target": "midori",
      "type": "embarrassed",
      "intensity": "mild",
      "details": "slight blush, eyes lowered"
    }
  ]
}
```

Expression is independent of pose, orientation, and gaze. The same expression may be shown while a character is standing, sitting, looking away, or facing the camera. When a character identity resource includes canonical facial-expression references, the renderer SHOULD use those references to preserve the character's facial structure and expression style.

The following examples use Midori's supplied character sheet as the identity reference. They illustrate how several expression values might be rendered without changing her canonical face, hair, or costume.

### Actions

Requirements — "actions" is optional. Each action record MUST contain "subject" and "action". "target" is optional unless the selected action requires an object or entity toward which the action is directed. Additional action-specific fields such as hand, tool, target_part, direction, or destination are optional unless needed to make the action semantically complete.

Actions describe what a character or object is intentionally doing in the panel. They answer the question “what activity is occurring?” An action is different from pose: "sitting" describes posture, while "read" describes an activity that may be performed while sitting. An action is also different from an interaction: an interaction records a required physical relationship or contact, such as a hand grasping a door handle.

The "actions" property is an array because several actions may occur in the same panel. Each action contains "subject" (who or what performs the action) and "action" (the activity), and may contain "target" (what the action is directed toward). Additional useful fields include "hand", "tool", "target_part", and "direction". The action vocabulary is intentionally open-ended and normally uses concise verb-like machine strings. The optional "duration" field is qualitative rather than clock-based. Standard SBL 1.0 values are "instant", "brief", "sustained", and "continuous". These values describe how persistent the depicted action is in story state; they do not specify seconds, frames, shot length, or synchronization. Exact or approximate storyboard timing belongs in a "direction" record of type "temporal" until a later SBL profile defines formal timing.

```json
{
  "actions":
  [
    {
      "subject": "midori",
      "action": "open",
      "target": "wooden_door_1",
      "hand": "right"
    }
  ]
}
{
  "actions":
  [
    {
      "subject": "midori",
      "action": "read",
      "target": "book_1",
      "duration": "sustained"
    }
  ],
  "pose":
  [
    {
      "target": "midori",
      "type": "sitting",
      "on": "chair_3"
    }
  ]
}
{
  "actions":
  [
    {
      "subject": "midori",
      "action": "point",
      "target": "beli",
      "hand": "right"
    }
  ]
}
```

SBL does not attempt to define an exhaustive action vocabulary. Common verbs such as "open", "close", "read", "write", "point", "walk", "run", "pour", "lift", "place", "turn", and "speak" are descriptive action values. When exact physical contact matters, pair the action with an "interactions" entry so the resolver can state precisely which body part contacts which target.

### Events

Requirements — "events" is optional. Each event requires "id" and "type". "source" and "visibility" are optional. When present, "source" MUST use one of the defined source forms below. SBL 1.0 does not define a separate event "location" field; use source and ordinary setting/blocking references instead.

Events describe occurrences in the scene. Unlike an action, an event does not require an intentional actor. An explosion, a door suddenly slamming, a gust of wind, a light flickering, or an object breaking may all be events. Events may originate on-panel, off-panel, or from an indirect/environmental cause, and their consequences may be visible even when the source is not.

An event requires "id" and "type". "source" identifies where the event originates when known. SBL 1.0 defines three source forms: (1) {"object": "<ref>"} for an originating object/entity; (2) {"type": "environment"} for an environmental/indirect source; and (3) a point source with "space": "stage" or "screen". A stage point requires horizontal and depth and may include elevation; a screen point requires normalized x and y. "visibility.source" describes the source relative to the frame using "on_panel", "off_panel", or "partial" and defaults to "on_panel". "visibility.indirect_effects" defaults to false and permits visible consequences even when the source is not fully visible.

```json
{
  "events": [
    {
      "id": "explosion_1",
      "type": "explosion",
      "source": {
        "space": "stage",
        "horizontal": "stage_right",
        "depth": "upstage"
      },
      "visibility": {
        "source": "off_panel",
        "indirect_effects": true
      }
    }
  ]
}
```

In this example the explosion itself MUST NOT be drawn because its source is off-panel. The panel may nevertheless show the flash, debris, dust, hair/clothing movement, or character reactions caused by it. A separate SFX entry may display "FWOOM!" and reference "explosion_1".

```json
{
  "events":
  [
    {
      "id": "vase_break_1",
      "type": "break",
      "source":
      {
        "object": "vase_1"
      },
      "visibility":
      {
        "source": "on_panel",
        "indirect_effects": true
      }
    }
  ]
}
{
  "events":
  [
    {
      "id": "wind_gust_1",
      "type": "wind_gust",
      "source":
      {
        "type": "environment"
      },
      "visibility":
      {
        "source": "off_panel",
        "indirect_effects": true
      }
    }
  ]
}
```

Events may cause changes in expression, pose, action, lighting, or other visible state, but those effects should be stated explicitly when they are important. For example, an explosion event does not automatically imply that Midori looks surprised; add an "expression" entry when that reaction is required.

#### Distinguishing Expression, Action, Interaction, and Event

These constructs deliberately overlap in real scenes but answer different questions. "expression" says how a character visibly looks; "pose" says the broad physical posture; "actions" say what an entity is doing; "interactions" specify required physical contact/relationships; and "events" say what occurs in the scene, whether or not an intentional actor causes it.

For example, a panel might contain an explosion event, Midori with a surprised expression, Midori performing the action "turn", and an interaction requiring her right hand to grasp Beli's wrist. Keeping these facts separate lets the resolver preserve each requirement independently.

### Camera and Composition

Requirements — "camera" and "composition" are optional. No camera child field is universally required. camera.angle defaults to "eye_level"; other omitted camera/composition properties remain unspecified unless inherited or otherwise defaulted.

Camera describes where and how the viewer sees the scene. Composition describes how subjects are arranged inside that camera frame. These properties affect presentation, not story-world identity: moving the camera does not move the characters in the fictional world.

#### Shot Size

The "shot" property controls how much of the subject and environment appear in frame. SBL 1.0 defines the following standard values:

a. "extreme_wide" — the environment dominates; people may be very small. Useful for geography, establishing scale, or showing a large location.

b. "wide" — shows substantial environment and the full spatial relationship among subjects.

c. "full" — normally shows a standing character from head to feet with some surrounding environment.

d. "medium_full" — approximately head to knees or mid-thigh; useful when gesture and body language matter.

e. "medium" — approximately waist-up; a common conversational framing.

f. "medium_closeup" — approximately chest/shoulders-up; emphasizes face while retaining some body language.

g. "closeup" — primarily the face/head or an equivalently tight subject detail.

h. "extreme_closeup" — isolates a very small detail such as eyes, mouth, hand, object control, or other critical feature.

#### Camera Angle

The "angle" property describes the camera's vertical relationship to the principal subject. Standard values are:

a. "birds_eye" — viewed from very high overhead; emphasizes layout and spatial pattern.

b. "high" — camera above the subject looking downward.

c. "eye_level" — camera approximately at the subject's eye height; neutral default.

d. "low" — camera below the subject looking upward.

e. "worms_eye" — extremely low viewpoint looking sharply upward; strongly exaggerates height and scale.

#### Camera Orientation

The optional "orientation" describes which side of the subject the camera sees: "front", "three_quarter_front", "profile", "three_quarter_back", or "back". This is camera-relative and is separate from the character's own body orientation.

#### Lens and Projection

Fisheye and barrel-distorted wide-angle views are optical/projection effects, not shot sizes or camera heights. SBL therefore places them in "lens.type". Standard lens types are "normal", "wide", "telephoto", "fisheye", and "wide_barrel".

a. "normal" — minimal intentional perspective distortion.

b. "wide" — wide field of view with stronger perspective expansion near the frame edges.

c. "telephoto" — narrow field of view with visually compressed depth.

d. "fisheye" — extreme curvilinear projection; straight lines may bow dramatically and the field of view may approach or exceed 180 degrees.

e. "wide_barrel" — wide-angle view with intentional barrel distortion; less extreme than fisheye but visibly bows lines outward near the edges.

#### Focus and Composition

"focus" identifies the visual emphasis. It may name a target id or use "foreground", "midground", "background", or "group". The "composition" object may identify "primary_subject" and may optionally provide a "style" such as "centered", "rule_of_thirds", "symmetrical", "asymmetrical", "leading_space_left", "leading_space_right", or "negative_space". These are compositional guides rather than geometric replacements for blocking.

```json
{
  "camera":
  {
    "shot": "wide",
    "angle": "eye_level",
    "orientation": "three_quarter_front",
    "lens":
    {
      "type": "normal"
    },
    "focus": "group"
  },
  "composition":
  {
    "primary_subject": "midori",
    "style": "rule_of_thirds"
  }
}
```

This example asks for a wide, eye-level three-quarter-front view with ordinary perspective. The group remains readable, Midori is the principal visual subject, and rule-of-thirds composition guides where she should fall within the frame. The camera description does not replace blocking: the characters still need their own spatial relationships or arrangement when those relationships matter.

#### Camera Examples

```json
{
  "camera":
  {
    "shot": "extreme_wide",
    "angle": "high",
    "lens":
    {
      "type": "wide"
    },
    "focus": "midori"
  }
}
```

An extreme-wide/high-angle shot emphasizes the environment and Midori's position within it. This is useful for establishing a classroom, plaza, corridor, battlefield, or other large location.

```json
{
  "camera":
  {
    "shot": "closeup",
    "angle": "eye_level",
    "orientation": "front",
    "lens":
    {
      "type": "telephoto"
    },
    "focus": "midori"
  },
  "composition":
  {
    "primary_subject": "midori",
    "style": "centered"
  }
}
```

A close-up with a telephoto treatment isolates Midori's face and compresses background depth. It is appropriate for dialogue, emotional reaction, or other moments where facial detail matters.

```json
{
  "camera":
  {
    "shot": "medium",
    "angle": "eye_level",
    "lens":
    {
      "type": "fisheye"
    },
    "focus": "midori"
  }
}
```

The fisheye example deliberately distorts straight lines and proportions near the edges. Use it as a stylistic effect, not as a substitute for an ordinary wide shot. Similarly, "wide_barrel" produces a wide-angle image with visible barrel distortion while remaining less extreme than fisheye.

### Lighting

Requirements — "lighting" is optional. When present it may contain "environment" and/or "shot". lighting.environment describes illumination that exists in the fictional scene. lighting.shot describes panel-specific photographic, cinematographic, or artistic treatment. lighting.shot.mode defaults to "clear".

Lighting separates story-world illumination from shot presentation. Both branches continue between ordinary consecutive panels, but only environmental lighting is captured and restored by checkpoints.

```json
"lighting":
{
  "environment": { },
  "shot": { "mode": "clear" }
}
```

#### Environmental Lighting

lighting.environment describes illumination physically or fictionally present in the scene: ambient illumination, sunlight, window light, fire, practical fixtures, emissive objects, magical/divine environmental illumination, power failures, emergency illumination, and physical directional/point/spot/area sources. Environmental lights MAY identify a physical source.

Environmental lighting is sequentially persistent, is captured by checkpoints, and is restored from checkpoints.

#### Shot Lighting

lighting.shot describes how effective scene illumination is presented in the current panel. It may contain key, fill, rim, background, accent, or other shot-specific lights. Camera-relative lighting positions belong to shot lighting.

Shot lighting is sequentially persistent during ordinary continue processing. It is NOT captured by checkpoints and is NOT restored from checkpoints.

#### Lighting Mode

lighting.shot.mode standard values are "clear", "naturalistic", "high_key", "low_key", "dramatic", "silhouette", and "custom". "clear" is the normative default.

#### Light Roles and Source Types

Standard shot-light roles are "key", "fill", "rim", "background", "accent", and "practical" where appropriate. Standard source/geometry types remain "ambient", "directional", "point", "spot", "area", "sun", "window", "fire", "practical", and "emissive_object". Source type alone does not determine branch.

#### Camera-Relative Shot-Light Position

For shot lighting, standard camera-relative positions are "front", "front_left", "front_right", "left", "right", "back_left", "behind", "back_right", "above", and "below". These are not story-world blocking coordinates.

#### Shared Lighting Properties

quality, intensity, color, color_temperature, contrast, and shadows MAY occur in the applicable environment or shot structure. Environmental values describe scene illumination; shot values describe presentation treatment and do not modify persistent environmental lighting.

```json
"lighting":
{
  "environment":
  {
    "ambient": { "level": "high", "color_temperature": 5000 },
    "contrast": "low",
    "shadows": "soft"
  },
  "shot": { "mode": "clear" }
}
```

A later panel may override only lighting.shot while environmental illumination continues unchanged. Explicit inherit.preserve containing "lighting" copies the complete effective lighting property, including both branches.

### Dialogue and Speech Balloons

Requirements — "dialogue" is optional. Every dialogue item MUST contain "id", "speaker", and SBL Text "content". "speaker" is always an array and MAY be empty for tailless/no-speaker text. Delivery, balloon, placement, and connection fields are optional and use the normative defaults where defined.

The "dialogue" array contains spoken dialogue, thoughts, and other balloon text. Each element describes one displayed utterance: who speaks, the literal text, delivery, balloon appearance, and optional links to neighboring dialogue items.

#### Speaker

The "speaker" field is always an array of machine ids. One element is ordinary speech from one character. Multiple elements mean all listed characters speak the same displayed text together; the shared balloon MUST visually associate itself with every listed speaker, normally by drawing one tail to each speaker. An empty array means the text has no speaker target and therefore no tail. Because "speaker" already determines the tail target, "tail.target" does not exist in SBL.

```json
"speaker":
[
  "midori"
]
"speaker":
[
  "midori",
  "beli"
]
"speaker":
[
]
```

#### Dialogue Text and Delivery

"content" is SBL Text containing the authored dialogue exactly as it should be displayed. A renderer MUST NOT paraphrase or rewrite it. For multiline authored text in the simple-string representation use the JSON escape sequence "\n"; rich formatting uses SBL Text "runs".

"delivery.volume" describes vocal loudness: "whisper", "quiet", "normal", "loud", or "scream". "delivery.transmission" describes how the voice reaches the scene: "direct", "telephone", "radio", "television", "pa_system", "intercom", "communicator", "recording", or "synthetic". Transmission does not imply that the speaker is physically visible. When "delivery.volume" is "whisper", the renderer SHOULD make the whisper unmistakable; one permitted treatment is to include the literal cue “(whisper)” inside the balloon before the spoken text when the author or production style requests that convention.

#### Balloon Fields

The optional "balloon" object controls the visual container. If omitted for ordinary speech, use a normal oval speech balloon and derive its tail from "speaker".

"shape" — Suggested values: "oval" (ordinary speech), "round", "rect" (box), "thought_cloud", "jagged" (shout/alarm), "rough" (strained/agitated), and "custom".

"tail.display" — Boolean. true draws a tail/trail; false suppresses it. An empty speaker array always produces no speaker tail.

"tail.anchor" — Attachment approach at the speaker: "mouth", "head", "hand", or "auto". Ordinary speech defaults to "mouth"; thoughts normally use "head".

"tail.length" — "short", "medium", or "long". The default is "medium". Longer tails permit the balloon to be positioned farther from its speaker.

"tail.routing" — "straight", "curved", "elbow", or "zigzag". The default is "straight". "straight" uses a direct straight path; "curved" uses a smooth curve; "elbow" uses one or more deliberate angular bends; "zigzag" uses repeated sharp bends for unusual, electronic, or agitated treatments.

"tail.attachment" — "seamless", "detached", or "trail". Ordinary speech defaults to "seamless". A seamless tail and its balloon body form one continuous filled silhouette. "detached" is reserved for an explicitly authored stylized effect and MUST NOT be inferred merely because body and tail were constructed separately. "trail" is used for thought-dot or similar non-contact trails.

"tail.base_shape" — "curved", "straight", "angular", or "custom". Ordinary oval and round speech balloons default to "curved" so the sides of the tail flow smoothly into the balloon body.

"tail.outline" — "unified" or "independent". Ordinary speech defaults to "unified". A unified outline is computed around the exterior union of the balloon body and tail; it MUST NOT draw the balloon body's border across the tail base.

**Ordinary speech-balloon join rule.** Unless the author explicitly requests a detached special effect, an ordinary speech balloon MUST use `tail.attachment="seamless"` and `tail.outline="unified"`. The renderer MUST combine the body and tail before fill and outline are applied, producing one uninterrupted exterior contour. A separately outlined triangle, an internal line across the tail base, a visible gap, or an overlapping appendage is a renderer failure.

"tail.position" — Preferred balloon exit: "auto", "bottom", "bottom_left", "bottom_right", "left", "right", "top_left", or "top_right".

"placement.mode" — "automatic", "relative", or "absolute". "automatic" has no required child fields. Automatic placement remains subject to page production-area constraints: when a safe rectangle exists, the renderer MUST place the complete balloon body and lettering inside it. "relative" requires "target" and positions the balloon relative to that target; "position" may be "above", "below", "left", "right", "upper_left", "upper_right", "lower_left", or "lower_right" and defaults to "above". Optional "offset_x" and "offset_y" are signed normalized panel-space deltas from that relative placement and each ranges from -1.0 through 1.0. "absolute" requires normalized "x" and "y" panel coordinates.

"placement.x / placement.y" — Normalized 0.0–1.0 coordinates used only when placement.mode is "absolute". "placement.offset_x / placement.offset_y" are signed normalized offsets used only for relative placement. All of these are screen-space presentation coordinates, not story-world coordinates.

"padding" — "tight", "normal", or "loose" interior spacing between text and balloon edge.

"text.align" — "left", "center", or "right"; center is the normal comic/manga default.

"emphasis" — Suggested values: "normal", "bold", "whisper", "yell", "shout", or "thought". It guides typography/outline treatment without changing content.

"fill" — "white", "transparent", "tone", "gradient", or "custom".

"border.width" — "thin", "medium", or "thick".

"border.style" — "solid", "dashed", "rough", or "none".

##### Relative balloon placement example

```json
"placement":
{
  "mode": "relative",
  "target": "midori",
  "position": "upper_right",
  "offset_x": 0.03,
  "offset_y": -0.02
}
{
  "id": "d1",
  "speaker":
  [
    "midori"
  ],
  "content": "Are you ready?",
  "delivery":
  {
    "volume": "normal",
    "transmission": "direct"
  },
  "balloon":
  {
    "shape": "oval",
    "tail":
    {
      "display": true,
      "anchor": "mouth",
      "length": "medium",
      "routing": "curved",
      "position": "bottom_left"
    },
    "placement":
    {
      "mode": "automatic"
    },
    "padding": "normal",
    "text":
    {
      "align": "center"
    },
    "fill": "white",
    "border":
    {
      "width": "thin",
      "style": "solid"
    }
  }
}
```

#### Connected Dialogue

Connected dialogue is a chain of separate balloons that visually belong to one continuing utterance. Each balloon remains a separate dialogue item with its own id and content. "next" names the following connected item; "prev" may name the preceding connected item. "connector" may be "touching", "overlap", "bridge", or "none". When a visible connection is established and "connector" is omitted, it defaults to "touching" because this is the compact ordinary connected-balloon treatment.

For a same-speaker chain, the first balloon draws its speaker tail by default. A later dialogue item whose "prev" connects it to an item with the same speaker array defaults to "balloon.tail.display": false. The entire chain belongs to the same visible speaker, so the renderer MUST NOT duplicate the character for each balloon. Explicit "balloon.tail.display" or "connector" values override these defaults.

```json
{
  "dialogue":
  [
    {
      "id": "d1",
      "speaker": ["midori"],
      "content": "We can do this.",
      "next": "d2",
      "balloon":
      {
        "tail":
        {
          "display": true,
          "anchor": "mouth"
        }
      }
    },
    {
      "id": "d2",
      "speaker": ["midori"],
      "content": "Stay focused.",
      "next": "d3",
      "prev": "d1",
      "balloon":
      {
        "tail":
        {
          "display": false
        }
      }
    },
    {
      "id": "d3",
      "speaker": ["midori"],
      "content": "And trust each other.",
      "prev": "d2",
      "balloon":
      {
        "tail":
        {
          "display": false
        }
      }
    }
  ]
}
```

A resolver MUST verify that "next"/"prev" references resolve, agree with each other, and do not form accidental cycles. The order of elements in the enclosing "dialogue" array establishes semantic reading order. "next" and "prev" establish only visual balloon connections and MUST NOT reorder dialogue items. The renderer should arrange connected balloons so the visible layout remains compatible with the array-defined reading order.

#### Interleaved Dialogue

Interleaved dialogue places two or more connected same-speaker balloon chains into one physical reading sequence. The reading order is the order of the dialogue items in the "dialogue" array. "next" and "prev" do NOT establish reading order; they identify only the balloons that are visually connected into the same speaker chain.

Because array order determines reading order, connected balloons do not have to be adjacent in the array. For example, d1 and d3 may form Midori’s connected chain while d2 and d4 form Beli’s connected chain; the array order d1, d2, d3, d4 still tells the reader to read the balloons in that interleaved order. Under the same-speaker-chain default, only the first balloon of each connected chain has a tail; later balloons connected by "prev" suppress their speaker tail unless explicitly overridden. Omitted connectors default to "touching".

```json
{
  "dialogue":
  [
    {
      "id": "d1",
      "speaker":
      [
        "midori"
      ],
      "content": "Did you finish the report?",
      "next": "d3"
    },
    {
      "id": "d2",
      "speaker":
      [
        "beli"
      ],
      "content": "Almost. Just the charts.",
      "next": "d4"
    },
    {
      "id": "d3",
      "speaker":
      [
        "midori"
      ],
      "content": "Great. Let's review it together.",
      "prev": "d1"
    },
    {
      "id": "d4",
      "speaker":
      [
        "beli"
      ],
      "content": "Sounds good to me.",
      "prev": "d2"
    }
  ]
}
```

In the example below, array order establishes the reading sequence d1 → d2 → d3 → d4. The connection fields independently establish two visual chains: Midori d1 ↔ d3 and Beli d2 ↔ d4. d1 has the single tail to Midori; d2 has the single tail to Beli; d3 and d4 have no tails.

#### Special Cases

Multiple entries in one "speaker" array mean simultaneous shared speech in one balloon. That is different from interleaving, where each speaker has a separate dialogue item.

An empty "speaker" array means no speaker tail. It may be used for narration-like text, an unattributed voice, signage-style text, or another deliberately tailless balloon/box treatment.

Thoughts normally keep the thinker in "speaker", use "shape": "thought_cloud", and use a head-anchored thought trail. Electronic/off-panel speech keeps the semantic speaker but may suppress or modify the tail because the physical voice originates from a device or outside the panel.

### Footnotes

Requirements — Footnotes are panel-local textual annotations. SBL supports a Simple Form for the common one-off case and a General Form for named footnotes. Footnote bugs are one or more superscript asterisks assigned automatically in first-use order within the panel. Bug numbering restarts with * in every panel.

#### Simple Form

The Simple Form attaches exactly one anonymous one-off footnote directly to an identified renderable textual item. The "footnote" value is SBL Text containing the footnote content. The bug is automatically appended to the end of the item's displayed content.

```json
{
  "id": "sign_1",
  "target": "signboard",
  "content": "関係者以外立入禁止",
  "footnote": "Authorized personnel only."
}
```

The Simple Form is intended for the common one-text-item/one-footnote case, especially translations and short explanatory notes. A Simple-Form footnote has no author-visible or addressable id. It MUST NOT be referenced elsewhere, and a processor MUST NOT expose any generated/internal identity as an SBL reference target. If the bug must appear somewhere other than the end of the content, the same note must be referenced more than once, multiple footnotes must attach to one textual item, or explicit identity is otherwise required, use the General Form.

The Simple Form MAY be used on identified renderable textual items whose grammar permits it, including dialogue items, narration items, SFX items, and text_objects. Its semantics are the same in each case.

#### General Form

The General Form declares named footnotes in the containing panel's "footnotes" array. Each footnote MUST contain a panel-local machine "id" and SBL Text "content".

```json
"footnotes":
[
  {
    "id": "fn_ohayo",
    "content": "\"Ohayō\" means \"Good morning.\""
  }
]
```

Renderable SBL Text in the same panel references a General-Form footnote using {footnote:footnote_id} at the exact position where the superscript bug should appear.

```json
"content": "Ohayō{footnote:fn_ohayo}"
```

General-Form footnote ids are visible only within their containing logical panel. The same local footnote id MAY be reused in another panel for an unrelated note. Cross-panel qualification of footnote ids is prohibited: a form such as {footnote:P23S2::fn_translation} is invalid even if that panel and id exist. If the same explanation is needed on another panel, declare a footnote on that panel.

A General-Form footnote MAY be referenced more than once within its panel. Every reference to the same id uses the same bug, and the footnote appears only once in the footnote box. Nested footnotes are prohibited: footnote content MUST NOT contain {footnote:...} references. Footnote content MAY contain ordinary anchor substitutions such as {ref:flood_story.page}.

#### Bug Assignment and Reading Order

Distinct footnotes are assigned bugs by first reference in the panel's effective textual reading order, not by declaration order in the "footnotes" array. The first distinct referenced footnote uses *, the second **, the third ***, and so on without a fixed language-level maximum. A Simple-Form footnote behaves for ordering purposes as though an anonymous footnote reference occurred immediately after the end of its associated content.

If a panel uses both Simple and General forms, all distinct footnotes participate in the same first-use sequence. Repeated references to one General-Form footnote do not consume additional bug values.

#### Footnote Box and Layout

All referenced footnotes in a panel are collected into one small rectangular footnote box at the bottom inside edge of that panel. The box MUST remain within panel boundaries, use a readable background and simple border, and use smaller but legible text than ordinary dialogue. Footnotes are listed in bug order.

The footnote box participates in layout. A renderer MUST reserve sufficient space for the fully resolved footnote box before composing critical artwork and text; it MUST NOT merely paste the box over completed artwork. Characters, balloons, important props, and other critical content should therefore be composed around the reserved region.

Only referenced General-Form footnotes are displayed. An unreferenced declared footnote is not rendered and SHOULD produce an unreferenced_footnote warning.

#### Multiple Footnotes Design Warning

More than one distinct referenced footnote in a panel is valid SBL, but a processor SHOULD issue a non-fatal multiple_panel_footnotes warning recommending that the author consider redesigning the page/panel or redistributing the explanatory material. The warning applies to the total number of distinct referenced footnotes regardless of whether they use the Simple Form, General Form, or both.

#### Resolution and Persistence

Anchor substitutions inside footnote content are resolved before footnote sizing. Footnote references and first-use bug assignment are then resolved before panel text/layout. Footnotes are panel-local moment-specific textual content: they do not participate in sequential continue, checkpoint capture, checkpoint restore, or explicit panel inheritance.

A conforming processor should distinguish at least these diagnostics: unresolved_footnote and duplicate_footnote_id are errors; unreferenced_footnote and multiple_panel_footnotes are warnings.

### Narration

Requirements — "narration" is optional. Each narration item MUST contain "id" and SBL Text "content". "box" and normalized screen "placement" are optional. If placement is omitted, the renderer chooses a compositionally appropriate position, subject to any page safe-area constraint; the complete narration box and lettering MUST remain inside the safe rectangle when one is defined. Array order establishes narration reading order.

Narration is textual storytelling information that is not spoken by a character physically present in the panel. Each narration item's "content" is SBL Text. Narration normally appears in a rectangular box with no speech tail. The order of elements in the "narration" array establishes narration reading order. SBL 1.0 does not define a separate narration "presentation" object; narration appearance is controlled by SBL Text formatting, the optional "box" object, and placement.

Explicit placement example:

```json
{
  "id": "n1",
  "content": "Three days later...",
  "placement":
  {
    "x": 0.15,
    "y": 0.08,
    "anchor": "top_left"
  }
}
{
  "narration":
  [
    {
      "id": "n1",
      "content": "Later that afternoon...",
      "box":
      {
        "shape": "rect",
        "fill": "white",
        "border":
        {
          "width": "thin",
          "style": "solid"
        }
      }
    }
  ]
}
```

Because narration has no physical speaker target, it does not use a speech tail. A narrative voice may be recorded separately when the identity of the narrator matters, but that identity does not imply physical presence in the panel.

```json
{
  "narration":
  [
    {
      "id": "n1",
      "content": "For three days, nothing happened."
    },
    {
      "id": "n2",
      "content": "Then, on the fourth morning..."
    }
  ]
}
```

The first box is read before the second because n1 precedes n2 in the array. Narration boxes may use the shared normalized screen "placement" object when explicit positioning is required; otherwise the renderer positions them compositionally.

### Sound Effects (SFX)

Requirements — "sfx" is optional. Each SFX item MUST contain "id" and SBL Text "content". "source", graphical style, and normalized screen "placement" are optional unless the production requires explicit source binding or positioning.

Sound effects (SFX) represent sound as visible text in the panel. SFX is not dialogue and is not placed inside a speech balloon unless a character is literally speaking the sound-effect word.

The "content" field is SBL Text containing the exact visible sound text. "source" may identify the event or object producing the sound. The optional "style" object controls SFX presentation. Suggested size values are "small", "medium", "large", and "huge"; weight values include "normal" and "bold"; shape values may include "impact", "subtle", "rhythmic", "rough", or another renderer-understandable descriptive value. SBL Text runs may be used when different parts of one SFX require different typographic treatment.

Explicit placement example:

```json
{
  "id": "sfx1",
  "content": "FWOOM!",
  "source": "explosion_1",
  "placement":
  {
    "x": 0.78,
    "y": 0.42,
    "anchor": "center"
  }
}
{
  "sfx":
  [
    {
      "id": "sfx1",
      "content": "FWOOM!",
      "source": "explosion_1",
      "style":
      {
        "size": "large",
        "weight": "bold",
        "shape": "impact"
      }
    },
    {
      "id": "sfx2",
      "content": "creak...",
      "source": "door_1",
      "style":
      {
        "size": "small",
        "weight": "normal",
        "shape": "subtle"
      }
    },
    {
      "id": "sfx3",
      "content": "TAP TAP TAP",
      "source": "footsteps_1",
      "style":
      {
        "size": "medium",
        "weight": "bold",
        "shape": "rhythmic"
      }
    }
  ]
}
```

SFX placement is graphical. The renderer may place the text near its source or where it best serves the composition unless the shared normalized screen "placement" object is supplied. An off-panel event may still have visible SFX: an off-panel explosion can produce "FWOOM!" without drawing the explosion itself.

### Visual Effects

Requirements — "effects" is optional. Each effect MUST contain "id" and "type". Target/origin, intensity, color, and effect-specific properties are optional unless needed by the selected effect.

Visual effects are graphical phenomena added to the rendered scene. They may emphasize motion or impact, represent environmental phenomena, show magical or technological energy, or alter the visual atmosphere.

The "type" field is intentionally open-ended rather than a closed enumeration. Authors may use any concise visual-effect description that the renderer can reasonably interpret. Suggested values include "speed_lines", "impact_lines", "motion_blur", "glow", "aura", "sparkles", "smoke", "dust", "debris", "mist", "rain", "snow", "light_rays", "lens_flare", "heat_distortion", and "magic_energy". "intensity" may use "mild", "moderate", "strong", and "extreme" when applicable.

```json
{
  "effects":
  [
    {
      "id": "effect1",
      "type": "speed_lines",
      "target": "midori",
      "intensity": "strong"
    },
    {
      "id": "effect2",
      "type": "impact_lines",
      "origin": "explosion_1",
      "intensity": "strong"
    },
    {
      "id": "effect3",
      "type": "glow",
      "target": "mana_orb",
      "intensity": "moderate",
      "color": "blue"
    }
  ]
}
```

A visual effect may target a character or object, originate from an event, or apply to the environment generally. Effects do not automatically create events: "impact_lines" can illustrate an already-defined explosion event, while a "glow" can simply describe the appearance of an existing mana orb.

#### Narration, SFX, and Visual Effects Compared

Narration is textual storytelling information that is not spoken by a character physically present in the panel. Each narration item's "content" is SBL Text. Narration normally appears in a rectangular box with no speech tail. The order of elements in the "narration" array establishes narration reading order.

### Constraints and Validation

Requirements — "constraints" and "validation" are optional arrays. SBL 1.0 defines the standard constraint types "event_source_visibility", "property_value", and "relative_position", and the standard validation types "speech_tail" and "reference_resolves". Standard records MUST use the fields defined below. Extension types are permitted only when their type is explicitly namespaced in the form "namespace:name". Every "strength" field uses "required", "preferred", "discouraged", or "forbidden".

```json
{
  "constraints":
  [
    {
      "type": "event_source_visibility",
      "target": "explosion_1",
      "value": "off_panel",
      "strength": "required"
    }
  ],
  "validation":
  [
    {
      "type": "speech_tail",
      "dialogue": "d1",
      "must_match_speaker": true
    }
  ]
}
```

Constraints state what the renderer should produce; validation states what should be checked afterward. "event_source_visibility" requires "target" (an event id), "value" ("on_panel", "off_panel", or "partial"), and optional "strength" (default "required"). "property_value" requires "target", dotted "property", "value", and optional "strength" (default "required"). "relative_position" requires "subject", "relation", and the same singular "object" or two-item "objects" form used by blocking relationships, plus applicable "space" and optional "strength" (default "required"). "speech_tail" requires "dialogue" and Boolean "must_match_speaker". "reference_resolves" requires "reference". Namespaced extension records may carry implementation-specific fields, but standard unnamespaced unknown types are invalid.

#### Standard constraint and validation forms

```json
{
  "constraints":
  [
    {
      "type": "property_value",
      "target": "midori",
      "property": "visibility",
      "value": "visible",
      "strength": "required"
    }
  ],
  "validation":
  [
    {
      "type": "reference_resolves",
      "reference": "midori"
    }
  ]
}
```

## Production and Continuity Features

This section defines production-oriented SBL features for reusable resources, continuity, precise visibility, character/object state, camera continuity, compositing, and renderer control.

### Resource Definitions and Reference Resolution

SBL references such as character sheets, costumes, locations, and props require a formal resource model. A resource table associates a stable SBL resource id with an external file and its intended purpose.

```json
{
  "resources":
  {
    "Midori_character_sheet":
    {
      "type": "image",
      "file": "Midori-Character-Sheet.png",
      "purposes":
        [
          "character_identity"
        ]
    },
    "academy_corridor":
    {
      "type": "sbl",
      "file": "academy_corridor.sbl.json"
    }
  }
}
```

Resource ids should be stable and resolvable by an SBL processor. Imports make resource libraries available; the resolver expands required resource information into a self-contained render request when necessary.

#### Example

A character or location may declare visual resources once; the resolver follows the references and supplies them with the resolved panel. The canonical SBL 1.0 "resources" representation is an object keyed by resource machine id. Resource ids are therefore the object member names rather than repeated "id" fields inside an array.

```json
{
  "resources":
  {
    "midori_character_sheet":
    {
      "type": "image",
      "file": "references/Midori-Zora.png",
      "purposes":
      [
        "character_identity"
      ]
    },
    "academy_classroom_ref":
    {
      "type": "image",
      "file": "references/Academy-Classroom.png",
      "purposes":
      [
        "architecture_reference"
      ]
    }
  },
  "references":
  {
    "characters":
    {
      "midori": "midori_character_sheet"
    },
    "locations":
    {
      "academy_classroom": "academy_classroom_ref"
    }
  }
}
```

### Identifier Scope

SBL uses cascading declaration scope. An entity declared at a broader scope is inherited by all descendant scopes unless a narrower scope overrides that entity or explicitly suppresses its presence. The declaration site determines scope; a separate scope property is normally unnecessary.

```json
{
  "script":
  {
    "characters":
    [
      {
        "id": "student_1",
        "type": "anonymous",
        "role": "student"
      }
    ]
  }
}
```

In this example student_1 is defined at script scope and is therefore available throughout the script by default.

A narrower scope may suppress an inherited entity without deleting its broader definition:

```json
{
  "id": "P40A",
  "characters":
  [
    {
      "id": "student_1",
      "present": false
    }
  ]
}
```

A narrower panel scope may suppress an inherited entity without deleting its broader definition. Here P40A suppresses student_1 only for that panel.

```json
{
  "id": "P41A",
  "characters":
  [
    {
      "id": "student_1",
      "present": true
    }
  ]
}
```

On a later panel, the broader definition becomes effective again. An explicit "present": true may restore the inherited entity when a still-visible narrower suppression would otherwise apply.

For generative rendering, present:false is primarily a source-language control. Suppressed entities should normally be omitted entirely from the resolved render specification rather than sent to the image generator as inactive characters. This reduces the number of competing identities the renderer must track and should improve character fidelity.

#### Example

This example shows a local id and a qualified reference to it from another page.

```json
{
  "id": "P40",
  "panels":
  [
    {
      "id": "P40A",
      "characters": [ { "id": "student_1", "name": "Student" } ]
    }
  ]
}
```

From another object or page, the same entity is referenced with the qualified string "P40::student_1".

### Character Scale and Canonical Dimensions

Requirements — Canonical dimensions and character scale are optional. SBL 1.0 canonical_dimensions defines canonical character height only. Each entry therefore requires positive numeric "height" and explicit "height_units" using a standard physical-distance unit. A character scale, when supplied, is a positive relative multiplier.

Character scale separates canonical story-world height from requested rendered size. In SBL 1.0, canonical_dimensions intentionally records height only; additional canonical body measurements are deferred to a future version. "scale" is a relative rendering multiplier and does not rewrite canonical height.

```json
{
  "canonical_dimensions":
  {
    "midori": { "height": 147, "height_units": "cm" },
    "beli": { "height": 150, "height_units": "cm" }
  },
  "characters":
  [
    { "id": "midori", "scale": 1.0 },
    { "id": "beli", "scale": 0.85 }
  ]
}
```

Use canonical dimensions when real relative height matters. Use scale for deliberate temporary resizing, transformed characters, miniatures, giants, diagrams, or stylized emphasis.

### Temporary Character Appearance State

Requirements — "appearance_state" is an optional array of target records. Each appearance-state record requires "target" and at least one state property. Even a single temporary appearance state uses a one-element array.

Temporary appearance state records visible changes that do not redefine canonical identity: wetness, dirt, blood, bruises, bandages, tears, sweat, soot, fatigue, torn clothing, disheveled hair, or temporary transformations.

```json
{
  "appearance_state": [
    {
      "target": "midori",
      "wet": true,
      "dirty": true,
      "injuries": [
        {
          "type": "bandage",
          "location": "left_forearm"
        }
      ],
      "clothing": {
        "condition": "muddy"
      },
      "details": "tired eyes; loose wet hair"
    }
  ]
}
```

Simple states may be booleans; location/severity-sensitive states should use structured objects. Temporary appearance state is sequentially persistent under ordinary continue processing and may also be copied through explicit inheritance. It is captured and restored by checkpoints as character_appearance.

### Visibility, Cropping, and Occlusion

Requirements — "visibility" is an optional target-keyed array. Each visibility record requires "target" and at least one visibility/cropping/occlusion instruction. Each target may appear at most once in one visibility array. Omitted crop and occlusion fields impose no crop or occlusion requirement.

Visibility, cropping, and occlusion are independent concepts and MAY be combined. "visibility" answers whether the entity is intended to appear at all. Valid values are "visible", "partial", "hidden", and "off_panel". "visible" means the entity appears normally; "partial" means only part is intended to be visible; "hidden" means the entity is within the scene/panel area but should not itself be visible; "off_panel" means the entity lies outside the visible frame. Cropping answers how the frame cuts through an entity and is expressed separately with "crop". Occlusion answers what blocks the camera's view and is expressed separately with "occluded_by" and "occlusion_amount".

The optional "crop" field is omitted when no crop is intended. Standard crop values are "knees_up", "waist_up", "chest_up", "shoulders_up", "head_only", "left_half", "right_half", and "custom". "occluded_by" is an array of entity ids identifying foreground blockers. "occlusion_amount" may be "slight", "partial", "major", or "complete". A complete occlusion normally corresponds to "visibility": "hidden"; contradictory combinations such as "visibility": "visible" with "occlusion_amount": "complete" MUST be reported as an error.

```json
{
  "visibility":
  [
    {
      "target": "midori",
      "visibility": "visible"
    },
    {
      "target": "beli",
      "visibility": "partial",
      "occluded_by": ["pillar_1"],
      "occlusion_amount": "major"
    },
    {
      "target": "kenee",
      "visibility": "off_panel",
      "direction":
      {
        "horizontal": "stage_right",
        "depth": "upstage"
      }
    },
    {
      "target": "buren",
      "visibility": "partial",
      "crop": "waist_up"
    },
    {
      "target": "midori_2",
      "visibility": "partial",
      "crop": "waist_up",
      "occluded_by": ["railing_1"],
      "occlusion_amount": "partial"
    }
  ]
}
```

### Character and Object Interaction

Requirements — "interactions" is optional. Each interaction requires "actor", "action", and "target". actor_part, target_part, object, and strength are optional unless required to disambiguate the intended interaction.

Interactions specify required physical or functional relationships. Use them when the renderer must know exactly who contacts, holds, gives, receives, strikes, uses, supports, or manipulates what.

Common actions include: look_at, listen_to, approach, follow, leave; give, take, hand_to, receive_from, pass; point_at, show, indicate; touch, hold, grab, grasp, pull, push, hug, pat, comfort; attack, defend, block, dodge, strike, kick, punch; cast_spell, channel, dispel, heal; sit_on, sit_in, lean_on, rest_on, stand_on; open, close, lock, unlock; read, write, examine, inspect, use, operate; eat, drink, cook, serve; ride, mount, dismount; lift, carry, set_down, place, throw, catch.

Common target parts include body parts (head, face, hair, eye, ear, mouth, neck, shoulder, chest, back, arm, elbow, wrist, hand, finger, waist, leg, knee, ankle, foot), clothing parts (robe, sleeve, collar, sash, belt, hem, boot, glove, pocket), object parts (top, handle, edge, lid, screen, button, keyhole, blade, grip), and environmental parts (floor, wall, door, table, chair, railing, pillar, tree, window).

```json
{
  "interactions":
  [
    {
      "actor": "midori", "action": "hand_to", "target": "beli",
      "actor_part": "right_hand", "target_part": "hands",
      "object": "book_1", "strength": "required"
    },
    {
      "actor": "beli", "action": "touch", "target": "midori",
      "actor_part": "left_hand", "target_part": "shoulder",
      "strength": "required"
    }
  ]
}
```

Use "actor_part" and "target_part" when contact location matters. "object" identifies a third object being transferred/manipulated. Unless a construct explicitly defines otherwise, every SBL field named "strength" uses the standard Constraint Strength vocabulary: "required", "preferred", "discouraged", and "forbidden". Character/object interactions use that same vocabulary; "suggested" is not an SBL 1.0 strength value.

### Object State

Requirements — Object state is optional. A local object-state update requires the object "id" and a "state" object containing at least one state property.

Object state describes mutable properties at the moment shown: open/closed, lit/unlit, locked/unlocked, full/empty, broken/intact, powered/on/off, page number, displayed mode, and similar facts.

```json
{
  "objects":
  [
    { "id": "door_1", "state": { "open": true, "locked": false } },
    { "id": "book_1", "state": { "open": true, "page": 42 } },
    { "id": "torch_1", "state": { "lit": true, "flame": "steady" } }
  ]
}
```

State fields are object-specific and intentionally open-ended. Identity says what an object is; state says its current condition.

### Spatial Containment and Support Relationships

Requirements — Each spatial containment/support relationship requires "target", "type", and "reference". The relationship collection itself is optional.

Containment and support relationships state where an entity physically belongs relative to another entity and how it is supported. Common types include "inside", "on_top_of", "sitting_on", "sitting_in", "standing_on", "leaning_on", "attached_to", "hanging_from", "under", "beneath", "held_by", and "carried_by".

```json
{
  "relationships":
  [
    { "target": "midori", "type": "inside", "reference": "classroom_1" },
    { "target": "book_1", "type": "on_top_of", "reference": "desk_3" },
    { "target": "beli", "type": "sitting_on", "reference": "chair_2" },
    { "target": "torch_1", "type": "attached_to", "reference": "wall_1" },
    { "target": "banner_1", "type": "hanging_from", "reference": "beam_2" }
  ]
}
```

Relationships may chain into a spatial hierarchy: book_1 can be on desk_3 while desk_3 is inside classroom_1.

### Eyelines and Camera Continuity

Requirements — "eyelines" and "camera_continuity" are optional. An eyeline record requires "from" and "type"; "to" is required for types that address a specific entity. Camera-continuity fields are individually optional.

Eyelines say what a character visually addresses. Camera continuity preserves understandable screen relationships across successive panels, especially in conversations and action. Eyeline types include "look_at", "look_toward", and "look_off_panel". Continuity options include axis="maintain" (180-degree rule), screen_side="preserve", direction="preserve", and match="eyeline".

```json
{
  "eyelines":
  [
    { "from": "midori", "type": "look_at", "to": "beli" }
  ],
  "camera_continuity":
  {
    "axis": "maintain",
    "screen_side": "preserve",
    "direction": "preserve",
    "match": "eyeline"
  }
}
```

These are continuity instructions, not Cartesian coordinates. If Midori is screen-left looking screen-right toward Beli, a reverse shot should normally preserve that relationship unless the script intentionally crosses the axis. When both "orientation.gaze" and an "eyelines" record constrain the same character in the same effective panel state, they MUST be semantically consistent. A conflict between the two is a semantic validation error rather than permission for the renderer to choose one arbitrarily.

### Perspective

Requirements — "perspective" is optional. When present, "type" is REQUIRED. Horizon, depth, foreground emphasis, and atmospheric treatment are optional. When present, "atmospheric" uses "none", "mild", "moderate", or "strong".

Perspective describes how three-dimensional space is projected into the two-dimensional panel. Camera angle says where the camera is; perspective describes convergence and depth behavior. Types include "one_point", "two_point", "three_point", "orthographic", "isometric", "forced", and "atmospheric".

one_point uses one principal vanishing point (corridors and square-on interiors); two_point uses two horizontal vanishing points (building/object corners); three_point adds a vertical vanishing point (dramatic tall structures); orthographic keeps parallel lines parallel; isometric is a consistent technical/map-like view; forced deliberately exaggerates depth; atmospheric reduces contrast, saturation, and detail with distance.

```json
{
  "perspective":
  {
    "type": "two_point",
    "horizon": "eye_level",
    "depth": "deep",
    "foreground_emphasis": "normal",
    "atmospheric": "mild"
  }
}
```

Optional "horizon": "high", "eye_level", "low". "depth": "shallow", "normal", "deep". "foreground_emphasis": "reduced", "normal", "exaggerated". These are renderer instructions, not manually supplied vanishing-point coordinates. "atmospheric" uses "none", "mild", "moderate", or "strong".

### Background Treatment

Requirements — "background" is optional. When present, "mode" is REQUIRED. For "environment" and "abstract", "style" is REQUIRED. For "none" and "transparent", "style" MUST be omitted. "color" is optional when meaningful and MUST be omitted for "none" and "transparent".

Background treatment separates the broad kind of background from its artistic treatment. "mode" answers what kind of background is rendered. SBL 1.0 standard modes are "environment", "abstract", "none", and "transparent". "environment" renders the actual defined setting; "abstract" replaces the literal environment with a graphical or symbolic treatment; "none" intentionally draws no background; "transparent" requests an alpha-transparent background when supported.

For "environment" mode, standard styles are "detailed", "normal", "simplified", and "blurred". For "abstract" mode, suggested styles include "gradient", "flat_color", "tone", "pattern", "speed_lines", "impact_lines", "sparkles", "flowers", and "gloom". Abstract style values are intentionally open-ended so productions may request other recognizable symbolic treatments. The optional "color" field may be supplied when meaningful. Plain white or black backgrounds use "style": "flat_color" with the corresponding color rather than separate white/black styles. SBL 1.0 does not define a separate background "detail" property; environment detail is expressed through the environment style.

```json
{
  "background":
  {
    "mode": "abstract",
    "style": "gradient",
    "color": "blue"
  }
}
```

The style vocabulary is open-ended. Use literal environment when continuity matters; use abstract treatment when mood, reaction, motion, or readability is more important than location detail.

Relationship to pose, action, interaction, and spatial state: "pose" describes broad posture; "actions" describe activity; "interactions" describe required contact or manipulation; spatial containment/support relationships describe where an entity is and what supports or contains it; "motion" describes how movement is visually represented in the still image. One construct does not silently imply another. For example, speed lines do not by themselves create a running action, and an action named "sit" does not by itself establish which chair supports the character.

### Motion Representation

Requirements — "motion" is optional. Each motion record MUST contain "target" and "type". Direction, intensity, trail_length, blur_amount, freeze_subject, and trail medium are optional or type-specific as defined below.

Motion representation controls how movement is visually communicated in a still panel. It supplements an action; it does not replace the action itself.

The core fields are "target", "type", "direction", "intensity", "trail_length", "blur_amount", and "freeze_subject". "target" names the moving entity. Standard "type" values are "none", "motion_lines", "speed_lines", "motion_blur", "afterimage", "impact_lines", and "trail". "intensity" may be "mild", "moderate", "strong", or "extreme". "trail_length" may be "short", "medium", or "long". "blur_amount" may be "mild", "moderate", or "strong". "freeze_subject" is Boolean; true keeps the subject crisp while surrounding or trailing motion treatment is applied. For "trail", the optional "medium" identifies what forms the trail; suggested values include "dust", "smoke", "water", "sparks", "magic", "light", and "debris".

```json
{
  "motion":
  [
    {
      "target": "midori",
      "type": "speed_lines",
      "direction":
      {
        "horizontal": "camera_right"
      },
      "intensity": "strong",
      "freeze_subject": true
    },
    {
      "target": "midori.right_hand",
      "type": "motion_lines",
      "direction":
      {
        "vertical": "down"
      },
      "intensity": "moderate"
    },
    {
      "target": "midori",
      "type": "trail",
      "medium": "dust",
      "direction":
      {
        "horizontal": "camera_right"
      },
      "trail_length": "long"
    }
  ]
}
```

Use "motion_lines" for local movement attached closely to a subject or body part; "speed_lines" for strong compositional directional emphasis; "motion_blur" for continuous fast movement; "afterimage" for ghosted or repeated prior positions; "impact_lines" for the graphical representation of sudden force or collision; and "trail" when a visible trail primarily communicates the path of a moving target. The underlying movement itself belongs in pose, actions, interactions, or events; motion representation describes only how that movement is depicted. A trail that primarily exists as an independent phenomenon belongs in visual effects, though both constructs MAY be used when both semantics matter.

"direction" MAY be a simple value such as "toward_camera" or "away_from_camera" when unambiguous, or a structured object when axes must be stated independently. Structured screen/camera direction uses "horizontal": "camera_left" or "camera_right" and "vertical": "up" or "down". Structured stage/world direction may use independent horizontal and depth values such as "stage_right" and "upstage". SBL uses "camera_left" and "camera_right" rather than "screen_left" and "screen_right" for camera-relative horizontal direction.

### Text Objects

Requirements — "text_objects" is optional. Each text object MUST contain "id" and SBL Text "content". "target" is normally required when the text belongs to a physical object or surface; type, style, and normalized screen "placement" are optional descriptive/presentation properties. Placement is most useful for free-standing graphical text; text attached to a physical target normally follows that target.

Text objects represent visible written text that is part of the scene rather than dialogue, narration, or SFX: signs, labels, books, letters, newspapers, monitors, phones, nameplates, inscriptions, and similar objects.

Each text object has an "id", exact SBL Text "content", and usually a "target" identifying the physical object/surface that carries the text. "type" may describe the medium (sign, label, inscription, screen_text, handwriting, printed_text). "style" may describe the physical lettering treatment such as wooden, engraved, handwritten, printed, digital, neon, painted, or another production-relevant style. The text object's "style" describes the in-world treatment of the text-bearing object; word-level typography inside "content" uses SBL Text runs and reusable text styles. When a text object is not physically bound to a target, the shared normalized screen "placement" object may specify its anchor point.

```json
{
  "text_objects":
  [
    { "id": "sign_1", "target": "signboard_1", "content": "Temple of Light", "type": "sign", "style": "wooden" },
    { "id": "note_1", "target": "paper_1", "content": "Do not enter.", "type": "note", "style": "handwritten" },
    { "id": "book_title_1", "target": "book_1", "content": "History of Zora", "type": "title", "style": "engraved" }
  ]
}
```

The renderer MUST preserve authored text exactly when legibility is required. Text-object placement follows the geometry of its target surface unless explicit placement overrides it.

### Rendering and Style References

Requirements — "references" is optional. Every referenced resource id MUST resolve. Role maps contain machine ids/references; "global_style", when present, MUST resolve to a visible style definition/resource.

Rendering and Style References solve a continuity problem: prose alone is often insufficient to keep a character, prop, room, costume, or visual style consistent across dozens or hundreds of independently generated panels. This section tells the resolver which visual references should guide rendering.

A reference does not insert the referenced image into the panel. Instead, the resolver supplies the reference together with the resolved scene so the renderer can preserve identity, design, materials, architecture, palette, line treatment, or other established visual facts.

The "references" object may group references by role. "characters" maps character ids to identity/character-sheet resources; "objects" maps prop ids; "locations" maps environments/sets; "costumes" maps reusable outfit definitions; and "styles" maps named visual-style references. "global_style" optionally names the default rendering style for the panel/page.

```json
{
  "references":
  {
    "characters":
    {
      "midori": "ref_midori_zora_arc",
      "beli": "ref_beli_zora_arc"
    },
    "objects":
    {
      "temple_sword": "ref_temple_sword"
    },
    "locations":
    {
      "temple_interior": "ref_temple_interior"
    },
    "styles":
    {
      "clean_manga": "ref_clean_manga_style"
    },
    "global_style": "clean_manga"
  }
}
```

Reference ids must resolve to declared resources or imported reusable definitions. A character reference establishes identity; a costume reference establishes clothing; a location reference establishes architecture/set dressing; a style reference guides linework, color treatment, texture, or presentation. These roles should not be conflated.

References are strong guidance, not permission to ignore explicit SBL. If the reference shows Midori standing but the panel says she is sitting, the renderer preserves Midori’s identity while obeying the sitting pose. Explicit panel instructions override incidental details in a reference image.

### Explicit Continuity Assertions

Requirements — "continuity" is optional. When present, "from" is REQUIRED and at least one of "preserve" or "assertions" MUST be present. All preserve paths and assertion references MUST resolve.

Continuity constrains or validates consistency with an explicitly identified renderable unit. It is distinct from inheritance: "inherit" copies effective scene state into the current unit, while "continuity" checks that selected facts remain consistent with another unit.

Every "continuity" object MUST contain "from". SBL never infers a previous panel. "from" is a normal SBL reference and may be local or qualified. In SBL 1.0, "continuity" is a panel-level construct and "from" identifies a previously defined logical panel. Page-level continuity is deferred to a future version.

```json
{
  "continuity":
  {
    "from": "P39",
    "preserve":
    [
      "midori.hair",
      "midori.costume"
    ],
    "assertions":
    [
      {
        "target": "midori",
        "property": "carried_item",
        "value": "notebook_1",
        "strength": "required"
      }
    ]
  }
}
```

"preserve" is an optional array of dotted property paths. Each path means: resolve this property in the unit named by "from" and require the current unit to preserve that effective value. SBL 1.0 does not define wildcard paths. If a preserve path does not resolve in the referenced unit, that is an error; the resolver MUST NOT silently preserve nothing.

"assertions" is an optional array of explicit continuity requirements. Each assertion identifies a target, property, value, and optional strength. "strength" uses the standard constraint vocabulary: "required", "preferred", "discouraged", or "forbidden".

"preserve" and "assertions" are individually optional, but at least one MUST be present. A continuity object containing only "from" is invalid.

NOTE: "inherit.preserve" and "continuity.preserve" intentionally have different grammars and semantics. inherit.preserve selects broad categories of scene state to copy into the inheriting panel. continuity.preserve uses dotted property paths and requires those specific effective values to remain consistent with the unit named by continuity.from. The shared word "preserve" does not make the two arrays interchangeable.

Sequential state and checkpoints do not change the purpose of "continuity". continuity validates or constrains consistency with another renderable unit; it does not copy state or establish panel entry state. Use entry_state.restore to resume a checkpoint and inherit to explicitly copy another panel's effective state.

### Visual Render Continuity

Requirements — `visual_continuity` is optional at page and panel scope. When present, exactly one of `from_page` or `from_panel` is REQUIRED. `description`, `preserve`, and `requirement` are optional. `requirement` values are `required` and `preferred` and defaults to `required`. The referenced page or panel MUST identify an earlier renderable unit in the same script.

`visual_continuity` preserves the established visual realization of a continuing scene across independently generated pages or panels. Use it when semantic state alone is insufficient to prevent environmental or character drift. It is distinct from `inherit` (semantic state copy) and `continuity` (semantic consistency assertion): `visual_continuity` asks the rendering workflow to supply an earlier rendered image as a visual continuity reference.

```json
{
  "visual_continuity":
  {
    "from_page": "CH1-P04",
    "description": "Continue the established SRA appearance from Page 4.",
    "preserve":
    [
      "environment",
      "lighting",
      "architecture",
      "gate appearance",
      "spatial character"
    ],
    "requirement": "required"
  }
}
```

Page-level `visual_continuity` applies to the whole page. Panel-level `visual_continuity` applies only to that logical panel and replaces the page-level declaration for that panel.

`from_page` identifies an earlier page render. `from_panel` identifies a specific earlier logical panel and is preferred when one panel is the clearest continuity source. Exactly one source form is legal. A processor MUST NOT infer a visual-continuity source from document order when the property is absent.

```json
{
  "visual_continuity":
  {
    "from_panel": "CH1-P04-S04",
    "preserve":
    [
      "environment",
      "lighting",
      "persistent objects"
    ]
  }
}
```

`preserve` contains concise renderer-facing visual aspects, not semantic dotted property paths. Typical values include environment, lighting, architecture, persistent objects, character appearance, wardrobe, composition, palette, atmosphere, and spatial character. More specific phrases such as `gate appearance` are allowed.

Authority: a prior render supplied through `visual_continuity` is NOT canonical authority. Explicit current SBL and required canonical character/costume/prop/location resources and authoritative textual specifications override conflicts. For requested aspects, `visual_continuity` is more specific than generic `visual_inspiration`, but it MUST NOT perpetuate a prior rendering error that conflicts with canonical material.

Resolution/packaging: the resolver preserves and normalizes the dependency and includes it in resource/readiness analysis. The page packager or equivalent tool SHOULD locate the referenced prior render and include it with the current render package. For `from_panel`, provide a panel crop or panel-specific render when practical; the containing page MAY be supplied if the target panel is clearly identified.

Availability: missing `required` visual continuity makes the target not render-ready unless fallback is explicitly authorized. Missing `preferred` visual continuity SHOULD produce a warning but does not block rendering. Availability does not change authority.

`visual_continuity` does not alter sequential semantic state, checkpoint state, inheritance, or canonical definitions.

### Render Layers, Passes, Sets, Profiles, and Local Render Directives

Requirements — "render_layers", "render_passes", "render_sets", "render_profiles", and "render" are optional production features. They control production outputs and compositing and MUST NOT silently change canonical story semantics. "visibility" remains a scene/panel property describing what is intended to appear in the depicted shot; render controls describe how that resolved scene is emitted.

#### Render Layers

Render layers group resolved scene content for selective production and compositing. Each layer requires a stable "id" and a non-empty "contents" array. Custom layer ids are allowed.

```json
{
  "render_layers":
  [
    { "id": "environment", "contents": ["setting", "environment_objects"] },
    { "id": "props", "contents": ["scene_props"] },
    { "id": "characters", "contents": ["midori", "beli"] },
    { "id": "event_effects", "contents": ["explosion_1"] }
  ]
}
```

Recommended conventional scene layer classes are environment, event_effects, props, and characters. SFX and text_objects are artwork-text constructs and may be selected explicitly. SBL does not combine all textual material into one generic text layer because editorial lettering and text integrated into artwork have different production behavior.

#### Standard Lettering Components

Dialogue, narration, and footnotes expose standard renderable components without becoming separate story objects: dialogue.container, dialogue.tail, dialogue.lettering, narration.container, narration.lettering, footnote.container, footnote.bug, and footnote.lettering. SFX and text_objects are artwork text and remain in a normal unlettered render unless explicitly excluded.

Suppressing lettering MUST NOT remove semantic text before layout. Cross-reference substitution, footnote resolution, font metrics, wrapping, balloon sizing, narration-box sizing, footnote-box sizing, placement, and reading order are resolved first. Suppression affects only final compositing of the selected lettering component.

```json
{
  "render":
  {
    "exclude": ["dialogue.lettering", "narration.lettering", "footnote.bug", "footnote.lettering"]
  }
}
```

#### Render Passes and Excluded Content

A render pass requests an additional production output derived from the resolved page or panel. Each pass requires a stable id and at least one non-empty include or exclude array. Selectors may name layers, standard components, semantic selector classes, or addressable entities where permitted.

When scene content is excluded, excluded_content.mode defines its compositional behavior. SBL 1.0 defines exactly two standard modes: reconstruct and omit.

reconstruct — The excluded content remains present for blocking, spacing, framing, composition, occlusion planning, balloon placement, and other layout decisions. It is suppressed from the output, and scene content that would have been behind it is reconstructed. Other content MUST NOT move into its reserved space merely because it is invisible.

omit — The excluded content is treated as absent for that pass. It reserves no space and the renderer may recompose other content into the vacated area.

SBL 1.0 does not define transparent as an excluded-content mode. If a silhouette mask is needed, an object-only or layer-only pass may be produced. This is distinct from setting the overall output background of a pass to transparent.

```json
{
  "render_passes":
  [
    {
      "id": "background_plate",
      "include": ["environment", "props"],
      "exclude": ["characters"],
      "excluded_content": { "mode": "reconstruct" }
    },
    {
      "id": "characters_plate",
      "include": ["characters"],
      "background": "transparent"
    }
  ]
}
```

#### Locked Render Sets and Registration

A render_set associates complementary passes that must share one canonical composition. SBL 1.0 defines the standard registration value "locked". Passes in a locked set MUST preserve identical canvas dimensions, panel bounds, camera position/orientation, framing, crop, perspective/projection, character/object scale, blocking, and spatial geometry. lighting.environment and lighting.shot also remain effective unless a pass explicitly defines a permitted production override.

A locked render set represents alternate extractions of one composition, not independent redraws. Implementations SHOULD derive the passes from one canonical composite or use equivalent internal controls that maximize registration.

```json
{
  "render_sets":
  [
    { "id": "main_composite", "registration": "locked" }
  ],
  "render_passes":
  [
    { "id": "background_plate", "render_set": "main_composite", "include": ["environment", "props"], "exclude": ["characters"], "excluded_content": { "mode": "reconstruct" } },
    { "id": "foreground_plate", "render_set": "main_composite", "include": ["characters"], "background": "transparent" }
  ]
}
```

#### Render-Pass Requirement Levels

Each render pass MAY declare "requirement" as "required", "preferred", or "optional". The default is "preferred". A required pass is part of the conforming requested output; inability to produce it is a renderer-conformance error. Failure to produce a preferred pass permits continued rendering but requires a warning. An optional pass may be omitted without warning.

If a required pass belongs to a locked render set, producing a geometrically incompatible pass does not satisfy the requirement.

```json
{
  "id": "background_plate",
  "requirement": "required",
  "render_set": "main_composite",
  "exclude": ["characters"],
  "excluded_content": { "mode": "reconstruct" }
}
```

#### Render Profiles

render_profiles declares reusable named production configurations. Profiles may be declared at script, page, or panel scope using normal SBL cascading rules. Profiles are production policy; they MUST NOT redefine canonical story state such as characters, setting, blocking, pose, dialogue content, object state, or camera.

Profile names such as proof, unlettered, and compositing are illustrative rather than reserved. No profile is selected implicitly. Profile selection occurs as part of a render operation or render request.

```json
{
  "render_profiles":
  {
    "unlettered":
    {
      "exclude": ["dialogue.lettering", "narration.lettering", "footnote.bug", "footnote.lettering"]
    },
    "compositing":
    {
      "passes": ["background_plate", "foreground_plate"]
    }
  }
}
```

#### Local Render Directives

A page or panel MAY contain a local "render" directive for persistent production intent specific to that unit. Page scope is the recommended common scope for one-off unlettered production because replacing all lettering on a page preserves internal typographic consistency. Panel-level directives and fine-grained component selectors remain available for exceptional cases.

```json
{
  "id": "CH01-P37",
  "render":
  {
    "exclude": ["dialogue.lettering", "narration.lettering", "footnote.bug", "footnote.lettering"]
  }
}
```

Fine-grained selectors MAY identify an individual component, for example "dialogue.d4.lettering", when a production workflow genuinely requires narrower suppression.

#### Runtime Render Requests and Precedence

A runtime render request may supply temporary production choices without modifying canonical Source SBL. This supports, for example, requesting a proof render with lettering visible even when the authored page normally suppresses lettering for production.

Effective render configuration is resolved in this precedence order: script/profile defaults, then page render directive, then panel render directive, then runtime render request. Narrower or later instructions override conflicting broader component selectors. Include and exclude arrays MUST NOT be naively concatenated when they conflict; processors SHOULD normalize them to effective per-selector states before rendering.

```json
Authored page:
{
  "render": { "exclude": ["dialogue.lettering"] }
}

Runtime proof request:
{
  "render": { "include": ["dialogue.lettering"] }
}

Effective result: dialogue.lettering is included for this render only.
```

#### Normal Composite and Additional Outputs

Declaring render_passes requests additional production outputs and does not, by itself, suppress the normal complete composite. If a workflow needs only selected passes, that choice belongs to the render request or effective render configuration rather than being inferred from the existence of render_passes.

#### Example: Page-Level Unlettered Production with Artwork Text Retained

```json
{
  "id": "CH01-P37",
  "render":
  {
    "exclude":
    [
      "dialogue.lettering",
      "narration.lettering",
      "footnote.bug",
      "footnote.lettering"
    ]
  },
  "panels":
  [
    {
      "id": "P37A",
      "dialogue": [{ "id": "d1", "speaker": ["midori"], "content": "Look out!" }],
      "sfx": [{ "id": "s1", "content": "FWOOM!" }],
      "text_objects": [{ "id": "sign_1", "target": "exit_sign", "content": "EXIT" }]
    }
  ]
}
```

In the unlettered output, the dialogue balloon remains correctly sized but contains no dialogue lettering. FWOOM! and EXIT remain because SFX and text_objects are artwork text. A proof render may temporarily include dialogue.lettering through a runtime override.

### Resolver Resource Manifest

Requirements — The resolver resource manifest is generated output rather than required Source SBL. When emitted, it MUST use a "resource_manifest" object containing "target", an ordered "requirements" array, and "render_ready". Optional diagnostic members such as "missing_required" and "excluded_as_unused" may be included when useful.

An SBL resolver should produce not only a flattened renderer-ready panel or page, but also a generated resource manifest identifying the minimal set of external files needed to render that target. This generated manifest is diagnostic/resolution output and is distinct from the Source SBL "resources" declaration object. The examples below use the canonical SBL 1.0 resolver resource-manifest shape. Source declarations remain in the keyed "resources" object; resolver output MUST NOT reuse "resources" as an array.

```json
{
  "resource_manifest":
  {
    "target": "CH12-P40-S3",
    "requirements":
    [
      {
        "id": "Midori_character_sheet",
        "type": "image",
        "purposes":
        [
          "character_identity",
          "color_reference"
        ],
        "requirement": "required",
        "file": "resources/characters/Midori.png"
      },
      {
        "id": "Beli_character_sheet",
        "type": "image",
        "purposes":
        [
          "character_identity"
        ],
        "requirement": "required",
        "file": "resources/characters/Beli.png"
      },
      {
        "id": "Academy_corridor_reference",
        "type": "image",
        "purposes":
        [
          "architecture_reference"
        ],
        "requirement": "preferred",
        "file": "resources/locations/Academy-Corridor.png"
      }
    ],
    "missing_required": [],
    "render_ready": true
  }
}
```

Suggested requirement levels are required, preferred, and optional. A required resource MUST be available before rendering unless the caller explicitly authorizes fallback behavior. A preferred resource SHOULD be supplied when available but does not by itself prevent rendering. An optional resource may improve fidelity but is not expected to materially determine identity or continuity.

#### Resource Purposes

The manifest should state why each resource is needed. A single resource may serve multiple purposes. Initial purpose values should include character_identity, costume_identity, footwear_identity, equipment_identity, prop_identity, location_identity, architecture_reference, lighting_reference, style_reference, scale_reference, and color_reference.

##### Example

Purpose labels tell the resolver why a resource is being supplied.

```json
{
  "resources":
  {
    "midori_ref":
    {
      "type": "image",
      "file": "refs/midori.png",
      "purposes": ["character_identity"]
    },
    "uniform_ref":
    {
      "type": "image",
      "file": "refs/uniform.png",
      "purposes": ["costume_identity"]
    },
    "classroom_ref":
    {
      "type": "image",
      "file": "refs/classroom.png",
      "purposes": ["architecture_reference"]
    }
  }
}
```

#### Missing Resource Detection

The resolver should compare required resources against the assets actually available to the rendering workflow. Missing required resources should be reported before rendering rather than silently replaced with invented content.

```json
{
  "resource_manifest":
  {
    "target": "CURRENT_TARGET",
    "requirements":
    [
      { "id": "Midori_character_sheet", "requirement": "required", "available": true },
      { "id": "Beli_character_sheet", "requirement": "required", "available": true },
      { "id": "Kenee_character_sheet", "requirement": "required", "available": true },
      { "id": "Buren_character_sheet", "requirement": "required", "available": false }
    ],
    "missing_required": ["Buren_character_sheet"],
    "render_ready": false
  }
}
```

When "resource_manifest.render_ready" is false because a required resource is missing, rendering MUST NOT proceed unless the caller explicitly authorizes fallback behavior. The manifest MUST identify the missing resource id in "missing_required" and SHOULD include its expected file path in the corresponding requirements entry.

##### Example

Missing required resources should be reported before rendering rather than silently replaced.

```json
{
  "resource_manifest":
  {
    "target": "P40A",
    "requirements":
    [
      {
        "id": "midori_character_sheet",
        "purposes": ["character_identity"],
        "requirement": "required",
        "file": "references/Midori-Zora.png"
      }
    ],
    "missing_required": ["midori_character_sheet"],
    "render_ready": false
  }
}
```

#### Resource Minimization

The resolver should omit resources that are irrelevant to the requested render target. If a script library contains dozens of character sheets but a panel contains only four characters, the renderer should normally receive only the references required or preferred for those four characters and the other resources actually used by the panel. Resource minimization reduces irrelevant context and may improve identity binding in generative image systems.

##### Example

Only resources needed by the current render target should be supplied.

```json
{
  "resource_manifest":
  {
    "target": "P40A",
    "requirements":
    [
      { "id": "midori_character_sheet", "requirement": "required" },
      { "id": "academy_classroom_ref", "requirement": "required" }
    ],
    "excluded_as_unused":
    [
      "buren_character_sheet",
      "dorm_room_ref"
    ],
    "render_ready": true
  }
}
```

#### Resolution Report

In addition to machine-readable resolved SBL, a resolver may produce a human-readable resolution report. This is especially useful when ChatGPT or another generative AI acts as the prototype SBL resolver.

```json
SBL RESOLUTION REPORT
Target: CH12-P40-S3

Required resources:
  Midori_character_sheet
  Beli_character_sheet
  Kenee_character_sheet
  Buren_character_sheet

Preferred resources:
  Academy_corridor_reference

Missing required resources:
  None

Suppressed entities:
  student_1
  student_2

Inherited:
  Midori costume
  Midori mana meter
  Academy corridor
  clear lighting

Resolved characters:
  Beli
  Midori
  Kenee
  Buren

Ready to render: YES
```

The resolution report is diagnostic output rather than SBL source. It may list resources, suppressed entities, inherited state, overrides, validation warnings, resolved characters, and render readiness.

##### Example

A resolution report records what was expanded, inherited, overridden, and validated.

```json
{
  "resolution_report":
  {
    "render_target": "P40A",
    "imports_expanded": ["Academy-Classroom.sbl.json"],
    "inheritance_applied": ["P39A"],
    "overrides_applied": ["midori.expression", "camera.shot"],
    "resources_required": 2,
    "errors": [],
    "warnings": []
  }
}
```

#### Example

A manifest shows exactly which external resources an independently rendered target requires and whether any are missing.

```json
{
  "resource_manifest":
  {
    "target": "P40A",
    "requirements":
    [
      {
        "id": "midori_character_sheet",
        "purposes": ["character_identity"],
        "requirement": "required",
        "file": "references/Midori-Zora.png"
      },
      {
        "id": "academy_classroom_ref",
        "purposes": ["architecture_reference"],
        "requirement": "required",
        "file": "references/Academy-Classroom.png"
      }
    ],
    "missing_required": [],
    "render_ready": true
  }
}
```

## Resolution Semantics and Merge Rules

This section is normative. It defines how Source SBL is converted into Resolved SBL for a specific page or panel. A conforming resolver MUST produce the same effective state from the same valid source document and resource set, independent of the renderer used afterward.

### Terminology

Source SBL is the authored document and may use imports, defaults, cascading declarations, inheritance, and compact references. Resolved SBL is the flattened effective state for a requested page or panel after all deterministic resolution rules have been applied. Render SBL is optional renderer-oriented output derived from Resolved SBL; it may contain redundant constraints or expanded semantic hints intended to improve generative rendering.

Normative requirement words in this section use the meanings defined in the document-level Normative Language section.

### Resolution Order

To resolve a panel, a conforming resolver MUST perform the following conceptual operations in order:

1. Validate the SBL specification name and version.
2. Load and resolve imported definitions/resources.
3. Build visible namespaces and validate document-wide anchor uniqueness.
4. Apply script-level definitions/defaults.
5. Apply page-level definitions/overrides.
6. Establish panel entry state: explicit inherit; otherwise reset; otherwise restore; otherwise sequentially persistent end-state of the preceding logical panel. The first logical panel has no preceding sequential state.
7. Apply current panel definitions/overrides.
8. Merge entities and target-keyed state arrays.
9. Apply component defaults and explicit overrides.
10. Apply present:false suppression.
11. Remove suppressed entities from resolved sets unless diagnostics request them.
12. Resolve structured references, anchors, and resource requirements.
13. Resolve reader-facing anchor substitutions in SBL Text.
14. Resolve panel footnote references, assign bugs in first-use reading order, and determine resolved footnote-box content/layout requirements.
15. Validate required constraints, continuity assertions, and reference/footnote diagnostics.
16. Calculate the panel's sequentially persistent end-state.
17. If checkpoint is present, capture checkpoint state from the resolved panel end-state; the checkpoint also establishes its implicit anchor.
18. Emit Resolved SBL and resource manifest.
19. Optionally derive Render SBL without changing resolved semantics.

Sequential state crosses page boundaries according to effective reading order. Resolving an independently requested page MUST NOT require that the preceding page first be rendered as an image.

### Cascading Precedence

When the same property is defined at multiple structural levels, the narrower definition takes precedence. The normal precedence order is script < page < panel. Imported definitions supply reusable base definitions and do not override an explicit declaration in the consuming document unless a future extension explicitly states otherwise.

```json
{
  "script":
  {
    "characters":
    [
      {
        "id": "midori",
        "costume":
        {
          "id": "academy_uniform"
        }
      }
    ],

    "pages":
    [
      {
        "id": "P40",

        "characters":
        [
          {
            "id": "midori",
            "costume":
            {
              "id": "formal_gown"
            }
          }
        ]
      }
    ]
  }
}
```

The effective costume for Midori on P40 MUST be formal_gown.

### Object Merge Rule

Objects that refer to the same entity id MUST be recursively merged. Properties present only in the broader definition survive. Properties explicitly supplied by the narrower definition replace the corresponding broader properties.

```json
{
  "script_definition":
  {
    "id": "midori",
    "costume":
    {
      "id": "academy_uniform"
    },
    "worn_items":
    [
      {
        "id": "mana_meter"
      }
    ]
  },

  "panel_override":
  {
    "id": "midori",
    "costume":
    {
      "id": "formal_gown"
    }
  }
}
```

The resolved result MUST preserve the mana meter while replacing the costume:

```json
{
  "id": "midori",
  "costume":
  {
    "id": "formal_gown"
  },
  "worn_items":
  [
    {
      "id": "mana_meter"
    }
  ]
}
```

### Array Merge Rules

Arrays containing identifiable entity objects (objects containing an "id" property) MUST merge by "id". An entity with the same id is recursively merged; a new id is appended to the effective collection; an inherited entity may be suppressed with "present": false.

SBL also defines target-keyed state arrays. For the properties "orientation", "pose", "expression", "appearance_state", "visibility", "stage_position", and "screen_position", records are identified by "target" and MUST merge by target. Within any one declaration of one of these arrays, each target MUST appear at most once; duplicate target records in the same array are invalid. When a narrower scope supplies a record for the same target, that record recursively overrides the broader record for that target; records for other targets remain effective. These properties therefore behave like entity arrays keyed by target rather than arrays that are replaced wholesale. Other arrays of scalar values or objects without an id or a property-specific merge key MUST, by default, be replaced by the narrower declaration rather than concatenated. A future property-specific rule MAY define different behavior, but such behavior must be explicit in the specification. Entity "references" arrays have a separate property-specific merge key: each reference record is keyed by the ordered pair ("resource", "purpose"). A narrower reference with the same resource and purpose recursively overrides that broader reference record, including fields such as "requirement"; reference records with a different resource or purpose remain effective. Within one references array, the same ("resource", "purpose") pair MUST NOT occur more than once.

```json
{
  "script_worn_items":
  [
    {
      "id": "mana_meter",
      "visible": true
    },
    {
      "id": "amulet",
      "visible": true
    }
  ],

  "panel_worn_items":
  [
    {
      "id": "mana_meter",
      "visible": false
    }
  ]
}
```

The resolved collection contains both items; mana_meter.visible becomes false and amulet remains unchanged.

Target-keyed state arrays preserve records for unaffected targets while overriding the matching target:

```json
{
  "script_pose":
  [
    { "target": "midori", "type": "standing" },
    { "target": "beli", "type": "standing" }
  ],
  "panel_pose":
  [
    { "target": "beli", "type": "sitting" }
  ]
}
```

The resolved pose array contains Midori standing and Beli sitting. Beli's narrower record replaces the broader state for Beli; Midori's broader record remains effective.

### Presence and Suppression

Entities declared at broader scope are inherited downward by default. The default value of present is true. A narrower declaration containing present:false suppresses that entity for that scope and its descendants unless a still-narrower declaration explicitly restores present:true.

```json
{
  "script":
  {
    "characters":
    [
      {
        "id": "student_1",
        "type": "anonymous"
      }
    ]
  },

  "page_override":
  {
    "characters":
    [
      {
        "id": "student_1",
        "present": false
      }
    ]
  }
}
```

student_1 MUST be absent from the resolved characters for that page. For generative rendering, suppressed entities SHOULD be omitted entirely from Render SBL rather than sent to the renderer as inactive characters.

### Default Component Resolution

Defaults supplied by a selected component are applied before explicit character-level overrides. Explicit values always win over defaults.

```json
{
  "costume":
  {
    "id": "academy_uniform",
    "defaults":
    {
      "footwear": "academy_shoes"
    }
  },

  "footwear":
  {
    "id": "training_boots"
  }
}
```

The effective footwear MUST be training_boots. If the explicit footwear property were absent, academy_shoes would become the effective footwear.

### Panel Inheritance

Requirements — "inherit" is optional. When present, "inherit.from" is REQUIRED. "inherit.preserve" is optional; when omitted, all inheritable semantic scene state is copied before local overrides are applied.

Explicit panel inheritance copies effective scene state from the referenced panel before applying the inheriting panel’s own local overrides. The current script/page base state is established first; inherited semantic state is then merged onto that base, and panel-local properties are applied last. Inheritance MUST NOT imply reuse of image pixels. The resolver MUST detect inheritance cycles and report them as errors.

```json
{
  "id": "P3",
  "inherit":
  {
    "from": "P2",
    "preserve":
    [
      "character_appearance",
      "wardrobe",
      "object_state"
    ]
  }
}
```

Panel inheritance is an explicit alternative to sequential entry state. A panel containing "inherit" MUST NOT also contain "entry_state". Ordinary consecutive panels normally omit both and use implicit continue behavior.

### Object-State Continuity

Object state carried by ordinary sequential continue or copied by explicit inheritance remains effective until overridden or explicitly reset. If a door becomes open in P2, it remains open in P3 under normal continue processing. A reset discards accumulated temporal state; checkpoint restoration reinstates captured object_state.

### Reference Resolution

Every id reference used by resolved blocking, dialogue, events, lighting, resources, constraints, or other semantic structures MUST resolve to exactly one visible entity/resource. Unqualified references resolve lexically from the current scope. Qualified references use :: to traverse explicitly named containing scopes. An unresolved or ambiguous reference is an SBL resolution error; a resolver MUST NOT silently guess which entity was intended.

### Resource Resolution and Readiness

The resolver MUST construct the minimal resource_manifest required for the target render. Missing required resources set resource_manifest.render_ready to false. Preferred or optional resources may be absent without invalidating the SBL document.

```json
{
  "resource_manifest":
  {
    "target": "CURRENT_TARGET",
    "requirements":
    [
      { "id": "Buren_character_sheet", "requirement": "required", "available": false }
    ],
    "missing_required": ["Buren_character_sheet"],
    "render_ready": false
  }
}
```

### Constraint Resolution

Required constraints MUST be mutually satisfiable. If two required constraints directly contradict each other, resolution fails before rendering. Preferred and discouraged constraints may conflict; the renderer may choose among them while preserving all required and forbidden conditions.

```json
{
  "constraints": [
    {
      "type": "relative_position",
      "subject": "midori",
      "relation": "left_of",
      "object": "beli",
      "strength": "required",
      "space": "screen"
    },
    {
      "type": "relative_position",
      "subject": "beli",
      "relation": "left_of",
      "object": "midori",
      "strength": "required",
      "space": "screen"
    }
  ]
}
```

The example is contradictory and MUST be reported as a resolution/constraint error.

### Error Classes

SBL distinguishes at least three failure classes:

Invalid SBL: malformed JSON, unsupported specification version, duplicate/conflicting declarations prohibited by the specification, illegal enum values, unresolved references, or malformed imports.

Resolution failure: syntactically valid SBL whose required semantics cannot be resolved, such as inheritance cycles, contradictory required constraints, or missing required resources.

Renderer failure: valid Resolved/Render SBL was produced, but the generated result violates the specification—for example, Buren's balloon tail points to Kenee.

### Worked Resolution Example: Suppressed Anonymous Student

```json
{
  "script":
  {
    "characters":
    [
      {
        "id": "student_1",
        "type": "anonymous"
      }
    ],

    "pages":
    [
      {
        "id": "P10",
        "characters":
        [
          {
            "id": "student_1",
            "present": false
          }
        ]
      }
    ]
  }
}
```

Resolved result for P10: student_1 is omitted from the resolved characters. The broader script definition remains unchanged and becomes effective again on later pages that do not suppress it.

### Worked Resolution Example: Costume Override Preserves Equipment

```json
{
  "script_character":
  {
    "id": "midori",
    "costume":
    {
      "id": "academy_uniform"
    },
    "worn_items":
    [
      {
        "id": "mana_meter",
        "location": "chest"
      }
    ]
  },

  "panel_override":
  {
    "id": "midori",
    "costume":
    {
      "id": "formal_gown"
    }
  }
}
```

Resolved result:

```json
{
  "id": "midori",
  "costume":
  {
    "id": "formal_gown"
  },
  "worn_items":
  [
    {
      "id": "mana_meter",
      "location": "chest"
    }
  ]
}
```

This example demonstrates why resolution operates property-by-property rather than replacing the entire character definition. The panel overrides Midori’s costume, but it does not override her worn equipment. Therefore the costume changes while the mana meter/equipment remains present.

### Worked Resolution Example: Off-Panel Event

```json
{
  "events":
  [
    {
      "id": "explosion_1",
      "type": "explosion",
      "source":
      {
        "object": "lavatory"
      },
      "visibility":
      {
        "source": "off_panel",
        "indirect_effects": true
      }
    }
  ],

  "sfx":
  [
    {
      "id": "sfx_1",
      "content": "FWOOM!",
      "source": "explosion_1"
    }
  ]
}
```

Resolved semantics: the explosion source is outside the visible panel and MUST NOT be drawn. FWOOM! is a visible SFX and SHOULD be rendered. Indirect effects such as reflected light, smoke, or character reactions MAY appear.

The rendered panel must distinguish the event source from its visible consequences. Because the source is off-panel, the explosion itself must remain outside the frame. The panel may still show the SFX, reflected light, dust, debris entering the frame, and Midori reacting to the event.

### Worked Resolution Example: Resource Manifest

A resource manifest is an inventory produced for a particular render target. Its purpose is to answer a practical question before rendering begins: “Exactly which external files does this page or panel require?” A long SBL project may contain hundreds of character sheets, location references, costume images, imported libraries, and style assets, but an individual panel usually needs only a small subset.

The resolver computes that subset by following the target’s references, imports, inheritance, and dependency closure. The manifest makes the result explicit so an implementation can verify that required files exist, report missing resources before image generation, avoid sending irrelevant assets to the renderer, cache or deduplicate resources, and reproduce the same render on another machine or in another AI session.

A manifest is normally generated rather than hand-authored. The author writes the SBL references; the resolver determines which resources are actually required for the requested target and emits the manifest as diagnostic/production information.

```json
{
  "resource_manifest":
  {
    "target": "CH12-P40-S3",
    "requirements":
    [
      {
        "id": "Midori_character_sheet",
        "type": "image",
        "purposes":
        [
          "character_identity",
          "color_reference"
        ],
        "requirement": "required",
        "file": "resources/characters/Midori.png"
      },
      {
        "id": "Beli_character_sheet",
        "type": "image",
        "purposes":
        [
          "character_identity"
        ],
        "requirement": "required",
        "file": "resources/characters/Beli.png"
      },
      {
        "id": "Academy_corridor_reference",
        "type": "image",
        "purposes":
        [
          "architecture_reference"
        ],
        "requirement": "preferred",
        "file": "resources/locations/Academy-Corridor.png"
      }
    ],
    "missing_required": [],
    "render_ready": true
  }
}
```

Only resources relevant to the requested render target SHOULD be included. Irrelevant character sheets and assets SHOULD be omitted.

In the example above, the manifest contains only the character sheets and other assets needed by CH12-P40-S3. A missing required item would make the target not ready to render; an unrelated character sheet from another scene should not appear in the manifest.

### Source, Resolved, and Render SBL Conformance

A resolver MUST NOT change story semantics while converting Source SBL to Resolved SBL. A Render SBL transformation MAY add redundant renderer-facing constraints, expand shorthand, or restate identities, but MUST NOT contradict or weaken required resolved semantics.

The separate SBL Conformance Test Suite provides formal examples and test cases for these semantics, including Source SBL, expected Resolved SBL, required resources, expected failures, and explicit pass/fail assessments. The test suite complements—but does not replace—the normative resolution rules in this section.

## Standard Vocabulary and Defaults

This section is normative. A conforming SBL implementation MUST interpret the following standard values consistently. Implementations MAY support extensions, but extensions MUST NOT silently redefine standard SBL values.

When a property is omitted, its value is either the explicit normative default listed here or unspecified. An implementation MUST NOT invent a different default where SBL defines one. A required property with no default is an error when the surrounding construct requires that property.

### Spatial Relationship Vocabulary

For beside, side MAY be left or right. left_of/right_of specify direction but not proximity; beside specifies proximity and may additionally specify side. "between" is structurally special: it uses an "objects" array containing exactly two distinct references instead of singular "object". Its coordinate-space meaning follows the same screen/world distinction as the other relative spatial relationships.

### Stage and Camera Position Vocabulary

Stage left/right are defined from the performer's perspective while facing the audience/camera. center_stage is the horizontal center between stage left and stage right. downstage/upstage describe depth relative to the audience, and midstage is the midpoint of that depth axis. center_stage and midstage therefore describe different axes and may be combined independently. camera_left/camera_right are defined from the viewer/camera perspective and are not synonyms for stage left/right. Stage elevation is independent of both horizontal position and depth; 0.0 represents the stage floor and 1.0 the top of the defined stage volume. Screen-space vertical position is separate: normalized screen y=0.0 is the top edge and y=1.0 is the bottom edge.

### Camera-Relative Character Orientation

Angles are nominal orientation targets rather than requirements for geometric precision. They exist to remove ambiguity from common artistic pose terminology.

### Common Pose Values

A pose MAY include additional detail. Implementations MUST preserve explicit detail when it does not contradict required structured properties.

### Camera Vocabulary

If camera.angle is omitted, the default is eye_level. Other camera properties are unspecified unless inherited or explicitly supplied.

### Visibility Vocabulary

Occlusion and cropping are distinct. Standard crop values are "knees_up", "waist_up", "chest_up", "shoulders_up", "head_only", "left_half", "right_half", and "custom". Standard occlusion_amount values are "slight", "partial", "major", and "complete". occluded_by is an array of entity ids identifying blockers. An occluder MAY be a character, environment element, prop, effect, or text object, including a speech balloon. For events, visibility.source defaults to on_panel unless explicitly overridden.

### Dialogue Delivery Vocabulary

Ordinary direct speech requires a speaker unless the dialogue construct explicitly supports multiple speakers or a device source. Speech tails default to anchor mouth. Thought trails default to anchor head. A scream MAY influence balloon outline and typography, but the renderer MUST NOT rewrite the authored dialogue text.

### Text Reading Order

For dialogue, the order of elements in the "dialogue" array establishes reading order. A separate "reading_order" value is therefore not required for ordinary dialogue. Other textual panel elements such as narration, SFX, and text objects may require their own ordering rules where their containing arrays do not already establish an order.

### Lighting Vocabulary and Defaults

clear means important subjects and environmental details SHOULD be readily visible and readable. It does not require flat lighting or prohibit shadows. An explicit artistic lighting instruction overrides clear where the two cannot coexist.

### Constraint Strength

required and forbidden constraints take precedence over preferred and discouraged constraints. Contradictory required/forbidden semantics MUST be reported before rendering when detectable.

### Background Vocabulary

### Motion Representation Vocabulary

### Render Layer Vocabulary

Borderline objects SHOULD be classified according to production intent. Persistent built-in scenery normally belongs to environment; independently movable/manipulable objects normally belong to props.

### Core Defaults

Additional dialogue defaults are also listed in the table below. expression.intensity has no default and remains unspecified when omitted.

Properties not listed with a normative default remain unspecified unless another section of the specification defines a default. Unspecified does not authorize a resolver to fabricate story facts. A renderer MAY make purely aesthetic choices where semantics remain unspecified, provided those choices do not violate resolved constraints.

### Extensibility

Implementations MAY add nonstandard vocabulary values. Extension values SHOULD be namespaced or otherwise distinguishable from standard SBL vocabulary. A conforming implementation encountering an unknown required semantic value MUST report it rather than silently substitute a different standard value.

## Resource and Import Semantics

This section is normative. SBL resources and imports make projects portable by defining how reusable character definitions, character sheets, costumes, locations, props, style references, and other external assets are located and resolved. A resolver MUST resolve these references deterministically and MUST NOT silently substitute unrelated resources.

### Packaging an SBL Project for ChatGPT or Another AI

Resource and import semantics describe how SBL files refer to one another and to external assets. To give a project to ChatGPT or another generative-AI system, the practical approach is to place the SBL source and every file needed to resolve it into one ZIP archive. The archive gives the AI a single project root and preserves the relative paths used by the SBL.

For an SBL 1.0 AI handoff, the ZIP SHOULD contain the source SBL document, all imported SBL libraries, all required image/reference resources, and the matching SBL JSON Schema. If the receiving system is expected to validate SBL mechanically, the matching schema is REQUIRED. Because a JSON Schema validates structure but does not fully explain SBL semantics, a package intended for a fresh ChatGPT account or another AI SHOULD also include the current AI-usable SBL specification.

The Human-Readable Specification is not required for machine processing when the AI-usable specification and schema are supplied, but it MAY be included for human readers. A README is also useful when the package has a particular entry file or render target.

```json
SBL-Project.zip
  SBL-Project/
    README.txt
    script.sbl.json

    imports/
      academy_locations.sbl.json
      academy_characters.sbl.json

    resources/
      characters/
        Midori.png
        Beli.png
      costumes/
        AcademyUniform.png
      locations/
        AcademyCorridor.png
      styles/
        Chapter12Style.png

    specification/
      SBL_AI_Usable_Specification.txt
      sbl.schema.json
```

All paths written inside the SBL SHOULD remain relative to the project root or to the declaring SBL file as defined below. Do not rewrite them as machine-specific absolute paths before zipping the project.

#### Typical ChatGPT workflow

1. Place the project files in the directory structure shown above.

2. Include the schema version that matches the SBL specification used by the script.

3. Include the AI-usable specification when the receiving AI cannot be assumed to know SBL.

4. ZIP the project root without flattening its directory structure.

5. Upload the ZIP to ChatGPT and identify the entry SBL file and the page/panel you want processed.

6. Ask ChatGPT to validate/resolve the target before rendering. Missing required resources should be reported rather than invented.

### Project-Relative Paths

Relative resource/import paths are resolved relative to the SBL file containing the declaration. Portable SBL SHOULD use relative paths. Absolute filesystem paths are nonportable and SHOULD NOT be used. Resolvers SHOULD normalize path separators and redundant path segments while preserving project-relative identity. Network URLs MAY be supported by an implementation but are not required by SBL 1.0.

```json
SBL-Project/
  script.sbl.json
  resources/
    characters/
      Midori.png
      Beli.png
    locations/
      academy_locations.sbl.json
    styles/
      Chapter12Style.png
```

### Resource Declarations

```json
{
  "resources":
  {
    "Midori_character_sheet":
    {
      "type": "image",
      "file": "resources/characters/Midori.png",
      "purposes":
      [
        "character_identity",
        "color_reference"
      ]
    },

    "academy_corridor_definition":
    {
      "type": "sbl",
      "file": "resources/locations/academy_corridor.sbl.json",
      "purposes":
      [
        "location_identity"
      ]
    }
  }
}
```

Resource ids MUST be unique within their declaration scope. When multiple resource scopes are visible, unqualified references resolve lexically and qualified references may be used to select a resource in another scope. File names are storage details and need not match resource ids. Initial standard resource types are image, sbl, text, and binary.

A resource declaration may contain purposes, an array describing the uses the asset is capable of serving. An entity resource reference uses singular purpose to state why that entity requires the resource, together with requirement. These fields are related but are not interchangeable.

### Imports

imports loads definitions from another SBL file. This differs from an image resource: an imported SBL file contributes reusable SBL definitions. Imports are lexically additive across script/page/panel scopes: a narrower imports declaration adds definitions and does not replace broader visible imports.

```json
{
  "imports":
  [
    {
      "file": "resources/locations/academy_locations.sbl.json"
    },
    {
      "file": "resources/characters/academy_characters.sbl.json"
    }
  ]
}
```

A required import that cannot be loaded is a resolution failure.

### Imported Definition Libraries

```json
{
  "library": {
    "id": "academy_locations",
    "specification": {
      "name": "SBL",
      "version": "1.0"
    },
    "locations": {
      "academy_corridor": {
        "objects": [
          {
            "id": "lavatory",
            "type": "room"
          },
          {
            "id": "window_1",
            "type": "window"
          }
        ]
      }
    }
  }
}
```

Imported libraries may define resources, characters, costumes, footwear, locations, props, or text styles without containing pages intended for direct rendering. These are the standard reusable-definition collections in SBL 1.0. Each library MUST declare its own id and SBL specification name/version so compatibility can be checked independently of the consuming script.

### Namespace and Collision Rules

In SBL 1.0, imported definitions enter the consuming document's effective namespace. Two unrelated definitions in the same effective declaration scope MUST NOT define the same local id. Different scopes may reuse a local id; lexical or qualified reference resolution determines which declaration is intended. A same-scope collision is an error and the resolver MUST NOT choose one arbitrarily. A consuming document MAY intentionally override an imported base definition where normal cascade rules permit it.

A future version MAY introduce qualified namespaces such as academy:lavatory; qualified namespace syntax is not required in SBL 1.0.

### Local Overrides of Imported Definitions

```json
{
  "imported":
  {
    "id": "academy_corridor",
    "lighting":
    {
      "mode": "clear"
    }
  },

  "local_override":
  {
    "id": "academy_corridor",
    "lighting":
    {
      "mode": "low_key"
    }
  }
}
```

The effective lighting mode is low_key. Properties not overridden remain inherited from the imported definition.

### Transitive Imports

Imports are transitive for resolution. If A imports B and B imports C, definitions from C required by B or A are available while resolving A. Only dependencies relevant to the requested target SHOULD be emitted to Render SBL.

```json
A.sbl.json
  imports B.sbl.json

B.sbl.json
  imports C.sbl.json

Resolution:
  A -> B -> C
```

### Circular Import Detection

A resolver MUST detect circular import chains and report a resolution error rather than recurse indefinitely.

```json
A imports B
B imports C
C imports A

Result:
  ERROR: circular_import
```

### Resource Requirements

Resource requirement levels are required, preferred, and optional. Rendering MUST NOT proceed when a required resource is missing unless the caller explicitly authorizes fallback behavior. A missing preferred resource SHOULD generate a warning but does not by itself prevent rendering. Missing optional resources normally do not generate warnings unless diagnostics are requested.

### Missing Resource Behavior

```json
{
  "resource_manifest":
  {
    "target": "CURRENT_TARGET",
    "requirements":
    [
      { "id": "Midori_character_sheet", "requirement": "required", "available": true },
      { "id": "Beli_character_sheet", "requirement": "required", "available": true },
      { "id": "Buren_character_sheet", "requirement": "required", "available": false },
      { "id": "Academy_corridor_reference", "requirement": "preferred", "available": false }
    ],
    "missing_required": ["Buren_character_sheet"],
    "missing_preferred": ["Academy_corridor_reference"],
    "render_ready": false
  }
}
```

Missing required resources make resource_manifest.render_ready false. The resolver MUST identify each missing required resource id and SHOULD report the expected path in the corresponding requirements entry.

### Resource Purpose Validation

Resource purposes tell the resolver/renderer why an asset is supplied. Standard purposes include character_identity, costume_identity, footwear_identity, equipment_identity, prop_identity, location_identity, architecture_reference, lighting_reference, style_reference, scale_reference, color_reference, visual_inspiration, and visual_continuity.

The resolver SHOULD detect clearly incompatible resource-purpose combinations and MUST NOT treat an incompatible asset as satisfying a required purpose. For example, an unsupported binary resource cannot silently satisfy a required character_identity reference.

### Visual Inspiration

A resource reference with purpose "visual_inspiration" supplies noncanonical, nonbinding visual guidance. It is appropriate for an earlier render, concept image, mood image, composition example, or other image that communicates roughly what a scene could look like while explicitly permitting substantial reinterpretation. The renderer MAY borrow composition, atmosphere, environmental character, scale, color relationships, staging, or other ideas identified by the reference description, but it MUST NOT treat incidental details in the inspiration image as canonical facts.

The optional "description" on a visual_inspiration reference SHOULD state which aspects are useful and MAY explicitly state which aspects must be ignored. This is especially important when an inspiration image contains obsolete character designs, noncanonical props, forbidden symbols, old costumes, or an outdated version of a persistent location.

```json
{
  "resources":
  {
    "CH1_P01_inspiration":
    {
      "type": "image",
      "file": "Assets/CH1-P01-inspiration.png",
      "purposes": ["visual_inspiration"]
    }
  },

  "references":
  [
    {
      "resource": "CH1_P01_inspiration",
      "purpose": "visual_inspiration",
      "description": "Use as loose inspiration for the immense scale, celestial atmosphere, floating architecture, luminous clouds, and overall grandeur of the Domain of the Gods. Reimagine freely; do not reproduce the image literally."
    }
  ]
}
```

For visual_inspiration, omission of "requirement" means "optional" for resource-availability purposes. An available visual_inspiration resource SHOULD nevertheless be included in the target resource manifest and page package because its purpose is to guide the render. If the author explicitly sets requirement to "preferred" or "required", that changes only the consequences of the file being unavailable; it does not increase the visual authority of the inspiration image.

Authority and availability are separate concepts. Explicit SBL semantic instructions and constraints are authoritative over visual inspiration. Required canonical identity/location/prop resources and authoritative textual production specifications are authoritative for the facts they define. Ordinary preferred references guide established visual continuity. visual_inspiration is the weakest visual authority and may influence only aspects not fixed by stronger information. A renderer MUST resolve conflicts in favor of the stronger source.

```json
{
  "references":
  [
    {
      "resource": "WOA_old_panel",
      "purpose": "visual_inspiration",
      "description": "Inspired by the surrounding WOA architecture, atmosphere, and overall composition only. Ignore the screen design, floor design, character designs, costumes, and any symbols shown in this image."
    },
    {
      "resource": "WOA_production_sheet",
      "purpose": "location_identity",
      "requirement": "required"
    },
    {
      "resource": "WOA_specification",
      "purpose": "location_identity",
      "requirement": "required"
    }
  ]
}
```

In this example the old panel may inspire the larger World Observation Area background and staging, while the required production sheet and textual specification control the canonical observation station. Details in the inspiration image that conflict with the required canonical material MUST be ignored.

### Multiple Resources for One Entity

```json
{
  "id": "midori",

  "references":
  [
    {
      "resource": "Midori_character_sheet",
      "purpose": "character_identity",
      "requirement": "required"
    },
    {
      "resource": "Midori_academy_uniform",
      "purpose": "costume_identity",
      "requirement": "required"
    },
    {
      "resource": "Chapter12_style",
      "purpose": "style_reference",
      "requirement": "preferred"
    }
  ]
}
```

An entity MAY reference multiple resources when different assets provide different aspects of its required identity.

References also participate in cascading resolution. Entity references are merged by the composite key ("resource", "purpose"), not by array position and not by resource alone. This allows a narrower scope to change the requirement level or other properties of one particular use of a resource without discarding unrelated identity, costume, style, color, or other references inherited from broader scopes.

```json
{
  "broader_references":
  [
    {
      "resource": "Midori_character_sheet",
      "purpose": "character_identity",
      "requirement": "required"
    },
    {
      "resource": "Chapter12_style",
      "purpose": "style_reference",
      "requirement": "preferred"
    }
  ],
  "narrower_references":
  [
    {
      "resource": "Chapter12_style",
      "purpose": "style_reference",
      "requirement": "required"
    }
  ]
}
```

The resolved references retain Midori_character_sheet for character_identity and Chapter12_style for style_reference; the narrower style record changes only its requirement from preferred to required.

### Resource Minimization

The resolver MUST determine resource dependencies for the requested target and SHOULD pass only relevant required/preferred resources plus relevant available visual_inspiration resources and applicable visual_continuity render dependencies to the renderer. Resources for suppressed characters, unused locations, unrelated costumes, inactive definitions, and unreferenced inspiration SHOULD be omitted. This reduces irrelevant context and may improve identity binding in generative image systems.

### Resource Dependency Closure

If a selected definition depends on additional resources, the resolver MUST compute the dependency closure. For example, selecting a location definition that references a required architecture image causes that image to appear in the target resource manifest.

```json
{
  "location": "academy_corridor",

  "references":
  [
    {
      "resource": "Academy_corridor_reference",
      "purpose": "architecture_reference",
      "requirement": "required"
    }
  ]
}
```

### Resource Path Normalization

Resolvers SHOULD normalize relative path separators and redundant path segments before loading resources. They MUST preserve logical project-relative identity and MUST NOT silently resolve a missing resource to an unrelated similarly named asset elsewhere.

### Portable SBL Package

This section defines the normative contents of a portable SBL deliverable. It answers “What must travel with the project so another conforming implementation can resolve it?” The earlier Packaging an SBL Project for ChatGPT or Another AI subsection is operational guidance for transferring that portable material to an AI system, typically as a ZIP archive.

The distinction is therefore purpose rather than a second competing package format: Resource and Import Semantics defines how references, imports, paths, requirements, and dependencies work; Portable SBL Package defines the self-contained set of files that must be distributable; the ChatGPT packaging guidance explains one convenient transport/container for that set and recommends adding the schema and AI-usable specification for a fresh AI session.

```json
SBL-Project/
  script.sbl.json

  resources/
    characters/
      Midori.png
      Beli.png
      Kenee.png
      Buren.png

    costumes/
      AcademyUniform.png

    locations/
      academy_locations.sbl.json
      AcademyCorridor.png

    styles/
      Chapter12Style.png
```

A portable SBL package consists of the source document, all required imported SBL libraries, and all required external resources. Preferred and optional resources SHOULD also be included when practical.

For distribution to a general SBL implementation, the portable package MUST contain the source document, required imported libraries, and required external resources. For an AI handoff that is expected to validate the language without prior context, include the matching JSON Schema; for a fresh AI account, also include the AI-usable specification so the model has the language semantics as well as the structural schema.

### Portability Requirement

A conforming SBL document and its declared required external resources MUST contain sufficient information for an implementation with no prior knowledge of the production to resolve the requested rendering unit. Production-specific knowledge required for identity, continuity, costume, location, or other required semantics MUST be represented in SBL or supplied as a declared resource.

### Fresh-Implementation Test

A useful portability test is to provide only the SBL specification, the portable SBL package, and a target panel/page identifier to an implementation or fresh AI session with no prior production context. The implementation should be able to identify required resources, resolve the target deterministically, report missing assets, and produce renderer-ready SBL without relying on undocumented production knowledge.

## Diagnostic Severity and Renderability

SBL processors SHOULD report diagnostics using at least three severities: "error", "warning", and "info". An error means the requested operation cannot be completed conformantly without changing or supplying information; examples include invalid JSON, schema violations, unresolved required references, import cycles, missing required resources, and contradictory required constraints. A warning identifies a suspicious or degraded condition that does not necessarily prevent processing. Info is explanatory and does not affect conformance.

A render target is "renderable" only when no unresolved errors apply to that target after parsing, schema validation, resource/import resolution, inheritance/default expansion, and semantic validation. A processor MUST NOT silently convert an error into guessed content. It MAY continue after warnings, but SHOULD expose those warnings to the caller.

## Structural Validation and JSON Schema

SBL 1.0 SHOULD be distributed with a JSON Schema based on JSON Schema Draft 2020-12. The schema validates the structural form of Source SBL before semantic resolution. Schema validation is necessary but not sufficient for SBL conformance.

### Validation Pipeline

```json
Source SBL
  -> JSON parsing
  -> JSON Schema validation
  -> SBL semantic/resolution validation
  -> Resolved SBL
  -> renderer
  -> render-conformance validation
```

Each stage detects a different class of problem. A later stage MUST NOT be used as a substitute for failures that should have been detected earlier.

### JSON Parsing

SBL source is strict JSON. A document that is not valid JSON is not valid SBL. Comments, trailing commas, multiple top-level objects, and other non-JSON syntax are rejected before schema validation.

### Schema Validation Responsibilities

The JSON Schema SHOULD validate object structure, required properties, data types, enumerated values, basic numeric ranges, and mutually exclusive structural alternatives where practical.

```json
Examples of schema-detectable errors:

"present": "no"
  INVALID: present must be Boolean

"width": "1024"
  INVALID: width must be numeric

"volume": "really_loud"
  INVALID: invalid enum value
```

### What JSON Schema Does Not Guarantee

JSON Schema cannot guarantee all semantic correctness. The resolver MUST perform checks that depend on references, inheritance, resource availability, cross-object relationships, layout geometry, or logical contradiction.

### Identifier and Reference Validation

The schema may require id/reference fields syntactically, but uniqueness, collision detection, cross-reference resolution, and inheritance-cycle detection are resolver responsibilities. Anchor uniqueness, anchor-target resolution, reader-facing substitution validity, panel-local footnote scope, duplicate footnote ids, and footnote-reference resolution are likewise resolver responsibilities.

### Layout Validation

The schema validates positive layout weights and basic row/panel structure. The resolver additionally checks merge-region validity and consistency between layout panel ids and panel-content ids.

### Resource Validation

The schema validates resource declarations and standard resource types. The resolver verifies file existence, import loading, purpose compatibility, dependency closure, and required-resource availability.

### Dialogue Validation

The schema SHOULD reject structurally invalid dialogue combinations where practical. Semantic validation verifies speaker ids, speaker-derived tail targets, device sources, next/prev connection references and dialogue array order.

### Standard Schema Artifact

The SBL distribution includes sbl-1.0.schema.json. During the draft phase, the Human-Readable Specification is the authoritative semantic definition. Discrepancies between this specification and the schema MUST be reported and corrected; implementations MUST NOT silently invent a third interpretation. A schema artifact that has not yet encoded a newly adopted SBL construct does not invalidate that construct in the draft Human-Readable Specification.

### Schema Evolution

The schema version is tied to the SBL specification version. Backward-incompatible structural changes require an SBL version change. Implementations SHOULD select the correct schema from script.specification.version.

### Validation Result Categories

Diagnostics SHOULD distinguish JSON syntax errors, schema errors, reference errors, import/resource errors, resolution errors, constraint contradictions, and renderer-conformance failures. Diagnostics SHOULD identify the affected SBL path and/or entity id whenever possible.

### Example Validation Result

```json
{
  "validation_result":
  {
    "valid_json": true,
    "valid_schema": true,
    "valid_semantics": false,
    "errors":
    [
      {
        "type": "unresolved_reference",
        "target": "dialogue.d1.speaker[0]",
        "value": "buren_missing"
      }
    ],
    "render_ready": false
  }
}
```

## Conformance Testing

The SBL Conformance Test Suite is maintained separately from this specification. It contains test documents, expected resolver behavior, expected failures, representative rendering requirements, and analysis artifacts used to determine whether an implementation conforms to a particular version of SBL.

The test suite may be expanded, corrected, or supplemented without changing the SBL language specification. Each release of the suite identifies the SBL specification version against which it applies. Language examples in this specification remain explanatory; formal conformance cases belong in the separate test suite.

The human-facing document is titled SBL Conformance Test Suite. The machine-readable collection of test cases may also be referred to as the conformance corpus.

## Lower-Priority Future Features

Useful but lower-priority additions include panel-border styles and border-breaking effects, manga-specific symbolic iconography, more sophisticated camera/lens modeling, advanced draw/layer ordering, advanced lighting physics, localization/translated-speech workflows, ruby/furigana control, and other features that are not required by the SBL 1.0 core language.
