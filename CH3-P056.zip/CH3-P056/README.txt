SBL 1.0 resolved page rendering package
Render target: CH3-P056
Entry file: CH3-P056.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Zorna-canonical-character-specification.txt
  Assets/Zorna-expression-sheet.png
  Assets/WOA-canonical-production-specification.txt
  Assets/Nyssara-character-sheet.png
  Assets/Terra-canonical-character-specification.txt
  Assets/Alpha-expression-sheet.png
  Assets/Nyssara-expression-sheet.png
  Assets/Zora-Nyas-world-map.png
  Assets/Alpha-character-sheet.png
  Assets/Terra-expression-sheet.png
  Assets/Alpha-canonical-character-specification.txt
  Assets/WOA-observation-field-states-sheet.png
  Assets/Terra-character-sheet.png
  Assets/Nyssara-canonical-character-specification.txt
  Assets/Zorna-character-sheet.png
  Assets/WOA-production-sheet.png
  Assets/WOA-production-sheet-plus-map.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
