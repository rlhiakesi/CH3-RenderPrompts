SBL 1.0 resolved page rendering package
Render target: CH3-P037
Entry file: CH3-P037.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Nyssara-character-sheet.png
  Assets/Nyas-cultural-development-specification.txt
  Assets/Terra-canonical-character-specification.txt
  Assets/Nyssara-expression-sheet.png
  Assets/Terra-character-sheet.png
  Assets/Zorna-expression-sheet.png
  Assets/Zora-Nyas-technology-timeline.txt
  Assets/Alpha-expression-sheet.png
  Assets/Alpha-canonical-character-specification.txt
  Assets/Zora-Nyas-writing-systems-renderer-spec.txt
  Assets/Nyassarian_Language_and_Script.docx
  Assets/Zorna-character-sheet.png
  Assets/Terra-expression-sheet.png
  Assets/Zorna-canonical-character-specification.txt
  Assets/Zora-Nyas-world-map.png
  Assets/Alpha-character-sheet.png
  Assets/Nyssara-canonical-character-specification.txt
  Assets/Zora-Nyas-writing-systems-sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
